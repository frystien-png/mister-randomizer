#!/bin/bash
# Generates a new Super Metroid + ALTTP combo seed (SMZ3).
# The result lands under games/SNES/SMZ3/<today's date>/
python3 /media/fat/Scripts/.randomizer/gen_smz3.py
echo ""
echo "Press any key to close."
read -n 1 -s
