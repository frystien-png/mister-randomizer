#!/bin/bash
# Generates a new A Link to the Past Randomizer seed.
# The result lands under games/SNES/ALTTPR/<today's date>/
python3 /media/fat/Scripts/.randomizer/gen_alttpr.py
echo ""
echo "Press any key to close."
read -n 1 -s
