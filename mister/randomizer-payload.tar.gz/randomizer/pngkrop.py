"""Cuts one cell out of a PNG strip - without PIL, which the MiSTer lacks.

Only the case the strip actually is: 8-bit, RGBA (colour type 6), not
interlaced. Anything else raises ValueError, and the caller falls back on
showing the whole strip with a CSS offset as before.

Why this is needed: the Samus image used to be taken from a SHARED strip using
a stored cell number. If samus.link replaces the strip, every old seed's number
points at the wrong cell, and all seeds already created silently get the wrong
Samus. Link never had the problem - his image is saved as a file per seed. Now
Samus is too.
"""
import struct
import zlib


def _chunks(png):
    if png[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("not a PNG")
    i = 8
    while i < len(png):
        n = struct.unpack(">I", png[i:i + 4])[0]
        typ = png[i + 4:i + 8]
        yield typ, png[i + 8:i + 8 + n]
        i += 12 + n


def _chunk(typ, data):
    return (struct.pack(">I", len(data)) + typ + data
            + struct.pack(">I", zlib.crc32(typ + data) & 0xFFFFFFFF))


def _avfiltrera(rader, w, h):
    """PNG's row filters in reverse. bpp is 4 for RGBA8."""
    bpp, stride = 4, w * 4
    ut = bytearray(h * stride)
    forra = bytearray(stride)
    p = 0
    for y in range(h):
        f = rader[p]
        p += 1
        rad = bytearray(rader[p:p + stride])
        p += stride
        if f == 1:
            for i in range(bpp, stride):
                rad[i] = (rad[i] + rad[i - bpp]) & 0xFF
        elif f == 2:
            for i in range(stride):
                rad[i] = (rad[i] + forra[i]) & 0xFF
        elif f == 3:
            for i in range(stride):
                a = rad[i - bpp] if i >= bpp else 0
                rad[i] = (rad[i] + ((a + forra[i]) >> 1)) & 0xFF
        elif f == 4:
            for i in range(stride):
                a = rad[i - bpp] if i >= bpp else 0
                c = forra[i - bpp] if i >= bpp else 0
                b = forra[i]
                pp = a + b - c
                pa, pb, pc = abs(pp - a), abs(pp - b), abs(pp - c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                rad[i] = (rad[i] + pr) & 0xFF
        elif f != 0:
            raise ValueError("okant radfilter %d" % f)
        ut[y * stride:(y + 1) * stride] = rad
        forra = rad
    return ut


def krop(png, x, bredd):
    """Ny PNG med kolumnerna [x, x+bredd) ur `png`. Full hojd."""
    ihdr = idat = None
    bitar = []
    for typ, data in _chunks(png):
        if typ == b"IHDR":
            ihdr = data
        elif typ == b"IDAT":
            bitar.append(data)
        elif typ == b"IEND":
            break
    if ihdr is None:
        raise ValueError("saknar IHDR")
    w, h, bd, ct, _cm, _fl, il = struct.unpack(">IIBBBBB", ihdr)
    if (bd, ct, il) != (8, 6, 0):
        raise ValueError("stods inte: bitdjup=%d colortype=%d interlace=%d"
                         % (bd, ct, il))
    if x < 0 or bredd <= 0 or x + bredd > w:
        raise ValueError("rutan %d..%d ligger utanfor bilden (%d bred)"
                         % (x, x + bredd, w))

    idat = _avfiltrera(zlib.decompress(b"".join(bitar)), w, h)
    stride, ny_stride = w * 4, bredd * 4
    rader = bytearray()
    for y in range(h):
        rad = y * stride + x * 4
        rader.append(0)                       # filter 0: rakt av
        rader += idat[rad:rad + ny_stride]

    return (b"\x89PNG\r\n\x1a\n"
            + _chunk(b"IHDR", struct.pack(">IIBBBBB", bredd, h, 8, 6, 0, 0, 0))
            + _chunk(b"IDAT", zlib.compress(bytes(rader), 9))
            + _chunk(b"IEND", b""))
