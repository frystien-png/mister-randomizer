#!/usr/bin/env python3
"""SMZ3 - Super Metroid & A Link to the Past Combo Randomizer.
Kors fran MiSTerns Scripts-meny.

Sjalva ROM-bygget ligger i smz3build.py bredvid. Endast standardbiblioteket.
"""

import base64
import datetime
import hashlib
import json
import struct
import re
import gzip
import os
import random
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import smz3build  # noqa: E402
import pngkrop  # noqa: E402

API = "https://samus.link/api/randomizers/smz3/generate"
# The strip with every Samus sprite, 32x48 per cell. Cell 0 is the default
# suit, so the list starts at 1.
SM_SHEET = "https://samus.link/sprites/sm.png"
SM_RUTA = 32
OUTDIR = "/media/fat/games/SNES/SMZ3"
IPS_CACHE = os.path.join(HERE, "zsm.ips")

BASES = {
    "sm": (os.path.join(HERE, "base", "sm.smc"), "21f3e98df4780ee1c667b84e57d88675"),
    "alttp": (os.path.join(HERE, "base", "alttp.smc"), "03a63945398191337e896e5771f77173"),
}

# 'seed' and 'players' MUST be present - otherwise the API answers HTTP 500.
SETTINGS = {
    "smlogic": "normal",
    "goal": "defeatboth",
    "opentower": "sevencrystals",
    "ganonvulnerable": "sevencrystals",
    "opentourian": "fourbosses",
    "swordlocation": "randomized",
    "morphlocation": "randomized",
    "keyshuffle": "none",
    "race": "false",
    "gamemode": "normal",
    "players": "1",
    "seed": "",
}


def die(msg):
    print("")
    print("ERROR: %s" % msg)
    print("")
    sys.exit(1)


def base_rom(key):
    path, want = BASES[key]
    if not os.path.exists(path):
        die("base ROM missing: %s" % path)
    data = open(path, "rb").read()
    got = hashlib.md5(data).hexdigest()
    if got != want:
        die("wrong checksum on %s\n       expected %s\n       got      %s"
            % (os.path.basename(path), want, got))
    return data


SPRITE_URL = "https://alttpr.com/sprites"
Z3_BASE = 0x400000

# Where Link's graphics and palette sit in ONE ALTTP ROM. The same three
# writes pyz3r does; see rom.sprite().
SPRITE_WRITES = [(0x80000, 28671, 0), (0xDD308, 120, None),
                 (0xDEDF5, 4, None)]


def z3_till_smz3(x):
    """ALTTP-offset -> offset i combo-ROM:en.

    ALTTP ligger som 1 MB LoROM fran 0x400000, block for block pa UDDA
    32KB-platser: block o hamnar pa 0x400000 + (2o+1)*0x8000. Samma
    mappning som smz3build.build_base() lagger dit den med.

    Verifierat 2026-08-11 mot en byggd seed: bas-ROM:ens bytes pa
    0x80000, 0xDD308 och 0xDEDF5 aterfinns identiska (100 %) pa de har
    adresserna i combo-ROM:en.
    """
    o, r = divmod(x, 0x8000)
    return Z3_BASE + (2 * o + 1) * 0x8000 + r


# --- Samus-skin -----------------------------------------------------------
# SMZ3 has TWO looks: Link and Samus. Samus sprites are RDC files at
# samus.link, not ZSPR at alttpr, and are written to entirely different places.
#
# Both the sprite list and the write table are FETCHED from the site's JS
# rather than hardcoded. The addresses belong to the SMZ3 version, and a hardcoded
# tabell skulle tyst bli fel den dag spelet uppdateras. Samma resonemang
# that smz3build.py follows for the base IPS.
SPRITE_INDEX = "https://samus.link/sprites/"


def _hamta(u, timeout=90):
    with urllib.request.urlopen(u, timeout=timeout) as r:
        return r.read()


def _sprite_chunk():
    """The JS chunk carrying the sprite list and the write table."""
    idx = _hamta("https://samus.link/").decode("utf-8", "replace")
    huvud = re.search(r"/static/js/main\.[A-Za-z0-9]+\.js", idx)
    if not huvud:
        raise RuntimeError("could not find the main chunk")
    js = _hamta("https://samus.link" + huvud.group(0)).decode("utf-8", "replace")
    for nr, h in re.findall(r"([0-9]{2,4}):\"([a-f0-9]{8,})\"", js):
        try:
            bit = _hamta("https://samus.link/static/js/%s.%s.chunk.js"
                         % (nr, h)).decode("utf-8", "replace")
        except Exception:                                      # noqa: BLE001
            continue
        if "samus_sprite" in bit:
            return bit
    raise RuntimeError("found no chunk with sprite data")


def _js_array(js, nyckel):
    """Cuts out a balanced JS array starting after `nyckel`."""
    start = js.index("[", js.index(nyckel))
    djup = 0
    for i, ch in enumerate(js[start:], start):
        if ch == "[":
            djup += 1
        elif ch == "]":
            djup -= 1
            if djup == 0:
                return js[start:i + 1]
    raise RuntimeError("unbalanced array for %s" % nyckel)


def samus_tabell(js):
    """The write list for RDC block type 4, as Python data."""
    # ⚠️ Search for the name PLUS the comma. Without the comma _js_array hits
    # the outer array ["samus_sprite", [...]] and the first entry becomes
    # strangen i stallet for forsta skrivningen.
    arr = _js_array(js, '"samus_sprite",')
    # `St` is a named stride list in the chunk; resolve it.
    st = re.search(r"St=(\[[0-9,]+\])", js)
    if st:
        arr = arr.replace(",St]", "," + st.group(1) + "]")
    arr = re.sub(r"(\w+):", r'"\1":', arr)
    arr = arr.replace("102e5", "10200000")
    return json.loads(arr)


def samus_lista(js):
    """[(title, path)] for Samus sprites."""
    arr = _js_array(js, '"sm":')
    return [(d["title"], d["path"]) for d in json.loads(arr) if d.get("path")]


def rdc_block(rdc, typ):
    """The data for one block out of an RDC file, plus its author."""
    if rdc[:18] != b"RETRODATACONTAINER":
        raise ValueError("not an RDC file")
    if rdc[18] != 1:
        raise ValueError("RDC version %d is not supported" % rdc[18])
    antal = struct.unpack("<I", rdc[19:23])[0]
    a, block = 23, []
    for _ in range(antal):
        block.append(struct.unpack("<II", rdc[a:a + 8]))
        a += 8
    slut = rdc.index(b"\0", a)
    forf = rdc[a:slut].decode("utf-8", "replace")
    for t, off in block:
        if t == typ:
            return rdc[off:], forf
    raise ValueError("block type %d is missing" % typ)


def snes_till_pc(e):
    """ExHiROM addressing, like samus.link's own yt()."""
    return (0x400000 if e < 0x800000 else 0) | (e & 0x3FFFFF)


def applicera_samus(rom, data, tabell):
    """Writes the Samus graphics using the site's own write table.

    The block's data is split into as many pieces as the table has entries,
    where each entry takes `count * size` bytes. Each piece is then written to
    sin adress, `count` ganger med `stride` emellan.
    """
    bitar, a = [], 0
    for post in tabell:
        n = post[1]
        antal = post[2] if len(post) > 2 else 1
        bitar.append(data[a:a + antal * n])
        a += antal * n
    for post, bit in zip(tabell, bitar):
        adr, n = post[0], post[1]
        antal = post[2] if len(post) > 2 else 1
        stride = post[3] if len(post) > 3 else 0
        lista = adr["exhirom"] if isinstance(adr, dict) else adr
        for bas in lista:
            for y in range(antal):
                hopp = stride[y] if isinstance(stride, list) else stride * y
                m = snes_till_pc(bas + hopp)
                rom[m:m + n] = bit[n * y:n * (y + 1)]


def valj_samus_skin():
    """(titel, forfattare, blockdata, tabell) eller (None, ...)."""
    try:
        js = _sprite_chunk()
        tabell = samus_tabell(js)
        lista = samus_lista(js)
        ix = random.randrange(len(lista))
        titel, sokvag = lista[ix]
        rdc = gzip.decompress(_hamta(SPRITE_INDEX + sokvag))
        data, forf = rdc_block(rdc, 4)
    except Exception as e:                                     # noqa: BLE001
        print("  skipping the Samus skin (%s: %s)" % (type(e).__name__, e))
        return None, None, None, None, None
    return titel, forf, data, tabell, ix


def spara_samus_bild(outdir, stem, ruta):
    """Klipper ut seedens Samus ur remsan och sparar den som egen fil.

    ⚠️ Varfor inte bara spara rutnumret, som forut: numret pekar in i en
    DELAD remsa. Laggs en sprite till hos samus.link forskjuts rutorna, och
    da byter varje redan skapad seed tyst Samus. Link har aldrig haft det
    problemet - hans bild laddas ner per seed. Nu gor Samus likadant.

    Remsan hamtas har och nu, inte ur den lokala kopian, sa att bilden med
    sakerhet hor ihop med sprite-listan vi nyss slumpade ur.
    """
    png = pngkrop.krop(_hamta(SM_SHEET), SM_RUTA * ruta, SM_RUTA)
    sokvag = os.path.join(outdir, stem + ".samus.png")
    with open(sokvag, "wb") as f:
        f.write(png)
    return sokvag


def valj_skin():
    """Picks a sprite alttpr itself has marked as SMZ3-capable."""
    try:
        with urllib.request.urlopen(SPRITE_URL, timeout=60) as r:
            alla = json.loads(r.read())
    except Exception as e:                                     # noqa: BLE001
        print("  could not fetch the sprite list (%s), using the default look"
              % type(e).__name__)
        return None, None
    val = [s for s in alla if s.get("file") and s.get("name") != "Link"
           and "smz3" in (s.get("usage") or [])]
    if not val:
        return None, None
    skin = random.choice(val)
    try:
        with urllib.request.urlopen(skin["file"], timeout=60) as r:
            zspr = r.read()
    except Exception as e:                                     # noqa: BLE001
        print("  could not fetch %s (%s), using the default look"
              % (skin.get("name"), type(e).__name__))
        return None, None
    return skin, zspr


def applicera_skin(rom, zspr):
    """Writes the sprite graphics into the ALTTP half's slots in the combo ROM."""
    gfx = zspr[12] << 24 | zspr[11] << 16 | zspr[10] << 8 | zspr[9]
    pal = zspr[18] << 24 | zspr[17] << 16 | zspr[16] << 8 | zspr[15]
    kallor = [gfx, pal, pal + 120]
    for (z3off, n, _), src in zip(SPRITE_WRITES, kallor):
        bitar = zspr[src:src + n]
        if len(bitar) < n:
            raise ValueError("the zspr file is too short")
        # Skrivningarna ryms inom var sitt 32KB-block, men dela anda -
        # that keeps the function correct even if an offset moves.
        skrivet = 0
        while skrivet < n:
            a = z3off + skrivet
            plats = 0x8000 - (a % 0x8000)
            bit = min(plats, n - skrivet)
            m = z3_till_smz3(a)
            rom[m:m + bit] = bitar[skrivet:skrivet + bit]
            skrivet += bit


def main():
    print("Super Metroid & A Link to the Past Combo Randomizer")
    print("===================================================")
    print("")

    sm = base_rom("sm")
    z3 = base_rom("alttp")
    print("Base ROMs verified.")

    print("Generating a seed at samus.link ...")
    req = urllib.request.Request(
        API, data=json.dumps(SETTINGS).encode(),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            data = json.loads(r.read())
    except Exception as e:
        die("could not reach samus.link: %s: %s\n       Does the MiSTer have network?"
            % (type(e).__name__, e))

    version = data.get("gameVersion", "?")
    seed_no = data.get("seedNumber", data["guid"][:8])
    print("  hash: %s" % data.get("hash", "-"))
    print("  url:  https://samus.link/seed/%s" % data["guid"])

    print("Building the combo ROM ...")
    if not os.path.exists(IPS_CACHE):
        print("  fetching the base IPS (one-off, ~400 KB) ...")
    try:
        rom, n_ips, n_seed, header = smz3build.build(
            sm, z3, base64.b64decode(data["worlds"][0]["patch"]),
            ips_cache=IPS_CACHE)
    except (RuntimeError, ValueError) as e:
        die(str(e))
    print("  base IPS: %d entries, seed patch: %d entries" % (n_ips, n_seed))
    print("  header: %s" % header)

    print("Picking skins ...")
    rom = bytearray(rom)
    skin, zspr = valj_skin()
    if zspr:
        try:
            applicera_skin(rom, zspr)
            print("  Link:  %s by %s"
                  % (skin.get("name"), skin.get("author") or "unknown"))
        except (ValueError, IndexError) as e:
            print("  the Link skin could not be applied (%s)" % e)
            skin = None
    stitel, sforf, sdata, stab, six = valj_samus_skin()
    if sdata:
        try:
            applicera_samus(rom, sdata, stab)
            print("  Samus: %s by %s" % (stitel, sforf or "unknown"))
        except (ValueError, IndexError, KeyError) as e:
            print("  the Samus skin could not be applied (%s)" % e)
            stitel = None
    rom = bytes(rom)

    today = datetime.date.today().isoformat()
    outdir = os.path.join(OUTDIR, today)
    os.makedirs(outdir, exist_ok=True)
    stem = "SMZ3-v%s-%s" % (version, seed_no)
    rom_path = os.path.join(outdir, stem + ".sfc")
    with open(rom_path, "wb") as f:
        f.write(rom)

    if skin or stitel:
        with open(os.path.join(outdir, stem + ".skin.json"), "w") as f:
            json.dump({"name": (skin or {}).get("name"),
                       "author": (skin or {}).get("author"),
                       "preview": (skin or {}).get("preview"),
                       "samus": stitel, "samus_author": sforf,
                       # ⚠️ The cell in the strip, not the list index. Cell 0 is
                       # the default Samus and the list therefore starts at
                       # 1 - without +1 the neighbour's sprite is shown.
                       "samus_index": (six + 1) if six is not None else None},
                      f, indent=1)
        if skin and skin.get("preview"):
            try:
                with urllib.request.urlopen(skin["preview"], timeout=60) as r:
                    open(os.path.join(outdir, stem + ".skin.png"), "wb").write(r.read())
            except Exception as e:                             # noqa: BLE001
                print("  could not fetch the preview image (%s)" % type(e).__name__)
        # Samus gets an image of her own the same way. If it fails the card
        # falls back on the strip + samus_index, as before.
        try:
            spara_samus_bild(outdir, stem, (six + 1) if six is not None else 0)
        except Exception as e:                                 # noqa: BLE001
            print("  could not save the Samus image (%s: %s)"
                  % (type(e).__name__, e))

    spoiler = data.get("spoiler")
    if isinstance(spoiler, str):
        try:
            spoiler = json.loads(spoiler)
        except ValueError:
            pass
    with open(os.path.join(outdir, stem + ".txt"), "w") as f:
        json.dump(spoiler, f, indent=4, ensure_ascii=False)

    print("")
    print("DONE")
    print("  %s" % rom_path)
    print("  %.1f MB" % (os.path.getsize(rom_path) / 1048576.0))
    print("")
    print("Filed under SNES > SMZ3 > %s" % today)


if __name__ == "__main__":
    main()
