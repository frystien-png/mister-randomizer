"""Builds SMZ3 combo ROMs (Super Metroid + A Link to the Past).

Reverse-engineered from samus.link's client code (chunk 464.*.js) and verified
against a known working reference ROM: the build differs from the reference by
0.37 %, which is exactly one seed patch.

Four steps, in this order:

  1. build_base()  - corresponds to Qt() in the client. 6 MB ExHiROM:
       Super Metroid is 3 MB LoROM and is packed into the first 4 MB:
         blocks 0-63  -> ODD 32KB slots, (2i+1)*0x8000
         blocks 64-95 -> EVEN slots,       2*(i-64)*0x8000
       ALTTP is 1 MB LoROM and goes at 0x400000:
         block o      -> 0x400000 + (2o+1)*0x8000

  2. apply_ips()    - motsvarar Yt(). Bas-IPS:en zsm.ips innehaller hela
       SMZ3-motorn (~1,4 MB uppackat) och fyller de jamna platserna i
       0x200000-0x3FFFFF som steg 1 lamnar tomma. UTAN DETTA STEG startar
       spelet men gar inte att spela. Formatet ar vanlig IPS:
       'PATCH' + [3-byte BE offset][2-byte BE langd][data], langd 0 = RLE.

  3. apply_seed()   - motsvarar $t(). Seedens egna andringar fran API:et.
       HELT ANNAT format an IPS: [4-byte LE offset][2-byte LE langd][data].

  4. Kontroll att SNES-headern pa 0x40FFC0 borjar med 'ZSM'.

IPS:ens URL innehaller en innehallshash som andras nar SMZ3 uppdateras.
Hittas den inte letas den upp automatiskt i webbplatsens JS-chunkar.
"""

import gzip
import os
import re
import struct
import urllib.request

BASE_URL = "https://samus.link"
IPS_URL = f"{BASE_URL}/static/media/zsm.ips.6dd02c44aa7fefdaa4e2.gz"

ROM_SIZE = 0x600000
Z3_BASE = 0x400000


def _get(url, timeout=120):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def discover_ips_url():
    """Letar upp aktuell zsm.ips-URL i webbplatsens JS om den hardkodade dott."""
    index = _get(BASE_URL + "/", timeout=30).decode("utf-8", "replace")
    m = re.search(r'src="(/static/js/main\.[^"]+\.js)"', index)
    if not m:
        return None
    main = _get(BASE_URL + m.group(1)).decode("utf-8", "replace")
    hit = re.search(r"static/media/zsm\.ips\.[a-f0-9]+\.gz", main)
    if hit:
        return f"{BASE_URL}/{hit.group(0)}"
    # The build sits in a lazily loaded chunk - search through them.
    for cid, chash in re.findall(r'(\d{2,4}):"([a-f0-9]{8})"', main):
        try:
            js = _get(f"{BASE_URL}/static/js/{cid}.{chash}.chunk.js",
                      timeout=30).decode("utf-8", "replace")
        except OSError:
            continue
        hit = re.search(r"static/media/zsm\.ips\.[a-f0-9]+\.gz", js)
        if hit:
            return f"{BASE_URL}/{hit.group(0)}"
    return None


def fetch_base_ips(cache_path):
    """Fetches and unpacks the base IPS. Cached - it only changes with SMZ3
    updates."""
    if cache_path and os.path.exists(cache_path):
        with open(cache_path, "rb") as f:
            data = f.read()
        if data[:5] == b"PATCH":
            return data
    try:
        raw = _get(IPS_URL)
    except OSError:
        url = discover_ips_url()
        if not url:
            raise RuntimeError(
                "cannot find the base IPS zsm.ips at samus.link. "
                "Without it the combo ROM is unplayable.")
        raw = _get(url)
    ips = gzip.decompress(raw) if raw[:2] == b"\x1f\x8b" else raw
    if ips[:5] != b"PATCH":
        raise RuntimeError("bas-IPS:en saknar PATCH-magic - hoppar av")
    if cache_path:
        try:
            with open(cache_path, "wb") as f:
                f.write(ips)
        except OSError:
            pass
    return ips


def build_base(sm, z3):
    rom = bytearray(ROM_SIZE)
    a = 0
    for i in range(64):
        lo = sm[0x8000 * (i + 64):0x8000 * (i + 65)]
        hi = sm[0x8000 * i:0x8000 * (i + 1)]
        rom[a:a + len(lo)] = lo
        rom[a + 0x8000:a + 0x8000 + len(hi)] = hi
        a += 0x10000
    a = Z3_BASE
    for o in range(32):
        c = z3[0x8000 * o:0x8000 * (o + 1)]
        rom[a + 0x8000:a + 0x8000 + len(c)] = c
        a += 0x10000
    return rom


def apply_ips(rom, ips):
    pos, n = 5, 0
    while pos + 3 <= len(ips):
        if ips[pos:pos + 3] == b"EOF":
            break
        off = (ips[pos] << 16) | (ips[pos + 1] << 8) | ips[pos + 2]
        ln = (ips[pos + 3] << 8) | ips[pos + 4]
        pos += 5
        if ln == 0:
            rl = (ips[pos] << 8) | ips[pos + 1]
            rom[off:off + rl] = bytes([ips[pos + 2]]) * rl
            pos += 3
        else:
            rom[off:off + ln] = ips[pos:pos + ln]
            pos += ln
        n += 1
    return n


def apply_seed(rom, patch):
    pos, n = 0, 0
    while pos < len(patch):
        off, ln = struct.unpack("<IH", patch[pos:pos + 6])
        pos += 6
        if ln == 0 or pos + ln > len(patch):
            raise ValueError(f"trasig seed-patch vid byte {pos}")
        if off + ln > ROM_SIZE:
            raise ValueError(f"seed-patchen pekar utanfor ROM:en: 0x{off:X}")
        rom[off:off + ln] = patch[pos:pos + ln]
        pos += ln
        n += 1
    return n


def build(sm, z3, seed_patch, ips_cache=None):
    """Returnerar (rom_bytes, antal_ips_poster, antal_seed_poster, header)."""
    rom = build_base(sm, z3)
    n_ips = apply_ips(rom, fetch_base_ips(ips_cache))
    n_seed = apply_seed(rom, seed_patch)

    header = bytes(rom[0x40FFC0:0x40FFD5])
    if not header.startswith(b"ZSM"):
        raise RuntimeError(
            f"bygget ser fel ut - headern borjar inte med 'ZSM' ({header!r})")
    m, sz, sram = rom[0x40FFD5], rom[0x40FFD7], rom[0x40FFD8]
    if (m, sz, sram) != (0x35, 0x0D, 0x05):
        raise RuntimeError(
            f"fel ROM-header: map=0x{m:02X} romsz=0x{sz:02X} sram=0x{sram:02X} "
            "(vantade ExHiROM 8 MB / 32 KB SRAM)")
    return bytes(rom), n_ips, n_seed, header.decode("ascii", "replace").strip()
