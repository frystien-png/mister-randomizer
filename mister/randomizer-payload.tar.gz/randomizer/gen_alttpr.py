#!/usr/bin/env python3
"""ALTTP Randomizer - run from the MiSTer's Scripts menu.

The same settings as the desktop script: NoGlitches / open / ganon.
No ROM is ever uploaded - alttpr.com only sends patch data, which is applied
locally to the base ROM in base/alttp.smc.

The dependencies are vendored in the same folder (bps/ and pyz3r/), so no pip
is needed.
"""

import datetime
import hashlib
import json
import os
import random
import sys
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from pyz3r.rom import Rom  # noqa: E402
import net_reason  # noqa: E402

BASE_URL = "https://alttpr.com"
BASE_ROM = os.path.join(HERE, "base", "alttp.smc")
BASE_MD5 = "03a63945398191337e896e5771f77173"
OUTDIR = "/media/fat/games/SNES/ALTTPR"

SETTINGS = {
    "glitches": "none",
    "item_placement": "advanced",
    "dungeon_items": "standard",
    "accessibility": "items",
    "goal": "ganon",
    "crystals": {"ganon": "7", "tower": "7"},
    "mode": "open",
    "entrances": "none",
    "hints": "on",
    "weapons": "randomized",
    "item": {"pool": "normal", "functionality": "normal"},
    "tournament": False,
    "spoilers": "on",
    "lang": "en",
    "enemizer": {
        "boss_shuffle": "none",
        "enemy_shuffle": "none",
        "enemy_damage": "default",
        "enemy_health": "default",
    },
}


SPRITE_URL = BASE_URL + "/sprites"


def die(msg):
    print("")
    print("ERROR: %s" % msg)
    print("")
    sys.exit(1)


def valj_skin():
    """Slumpar en av alttpr.coms sprites. (skin, zspr) eller (None, None).

    Skinnet ar rent kosmetiskt men fyller ett syfte: det gor seeden lattare
    att kanna igen an en hash. Misslyckas hamtningen fortsatter vi utan -
    en seed utan skin ar battre an ingen seed.
    """
    try:
        alla = json.loads(get(SPRITE_URL))
    except Exception as e:                                     # noqa: BLE001
        print("  could not fetch the sprite list (%s), using the default look"
              % type(e).__name__)
        return None, None
    # "Link" is the default look - randomise that and you have no idea the
    # skin feature is even on, so it is skipped.
    val = [s for s in alla if s.get("file") and s.get("name") != "Link"]
    if not val:
        return None, None
    skin = random.choice(val)
    try:
        zspr = get(skin["file"])
    except Exception as e:                                     # noqa: BLE001
        print("  could not fetch %s (%s), using the default look"
              % (skin.get("name"), type(e).__name__))
        return None, None
    return skin, zspr


def spara_skin(outdir, stem, skin):
    """Writes the skin's name and preview image next to the ROM.

    The image is downloaded now rather than when it is shown: the MiSTer does
    not always have network while you are looking at the tracker, and a broken
    image there would be annoying for something that is only a memory hook.
    """
    with open(os.path.join(outdir, stem + ".skin.json"), "w") as f:
        json.dump({"name": skin.get("name"), "author": skin.get("author"),
                   "preview": skin.get("preview")}, f, indent=1)
    if not skin.get("preview"):
        return
    try:
        png = get(skin["preview"])
        with open(os.path.join(outdir, stem + ".skin.png"), "wb") as f:
            f.write(png)
    except Exception as e:                                     # noqa: BLE001
        print("  could not fetch the preview image (%s)" % type(e).__name__)


def get(url, data=None):
    req = urllib.request.Request(
        url,
        data=json.dumps(data).encode() if data is not None else None,
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()


def main():
    print("A Link to the Past Randomizer")
    print("=============================")
    print("")

    if not os.path.exists(BASE_ROM):
        die("base ROM missing: %s" % BASE_ROM)
    got = hashlib.md5(open(BASE_ROM, "rb").read()).hexdigest()
    if got != BASE_MD5:
        die("wrong checksum on the base ROM\n       expected %s\n       got      %s"
            % (BASE_MD5, got))
    print("Base ROM verified.")

    print("Generating a seed at alttpr.com ...")
    # Every call to alttpr.com shares one handler, so a failure is explained
    # the same way wherever it happens. Only the first call used to be guarded;
    # the other two ended in a bare traceback.
    url = BASE_URL + "/api/randomizer"
    try:
        seed = json.loads(get(url, SETTINGS))
        seed_hash = seed["hash"]
        print("  hash: %s" % seed_hash)
        print("  url:  %s/h/%s" % (BASE_URL, seed_hash))

        print("Fetching the base patch ...")
        url = "%s/api/h/%s" % (BASE_URL, seed_hash)
        info = json.loads(get(url))
        url = BASE_URL + info["bpsLocation"]
        bps = get(url)
    except Exception as e:                                     # noqa: BLE001
        net_reason.fail(e, url)

    print("Patching the ROM ...")
    rom = Rom(BASE_ROM)
    rom.apply_bps_patch(patch=bps)
    if seed["size"] > 2:
        rom.expand(newlenmb=seed["size"])
    rom.apply_dict_patches(patches=seed["patch"])
    rom.heart_speed("half")
    rom.heart_color("red")
    rom.menu_speed("normal")
    rom.quickswap(True)
    rom.music(True)
    rom.msu1_resume(True)

    # ⚠️ The skin has to be applied BEFORE checksum() - it writes into the ROM.
    print("Picking a skin ...")
    skin, zspr = valj_skin()
    if zspr:
        rom.sprite(zspr)
        print("  %s by %s" % (skin.get("name"), skin.get("author") or "unknown"))

    rom.checksum()

    today = datetime.date.today().isoformat()
    outdir = os.path.join(OUTDIR, today)
    os.makedirs(outdir, exist_ok=True)
    stem = "alttpr - NoGlitches-open-ganon_%s" % seed_hash
    rom_path = os.path.join(outdir, stem + ".sfc")
    rom.write_to_file(rom_path)
    with open(os.path.join(outdir, stem + ".txt"), "w") as f:
        json.dump(seed.get("spoiler", {}), f, indent=4)
    if skin:
        spara_skin(outdir, stem, skin)

    print("")
    print("DONE")
    print("  %s" % rom_path)
    print("  %.1f MB" % (os.path.getsize(rom_path) / 1048576.0))
    print("")
    print("Filed under SNES > ALTTPR > %s" % today)


if __name__ == "__main__":
    main()
