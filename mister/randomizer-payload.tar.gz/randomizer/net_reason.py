"""Explains why a download failed, in words a player can act on.

Everything the generators fetch goes over HTTPS, and the exceptions urllib
raises are written for programmers:

    URLError: <urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate
    verify failed: certificate has expired (_ssl.c:1129)>

followed by our own guess that the network was down. On 2026-09-11 samus.link
let its certificate expire, and that guess sent the player looking at the
wrong end of the cable.

classify() turns the exception into a reason code plus the facts behind it.
When the game browser runs a generator it sets RANDOMIZER_REASON=1 and reads
the REASON line back, so the page can show a TRANSLATED sentence - server.py
holds those sentences as GEN_REASONS. Run from the Scripts menu the line is
left out and the English text below is all you see.
"""

import json
import os
import socket
import ssl
import sys
import tempfile
import time
import urllib.error
import urllib.parse

# OpenSSL's verify codes (X509_V_ERR_*).
CERT_NOT_YET_VALID = 9
CERT_HAS_EXPIRED = 10

# The MiSTer has no battery-backed clock; it is set over the network at boot.
# A clock before this code was written cannot be right, and then every
# certificate looks expired or not yet valid - the site is not to blame.
CLOCK_FLOOR = 1785456000                     # 2026-07-31 00:00 UTC

# English for the terminal. Keep in step with GEN_REASONS in server.py.
TEXTS = {
    "cert_expired": "%(host)s's security certificate expired on %(date)s, so the connection is refused. The fault is on %(host)s's side - try again once they have renewed it.",
    "cert_expired_nodate": "%(host)s's security certificate has expired, so the connection is refused. The fault is on %(host)s's side - try again once they have renewed it.",
    "clock": "The MiSTer's clock says %(now)s, so %(host)s's certificate cannot be checked. The clock is set from the network at boot - check the network and restart the MiSTer.",
    "cert": "%(host)s's security certificate could not be verified (%(detail)s), so the connection is refused.",
    "offline": "Could not reach %(host)s. Check that the MiSTer has network.",
    "timeout": "%(host)s did not answer in time. The site may be slow or down - try again later.",
    "http": "%(host)s answered with an error (HTTP %(code)s). The fault is on %(host)s's side, not the MiSTer's - try again later.",
    "other": "The download from %(host)s failed: %(detail)s",
}


def _utc(seconds):
    return time.strftime("%Y-%m-%d %H:%M UTC", time.gmtime(seconds))


def _host(url):
    return urllib.parse.urlsplit(url).hostname or url


def cert_expiry(host, port=443):
    """When the certificate the host serves expires (epoch seconds), or None.

        Fetched WITHOUT verification: it is only read to explain the failure,
        never trusted, and nothing else is sent over the connection.

        ⚠️ server_hostname is required. Without SNI samus.link's load balancer
        answers with a fallback "Kubernetes Ingress Controller Fake
        Certificate" carrying entirely different dates - and
        ssl.get_server_certificate on the MiSTer's Python 3.9 sends no SNI.
    """
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((host, port), timeout=15) as s:
            with ctx.wrap_socket(s, server_hostname=host) as t:
                der = t.getpeercert(binary_form=True)
        # getpeercert() only decodes a VERIFIED certificate. The standard
        # library can still decode an unverified one, but only from a file.
        fd, path = tempfile.mkstemp(suffix=".pem")
        try:
            with os.fdopen(fd, "w") as f:
                f.write(ssl.DER_cert_to_PEM_cert(der))
            decoded = ssl._ssl._test_decode_cert(path)
        finally:
            os.unlink(path)
        return ssl.cert_time_to_seconds(decoded["notAfter"])
    except Exception:                                          # noqa: BLE001
        return None


def classify(exc, url):
    """(kind, facts) for an exception raised while fetching `url`."""
    host = _host(url)
    now = time.time()
    # urlopen wraps most failures in URLError(reason); a timeout while reading
    # the body arrives bare.
    reason = getattr(exc, "reason", exc)

    # HTTPError is a URLError too, so it has to be tested first.
    if isinstance(exc, urllib.error.HTTPError):
        return "http", {"host": host, "code": exc.code}
    if isinstance(reason, ssl.SSLCertVerificationError):
        code = getattr(reason, "verify_code", None)
        if now < CLOCK_FLOOR or code == CERT_NOT_YET_VALID:
            return "clock", {"host": host, "now": _utc(now)}
        if code == CERT_HAS_EXPIRED:
            expired = cert_expiry(host)
            if expired is not None:
                return "cert_expired", {"host": host, "date": _utc(expired)}
            return "cert_expired_nodate", {"host": host}
        return "cert", {"host": host,
                        "detail": getattr(reason, "verify_message", None)
                        or str(reason)}
    if isinstance(reason, socket.timeout):
        return "timeout", {"host": host}
    if isinstance(reason, ssl.SSLError):
        return "other", {"host": host, "detail": str(reason)}
    if isinstance(reason, OSError):
        return "offline", {"host": host}
    return "other", {"host": host, "detail": "%s: %s" % (type(exc).__name__, exc)}


def fail(exc, url):
    """Explain the failure and exit, the same way die() does."""
    kind, facts = classify(exc, url)
    print("")
    print("ERROR: %s" % (TEXTS[kind] % facts))
    if os.environ.get("RANDOMIZER_REASON"):
        facts = dict(facts, kind=kind)
        print("REASON %s" % json.dumps(facts, ensure_ascii=False))
    print("")
    sys.exit(1)
