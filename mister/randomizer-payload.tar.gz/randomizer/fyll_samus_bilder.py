#!/usr/bin/env python3
"""Gives already created SMZ3 seeds a Samus image of their own.

New seeds get their image from gen_smz3.py. This script takes the old ones,
which only have a cell number into the shared strip and would therefore change
Samus silently if samus.link ever adds a sprite.

    python3 fyll_samus_bilder.py          # show what would be done
    python3 fyll_samus_bilder.py --skarp  # write the files

Safe to re-run: seeds that already have an image are left alone.
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import pngkrop  # noqa: E402

SEEDS = "/media/fat/games/SNES/SMZ3"
SHEET = "/media/fat/Scripts/.mistergames/sprites-sm.png"
RUTA = 32


def main():
    skarp = "--skarp" in sys.argv
    try:
        with open(SHEET, "rb") as f:
            sheet = f.read()
    except OSError as e:
        print("cannot find the strip: %s" % e)
        return 1

    gjorda = hoppade = fel = 0
    for dp, _dn, fns in os.walk(SEEDS):
        for fn in sorted(fns):
            if not fn.lower().endswith(".sfc"):
                continue
            stem = fn[:-4]
            mal = os.path.join(dp, stem + ".samus.png")
            if os.path.exists(mal):
                hoppade += 1
                continue
            # The cell number is in skin.json. If the file is missing the
            # seed predates skin support and gets the default suit, cell 0.
            ruta = 0
            try:
                with open(os.path.join(dp, stem + ".skin.json")) as f:
                    ruta = json.load(f).get("samus_index") or 0
            except (OSError, ValueError):
                pass
            try:
                png = pngkrop.krop(sheet, RUTA * ruta, RUTA)
            except ValueError as e:
                print("  ERROR %s (cell %d): %s" % (stem, ruta, e))
                fel += 1
                continue
            print("  %s -> cell %d, %d bytes%s"
                  % (stem, ruta, len(png), "" if skarp else "  (torrkorning)"))
            if skarp:
                with open(mal, "wb") as f:
                    f.write(png)
            gjorda += 1

    print("")
    print("%d to write, %d already had an image, %d failed"
          % (gjorda, hoppade, fel))
    if not skarp and gjorda:
        print("Re-run with --skarp to write the files.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
