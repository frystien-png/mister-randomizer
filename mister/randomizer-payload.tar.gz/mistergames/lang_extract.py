"""Pull the translatable strings out of the pages.

Run it from .mistergames/:

    python3 lang_extract.py > lang/TEMPLATE.json

The output is a language file where every key points at itself - the
English source, unchanged. Translate the right-hand side, save it as
lang/<code>.json and pick the language in the installer.

⚠️ The extraction MUST use the same pattern language.py substitutes with,
or you get keys that can never match. That is why the pattern is imported
from there instead of copied.
"""
import json
import re
import sys

from language import DELIMITED

PAGES = ["page.py", "seedpage.py", "annotatepage.py"]

# Segments that are code rather than text: class names, CSS values, API
# routes, DOM properties and the like.
#
# ⚠️ A single capitalised word ("Direct", "Cancel") is almost always button
# text - the classes and ids in the pages are lowercase throughout. What is
# code, on the other hand, is a lowercase word, or a word with a capital in
# the MIDDLE (classList, innerHTML).
CODE = re.compile(
    r"""^(?:
        [a-z0-9_-]+                      # single lowercase word: class/id/attr
      | [A-Za-z][A-Za-z0-9_]*[A-Z][A-Za-z0-9_]*   # capital inside: identifier
      | [\d\s.,:;%+-]*                   # digits and punctuation only
      | (?:utf|UTF)-8
      | [a-z]+:[a-z0-9 ,.-]*             # css declaration
    )$""",
    re.X,
)

# Words that give away JS or CSS even when the shape looks innocent.
CODE_WORDS = re.compile(
    r"\b(?:function|return|const|let|var|null|true|false|undefined|"
    r"px|rem|vh|vw|rgba?|solid|none|flex|grid|block|inline|hidden|"
    r"POST|GET|application|charset|width|height|device)\b"
)

# Characters that never occur in a sentence but constantly in code. One is
# enough to discard the segment - it is then an attribute name, a CSS
# declaration or a piece of an expression, not something a user reads.
CODE_CHARS = re.compile(r"[=${}();#/\\<>\[\]|*\n\t]")

# ⚠️ The parenthesis in CODE_CHARS also swallows real labels: "Cleared (",
# "Remaining (", "Still to open (", "Already revealed (" are counted before a
# number and therefore end in an open bracket. They will NEVER come out of an
# extraction, so they are kept by hand in TEMPLATE.json - do not delete keys
# from the template just because a fresh run does not produce them.

# CSS selectors, file names and HTML headers. They sit in the same kind of
# quotes as the text but must NEVER be translated - a translated class list
# breaks the page instead of speaking French.
SELECTOR = re.compile(
    r"""^(?:
        [.,][A-Za-z0-9 ._-]*             # .class, .a .b, leading comma
      | [A-Za-z0-9 ._-]*\.(?:png|webp|jpe?g|svg|json|trk|smc|sfc)$
      | [a-z-]+:[^ ]*                    # css declaration
      | [Cc]ontent-[Tt]ype
    )$""",
    re.X,
)


def candidates(text):
    for m in DELIMITED.finditer(text):
        s = m.group("text")
        if not (2 <= len(s) <= 80):
            continue
        if not re.search(r"[A-Za-z]", s):
            continue
        if CODE_CHARS.search(s):
            continue
        # ⚠️ NOT s.strip() here. Keys like " games" (the count is glued to
        # the word: 42+' games') are real user text, but stripped they look
        # like class names and used to fall out - so "42 games" simply
        # could not be translated.
        if CODE.match(s) or CODE_WORDS.search(s):
            continue
        if SELECTOR.match(s):
            continue
        # Segments with code interpolated in the middle ('+n+') cannot be
        # translated as a whole - they sit around a variable and are picked
        # up in their separate parts.
        if "+" in s and re.search(r"\+\s*\w", s):
            continue
        yield s


def main():
    out = {}
    for page in PAGES:
        try:
            text = open(page, encoding="utf-8").read()
        except OSError as e:
            print("skipping %s: %s" % (page, e), file=sys.stderr)
            continue
        for s in candidates(text):
            out.setdefault(s, s)
    print(json.dumps(out, ensure_ascii=False, indent=2, sort_keys=True))
    print("%d strings" % len(out), file=sys.stderr)


if __name__ == "__main__":
    main()
