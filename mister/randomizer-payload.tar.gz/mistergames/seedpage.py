"""The seed page: create, pick and launch randomizer seeds.

Served both by the MiSTer (at /seeds) and by Home Assistant from
/config/www/mister-seeds.html, where window.MISTER_API points back here.
"""

SEEDPAGE = r"""<!doctype html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Seeds</title>
<style>
:root{--bg:#12141a;--card:#1c2029;--card2:#232833;--fg:#e8eaf0;--dim:#8b93a7;
--accent:#5b9dff;--ok:#3ddc84;--line:#2c313d}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;background:var(--bg);color:var(--fg);
font:16px/1.4 system-ui,-apple-system,"Segoe UI",sans-serif;overscroll-behavior:none}
header{position:sticky;top:0;z-index:5;background:rgba(18,20,26,.96);
backdrop-filter:blur(8px);border-bottom:1px solid var(--line);
padding:env(safe-area-inset-top) 0 0}
.bar{display:flex;align-items:center;gap:10px;padding:12px 14px}
h1{font-size:18px;margin:0;font-weight:600;flex:1}
.cog{width:38px;height:38px;border-radius:11px;background:var(--card);
border:1px solid var(--line);color:var(--dim);font-size:18px;flex:0 0 auto;
display:flex;align-items:center;justify-content:center;text-decoration:none}
.cog:active{border-color:var(--accent);color:var(--accent)}
.now{display:none;align-items:center;gap:7px;background:var(--card);
border:1px solid var(--line);border-radius:99px;padding:5px 12px 5px 9px;
font-size:12.5px;color:var(--dim);max-width:50vw}
.now.show{display:inline-flex}
.now b{color:var(--fg);font-weight:600;overflow:hidden;
text-overflow:ellipsis;white-space:nowrap}
.now i{width:7px;height:7px;border-radius:50%;background:var(--ok);
flex:0 0 auto;animation:pulse 2.2s ease-in-out infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
main{padding:14px 14px calc(30px + env(safe-area-inset-bottom))}
section{margin-bottom:26px}
.sh{display:flex;align-items:center;gap:12px;margin-bottom:12px}
.sh .ic{font-size:26px;line-height:1}
.sh .tx{flex:1;min-width:0}
.sh h2{font-size:17px;margin:0;font-weight:600}
.sh .sub{color:var(--dim);font-size:13px;margin-top:1px}
.newbtn{background:var(--accent);border:0;color:#04122b;font:600 14px system-ui;
padding:11px 18px;border-radius:99px;cursor:pointer;flex:0 0 auto}
.newbtn:active{opacity:.8}
.newbtn:disabled{background:var(--card2);color:var(--dim);cursor:default}
.datehdr{color:var(--dim);font-size:12px;font-weight:600;letter-spacing:.05em;
text-transform:uppercase;margin:14px 0 7px}
ul{list-style:none;margin:0;padding:0}
li{background:var(--card);border:1px solid var(--line);border-radius:12px;
padding:14px;margin-bottom:8px;cursor:pointer;display:flex;
align-items:center;gap:12px}
li:active{background:var(--card2);border-color:var(--accent)}
li .nm{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;
white-space:nowrap;font-size:15px}
li .go{color:var(--accent);font-size:19px;flex:0 0 auto}
.none{color:var(--dim);font-size:14px;padding:16px;text-align:center;
border:1px dashed var(--line);border-radius:12px}
.toast{position:fixed;left:50%;bottom:calc(24px + env(safe-area-inset-bottom));
transform:translateX(-50%) translateY(80px);background:var(--ok);color:#06240f;
padding:13px 22px;border-radius:99px;font-weight:600;opacity:0;
transition:.25s;pointer-events:none;max-width:90vw;z-index:90}
.toast.show{transform:translateX(-50%);opacity:1}
.toast.err{background:#ff6b6b;color:#2a0000}
.bar2{height:3px;background:var(--card2);border-radius:2px;overflow:hidden;
margin-top:10px;display:none}
.bar2.show{display:block}
.bar2 span{display:block;height:100%;width:35%;background:var(--accent);
animation:slide 1.4s ease-in-out infinite}
@keyframes slide{0%{margin-left:-35%}100%{margin-left:100%}}
.off{position:fixed;inset:0;background:var(--bg);display:none;
flex-direction:column;align-items:center;justify-content:center;
text-align:center;padding:32px;z-index:50}
.off.show{display:flex}
.off h2{font-size:22px;margin:26px 0 10px;font-weight:600}
.off p{color:var(--dim);margin:0 0 26px;max-width:32ch;line-height:1.55}
.off button{background:var(--accent);border:0;color:#04122b;
font:600 16px system-ui;padding:14px 28px;border-radius:99px;cursor:pointer}
.off .hint{font-size:13px;color:#5d6478;margin-top:18px}
@keyframes blink{0%,45%{opacity:1}55%,100%{opacity:.15}}
@keyframes float{0%{transform:translateY(0) scale(.8);opacity:0}
25%{opacity:.9}100%{transform:translateY(-26px) scale(1.15);opacity:0}}
@keyframes sway{0%,100%{transform:rotate(-2deg)}50%{transform:rotate(2deg)}}
#led{animation:blink 1.6s ease-in-out infinite}
#box{animation:sway 4.5s ease-in-out infinite;transform-origin:50% 90%}
.z1{animation:float 2.8s ease-out infinite}
.z2{animation:float 2.8s ease-out .9s infinite}
.z3{animation:float 2.8s ease-out 1.8s infinite}

/* --- ALTTPR tracker: where have I been. Spoiler-free, never shows contents. */
/* One run per card, always stacked. Room is made by collapsing the runs
   you are not looking at - the header is the button. */
.trkh{margin:16px 14px 0;display:flex;align-items:center;gap:12px}
.trkh h2{margin:0;font-size:17px;font-weight:600;flex:1}
.trks{display:grid;gap:12px;margin:12px 14px 0;grid-template-columns:1fr}
/* Phone: the games below each other, as before. Desktop: side by side.
   ⚠️ The breakpoint follows the CONTENT, not a round number. The SMZ3 card
   has three mini maps in a row (.minis, max-width 637px); below ~1200px the
   column gets so narrow that they cramp, and one column is then better.
   align-items:start so the columns are not stretched to equal height. */
.spelrader{display:block}
@media (min-width:1200px){
  .spelrader{display:grid;grid-template-columns:1fr 1fr;gap:10px;
  align-items:start}
  .spel{min-width:0}          /* utan detta vagrar grid-kolumner krympa */
}
.trk .th{cursor:pointer;user-select:none;-webkit-user-select:none}
.trk .th .chev{margin-left:auto;color:var(--dim);font-size:13px;
transition:transform .15s;flex:0 0 auto}
.trk.min .th .chev{transform:rotate(-90deg)}
.trk.min .th{margin-bottom:0}
.trk.min .sync{margin-bottom:0;font-size:11.5px}
.trk.min .worlds,.trk.min .stats,.trk.min .sp,.trk.min .warn2{display:none}
/* The seed's skin. Purely cosmetic in the game, but here it is a memory
   hook: you recognise the squirrel, not "mykamxJmMQ". Only shown expanded.
   The image is 16x24 pixels - pixelated, or it turns into a blurry blob. */
.trk .skin{display:flex;align-items:center;gap:11px;margin-top:12px}
.trk .skin img{width:48px;height:72px;image-rendering:pixelated;
flex:0 0 auto;background:var(--card2);border:1px solid var(--line);
border-radius:9px;padding:5px;object-fit:contain}
/* The Samus cell out of the sprite strip. Same size and scaling as
   samus.link: 16x24 per cell, background scaled down to 24px height. */
.trk .skin .sam{width:48px;height:72px;flex:0 0 auto;display:block;
background-repeat:no-repeat;background-size:auto 72px;
image-rendering:pixelated;background-color:var(--card2);
border:1px solid var(--line);border-radius:9px}
.trk .skin b{font-size:13px;font-weight:600;display:block}
.trk .skin s{display:block;text-decoration:none;color:var(--dim);
font-size:11.5px;margin-top:2px}
.trk.min .skin{display:none}
/* The SMZ3 card equivalents: the map row and the ammunition counters. */
.trk.min .minis,.trk.min .smstat{display:none}
/* There used to be a separate "Show map" button here. It is gone: it was
   a SECOND control for what the header already did, and it took 48 px in
   the minimised state - a minimised ALTTP card came to 127 px against the
   SMZ3 card's 79. Both card types now collapse the same way, by tapping
   anywhere in the header or the sync row. The "x/y cleared" counter moved
   into the sync row so it stays visible when collapsed. */
.trk .th,.trk .sync{cursor:pointer}
.trk .sync b{color:var(--fg);font-weight:600}
.trk .th:active .chev,.trk .sync:active{color:var(--accent)}
.trk{margin:0;background:var(--card);border:1px solid var(--line);
border-radius:16px;padding:16px;display:none}
.trk.show{display:block}
.trk .th{display:flex;align-items:baseline;gap:9px;margin-bottom:3px}
.trk h2{margin:0;font-size:15px;font-weight:600}
.trk .sid{color:var(--dim);font-size:12px;
font-family:ui-monospace,SFMono-Regular,Menlo,monospace}
/* ⚠️ NO margin-left:auto here. It pushed Start and the wastebasket all
   the way right, far from the seed id they belong to. The chevron (and
   'Hide') keep their auto and stay where they should. */
.trk .th .play{margin-left:0}
.trk .del{background:none;border:0;color:#ff6b6b;font-size:15px;
cursor:pointer;padding:2px 4px;flex:0 0 auto}
.pick .danger{background:#ff6b6b;color:#2a0000}
/* SMZ3 contains two games, so the card shows both as thumbnails side by
   side. A tap enlarges; from there you click on - a dot in Zelda, an area
   in Metroid. */
/* Three maps in a row, but the same size as the ALTTP card's two. The
   width cap is that calculation run backwards: ALTTP's cells come to
   (420-14)/2 = 203px, so three of those with two gaps is
   3*203 + 2*14 = 637px. The maps then look equally large on both card
   types even though the row is wider. */
.minis{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;
margin-top:12px;max-width:637px}
.mini{background:var(--card2);border:1px solid var(--line);border-radius:10px;
overflow:hidden;cursor:pointer;padding:0;color:inherit;font:inherit;
text-align:left}
.mini:active{border-color:var(--accent)}
.mini .bild{background:#0a0b0f center/100% 100% no-repeat;position:relative}
.mini .bild::before{content:"";display:block;padding-top:100%}
.mini .txt{padding:6px 8px;font-size:11px;font-weight:600}
.mini .txt s{display:block;text-decoration:none;color:var(--dim);
font-weight:400;font-variant-numeric:tabular-nums}
/* SMZ3: Zebes as an overview, six areas that can each be opened. */
.zeb{position:relative;border-radius:8px;overflow:hidden;margin-top:12px;
background:#0a0b0f center/100% 100% no-repeat}
.zeb::before{content:"";display:block;padding-top:102.1%}
/* Area markers on the world map - the same language as the dungeon labels. */
.zeb u{position:absolute;transform:translate(-50%,-50%);cursor:pointer;
background:rgba(10,11,15,.88);border:1px solid var(--accent);color:var(--fg);
font:600 9px/1.15 ui-monospace,monospace;padding:3px 5px;border-radius:5px;
text-decoration:none;white-space:nowrap;text-align:center}
.zeb u:active{border-color:var(--fg)}
.zeb u.klar{border-color:var(--line);color:var(--dim);opacity:.6}
.zeb u i{display:block;font-style:normal;font-size:8px;color:var(--dim)}
.areas{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin-top:12px}
.area{background:var(--card2);border:1px solid var(--line);border-radius:11px;
padding:10px 12px;cursor:pointer;text-align:left;color:var(--fg);font:inherit}
.area:active{border-color:var(--accent)}
.area b{display:block;font-size:13.5px;font-weight:600}
.area s{display:block;text-decoration:none;font-size:11.5px;color:var(--dim);
margin-top:2px;font-variant-numeric:tabular-nums}
.area.klar{opacity:.5}
.area.klar b{color:var(--dim)}
.smstat{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:12px;
text-align:center}
.smstat div{font-size:11.5px;color:var(--dim)}
.smstat em{display:block;font-style:normal;font-size:17px;font-weight:600;
color:var(--fg);margin-bottom:2px}
/* The information box behind a map dot. */
#info .need{display:flex;flex-wrap:wrap;gap:6px;margin:2px 0 4px}
#info .need b{background:var(--card2);border:1px solid var(--line);
border-radius:999px;padding:5px 11px;font-size:12.5px;font-weight:600}
#info .need b.or{border-color:var(--accent);color:var(--accent)}
/* A requirement that can be met in more than one way: the chips are held
   together in a group with a small "or" between them, so it is visible
   that they belong to the SAME slot in the combination and are not two
   separate requirements. */
#info .need .grp{display:flex;align-items:center;gap:6px;flex-wrap:wrap;
background:var(--card2);border:1px dashed var(--accent);border-radius:999px;
padding:3px 5px}
#info .need .grp b{background:transparent;border-color:transparent;
color:var(--accent);padding:2px 6px}
#info .need .grp i{font-style:normal;font-size:10.5px;color:var(--dim);
text-transform:uppercase;letter-spacing:.05em}
#info .lbl{font-size:11px;color:var(--dim);font-weight:600;
letter-spacing:.06em;text-transform:uppercase;margin:12px 0 6px}
#info .ok{color:var(--ok);font-size:13.5px}
#info .warn{color:var(--dim);font-size:13px;line-height:1.5}
#info .chests{background:var(--card2);border-radius:10px;padding:9px 12px;
max-height:38vh;overflow:auto}
#info .chests div{padding:3px 0;font-size:13.5px}
#info .chests div.lock{color:var(--dim)}
/* Bosses cannot be read from the save file, so they get a shape of their
   own rather than borrowing the item dots' colours and claiming something
   we do not know. */
.pts b.boss:not(.tap){background:#ffb454;border-radius:2px;
transform:rotate(45deg);box-shadow:0 0 0 1px rgba(0,0,0,.6)}
.pts b.tap.boss::after{background:#ffb454;border-radius:2px;
transform:rotate(45deg);box-shadow:0 0 0 1px rgba(0,0,0,.6)}
#info .chests s{color:#ff6b6b;text-decoration:none;font-size:11px}
#info .foot2{margin-top:16px}
#info .setrw{width:100%;background:var(--card2);border:1px solid var(--line);
color:var(--fg);font:600 14px system-ui;padding:12px;border-radius:11px;
cursor:pointer}
#info .setrw:active{border-color:var(--accent);color:var(--accent)}
/* The row is no longer a counter - the arrow shows that it opens something. */
.pick .files{background:var(--card2);border-radius:10px;padding:11px 12px;
margin:10px 0;font:12px ui-monospace,monospace;color:var(--dim);
max-height:30vh;overflow:auto}
.pick .files div{padding:2px 0}
.trk .play{background:var(--accent);border:0;color:#04122b;font:600 12px system-ui;
padding:7px 13px;border-radius:99px;cursor:pointer;margin-left:6px;flex:0 0 auto}
.sp{margin-top:14px;padding-top:12px;border-top:1px solid var(--line)}
.sp>b{font-size:11px;color:var(--dim);font-weight:600;letter-spacing:.06em;
text-transform:uppercase;cursor:pointer;display:block}
.sp .box{display:none;margin-top:10px}
.sp.open .box{display:block}
.sp input{width:100%;padding:11px 12px;font-size:15px;border-radius:11px;
border:1px solid var(--line);background:var(--card2);color:var(--fg)}
.sp .warn2{color:#ffb454;font-size:11.5px;margin:8px 0 0;line-height:1.45}
.sp ul{margin:9px 0 0}
.sp li{display:block;padding:9px 11px;font-size:13px;cursor:default}
.sp li s{color:var(--dim);text-decoration:none;font-size:11.5px;display:block}
/* The spoiler counter. Sits in the header so it shows without expanding. */
.sp>b .cnt{font-style:normal;background:var(--card2);border:1px solid var(--line);
border-radius:999px;padding:1px 8px;margin-left:7px;font-size:10.5px;
letter-spacing:0}
.sp>b .cnt.nog{border-color:#ffb454;color:#ffb454}
/* Choosing what you are searching for. Without it the server cannot tell
   whether "Hammer" is an item or a location - and the list must not give
   that away. */
.sp .lage{display:flex;gap:6px;margin-bottom:9px}
.sp .lage button{flex:1;padding:8px 10px;font-size:12.5px;font-weight:600;
border-radius:10px;border:1px solid var(--line);background:var(--card2);
color:var(--dim);cursor:pointer}
.sp .lage button.pa{border-color:var(--accent);color:var(--accent)}
.sp li.val{cursor:pointer;border-radius:10px}
.sp li.val:hover{background:var(--card2)}
.sp li.sedd::after{content:'✓ revealed';color:var(--ok);font-size:11px;
float:right;font-weight:600}
/* The confirmation step - nothing is revealed before this. */
.sp .konf{margin:9px 0 0;padding:11px;border-radius:11px;
background:var(--card2);border:1px dashed #ffb454}
.sp .konf p{margin:0 0 9px;font-size:13px;line-height:1.45}
.sp .konf .rad{display:flex;gap:8px}
.sp .konf button{flex:1;padding:9px;border-radius:10px;font-size:13px;
font-weight:600;cursor:pointer;border:1px solid var(--line);
background:var(--card);color:var(--fg)}
.sp .konf button.ja{border-color:#ffb454;color:#ffb454}
.sp .svar{margin:9px 0 0;padding:11px;border-radius:11px;
background:var(--card2);border:1px solid var(--ok)}
.sp .svar li{padding:5px 0}
/* Already revealed. Shown when the search field is empty, so you do not
   have to look the same thing up again and wonder whether you already
   peeked. Those answers are already paid for. */
.sp .logg{margin:9px 0 0}
.sp .logg .rub{font-size:11px;color:var(--dim);font-weight:600;
letter-spacing:.06em;text-transform:uppercase;margin:0 0 6px}
.sp .logg li{display:block;padding:7px 11px;font-size:12.5px;
border-radius:10px;background:var(--card2);margin-bottom:5px}
.sp .logg li em{font-style:normal;color:var(--dim);font-size:11px;
margin-right:6px}
.sp .logg li b{color:var(--ok);font-weight:600}
.trk .sync .klar{color:var(--ok);font-weight:700}
.sp .svar b{font-size:13.5px;color:var(--ok)}
.trk .sync{color:var(--dim);font-size:12px;line-height:1.45;margin-bottom:15px}
.trk .worlds{display:grid;grid-template-columns:1fr 1fr;gap:14px;
max-width:420px}
/* Thumbnail: the dots read as colour clusters but cannot be hit - the
   whole box opens full screen, where they are usable. */
.trk .wl .mapwrap{cursor:pointer}
.trk .wl .pts b,.trk .wl .marks u{pointer-events:none}
/* The mini map answers a single question: WHERE can I do something right
   now. Only the green ones are therefore shown, and small - everything
   else (cleared, red, and the groups' number labels) belongs in full
   screen, where there is room to read them. A group becomes an ordinary
   dot like any other here.
   ⚠️ Overrides both .pts b.tap.can::after and .pts b.grp.can::after, so
   everything they set has to be reset: content, size, transform, border,
   padding and the halo. */
/* ⚠️ Applies ONLY to the thumbnails - the ALTTP card's .wl and the SMZ3
   card's .mini. Full screen sits under .zbody and is untouched: there
   everything is shown, at full size, with groups and dungeons as number
   labels. Here only what is reachable is shown, and everything becomes the
   same small dot - single location, group and dungeon alike. */
/* ⚠️ `.mini .bild` and not just `.mini`: one more class is needed to
   outweigh `.pts b.grp.can::after`. At EQUAL specificity the rule that
   comes last in the file wins, and the badge rule does - which turned the
   group dots into rectangular label frames instead of dots. */
.trk .wl .pts b,.mini .bild .pts b,
.trk .wl .marks u,.mini .bild .marks u{display:none}
.trk .wl .pts b.can,.mini .bild .pts b.can,
.trk .wl .marks u.can,.mini .bild .marks u.can{display:block;
position:absolute;width:9px;height:9px;margin:-4.5px 0 0 -4.5px;
background:none;border:0;padding:0;box-shadow:none;transform:none;
border-radius:0;font-size:0}
/* The dot itself. Has to reset everything the badge and label rules set:
   content, size, transform, border, padding and the halo. */
.trk .wl .pts b.can::after,.mini .bild .pts b.can::after,
.trk .wl .marks u.can::after,.mini .bild .marks u.can::after{content:"";
position:absolute;left:50%;top:50%;width:4px;height:4px;
margin:-2px 0 0 -2px;transform:none;border:0;padding:0;opacity:1;
border-radius:50%;background:var(--ok);
box-shadow:0 0 0 1px rgba(0,0,0,.5),0 0 3px 1px rgba(61,220,132,.7)}
.mini .bild .pts,.mini .bild .marks{position:absolute;inset:0;
pointer-events:none}
.trk .wl .zbtn{display:none}
.trk .wl .n2{text-align:center;font-size:11px;color:var(--dim);margin-top:5px;
font-variant-numeric:tabular-nums}
.trk .wl h3{margin:0 0 8px;font-size:11px;font-weight:600;color:var(--dim);
letter-spacing:.06em;text-transform:uppercase;text-align:center}
/* One dot per marked location. Green = picked up, grey = still there.
   (Red for unreachable comes later.) */
.map{aspect-ratio:1}
.pts{position:absolute;inset:0;pointer-events:none}
.pts b{position:absolute;width:7px;height:7px;margin:-3.5px 0 0 -3.5px;
border-radius:50%;background:#8b93a7;display:block;
box-shadow:0 0 0 1px rgba(0,0,0,.65)}
/* The colours answer "what can I do now", not "what have I done":
   green = open to collect, red = unreachable, grey = already empty. */
/* :not(.tap) - otherwise the whole 22px tap target is painted, not the
   dot. That was why the red ones looked like they had an aura behind
   them. */
.pts b.can:not(.tap){background:var(--ok);box-shadow:0 0 0 1px rgba(0,0,0,.5),0 0 5px 3px rgba(61,220,132,.95),0 0 13px 6px rgba(61,220,132,.45)}
/* :not(.tap) so the opacity does not stack - clickable dots are dimmed on
   their ::after instead, or 0.35 x 0.35 becomes nearly invisible. */
.pts b.done:not(.tap){background:var(--dim);opacity:.35}
/* Locations that cannot be derived can be ticked off by hand. The hit
   area is 22px so a thumb can land on it, while the dot stays 7px. */
.pts b.tap{width:22px;height:22px;margin:-11px 0 0 -11px;background:none;
box-shadow:none;pointer-events:auto;cursor:pointer}
.pts b.tap::after{content:"";position:absolute;left:50%;top:50%;
width:7px;height:7px;margin:-3.5px 0 0 -3.5px;border-radius:50%;
background:#8b93a7;box-shadow:0 0 0 1px rgba(0,0,0,.65)}
/* Green halo: what you CAN do now should pull the eye. */
.pts b.tap.can::after{background:var(--ok);
box-shadow:0 0 0 1px rgba(0,0,0,.5),0 0 5px 3px rgba(61,220,132,.95),0 0 13px 6px rgba(61,220,132,.45)}
.pts b.tap.done::after{background:var(--dim);opacity:.35}
.pts b.tap:active::after{transform:scale(1.5)}
/* Groups with several chests get a small number label instead of a dot. */
.pts b.grp::after{width:auto;height:auto;margin:0;left:50%;top:50%;
transform:translate(-50%,-50%);content:attr(data-n);border-radius:4px;
background:rgba(10,11,15,.86);border:1px solid #8b93a7;color:var(--fg);
font:600 8.5px/1 ui-monospace,monospace;padding:2.5px 3.5px;
box-shadow:none;white-space:nowrap}
/* The group labels ("2/5") get the same halo as the individual dots. */
.pts b.grp.can::after{border-color:var(--ok);color:var(--ok);
box-shadow:0 0 5px 1px rgba(61,220,132,.85),0 0 13px 4px rgba(61,220,132,.4)}
.pts b.grp.done::after{border-color:var(--dim);color:var(--dim);opacity:.5}
.pts b.grp.part::after{border-color:var(--accent);color:var(--accent)}
.pts b.grp:active::after{transform:translate(-50%,-50%) scale(1.25)}
/* The labels should take up the same PROPORTION of the map on a phone as
   on a desktop. The map is ~430 px wide there against ~1020 on a desktop,
   so a fixed 8.5 px came out more than twice as large relative to the map.
   The scale is set by JS on .mapwrap (--eskala); without it 1 applies, so
   the desktop is unchanged.

   ⚠️ SCALED WITH TRANSFORM, not with font-size. The first attempt
   recalculated the font size to 3.6 px - measured in the emulator that was
   exact, but on a real phone the text was still too big. Real phones have
   a MINIMUM font size (and the system's text enlargement on top of that),
   so 3.6 px renders larger than it says. No such setting can touch a
   transform: it scales the finished, rendered box.

   ⚠️ translate() FIRST, scale() LAST, and transform-origin set to the edge
   the badge should stay anchored to. The first attempt had scale first -
   the badge then drifts and ended up outside the map on BOTH devices
   (Wrecked Ship to 108 % on the phone, 106 % on the desktop). With the
   origin at the anchoring edge the box scales towards that edge and stays
   put. */
.zbody .mapwrap{--eskala:1;--pskala:max(0.5,var(--eskala))}
/* The dots in FULL SCREEN shrink on a phone. ⚠️ Floor at 0.5: the wanted
   result was "roughly 50 %", and raw --eskala would have given 42 % - too
   small. On a desktop --eskala is 1, so max() gives 1 and nothing changes
   there.
   ⚠️ Scoped to .zbody. The mini maps on the cards have their own size
   (9 px) and must not move. */
.zbody .pts b.tap::after{transform:scale(var(--pskala))}
.zbody .pts b.tap:active::after{transform:scale(calc(var(--pskala)*1.5))}
.zbody .marks u{transform-origin:50% 50%;
  transform:translate(-50%,-50%) scale(var(--eskala))}
.zbody .marks u.hoger{transform-origin:100% 50%;
  transform:translate(-100%,-50%) scale(var(--eskala))}
.zbody .marks u.vanster{transform-origin:0 50%;
  transform:translate(0,-50%) scale(var(--eskala))}
.zbody .pts b.grp::after{transform-origin:50% 50%;
  transform:translate(-50%,-50%) scale(var(--eskala))}
.zbody .pts b.grp:active::after{
  transform:translate(-50%,-50%) scale(calc(var(--eskala)*1.25))}
/* Unreachable with the current items. Duller than the others: the
   location is not uninteresting, it is just not your turn yet. */
.pts b.no:not(.tap){background:#ff6b6b;opacity:.7}
.pts b.tap.no::after{background:#ff6b6b}
.pts b.grp.no::after{border-color:#ff6b6b;color:#ff6b6b;background:rgba(10,11,15,.86)}
/* Optional map image behind the grid. Place it as /local/alttp-lw.png and
   -dw.png next to the page; if it is missing everything falls back to the
   grid. The overworld is 8x8 screens, so a complete map lines up 1:1. */
/* The wrapper clips, the map inside scales. touch-action:none so the
   browser does not take the gesture over and scroll the page instead. */
/* Two modes. Normal: a tap opens chests and the page scrolls as usual.
   Zoom mode: pinch and drag control the map, a tap opens nothing. One
   finger cannot mean both things, so a button keeps the modes apart. */
.mapwrap{position:relative;overflow:hidden;border-radius:6px}
/* Full-screen view: the map gets the whole area instead of half a card. */
.zoomov{position:fixed;inset:0;background:var(--bg);z-index:70;display:none;
flex-direction:column}
.zoomov.show{display:flex}
.zhead{display:flex;align-items:center;gap:10px;padding:
calc(10px + env(safe-area-inset-top)) 14px 10px;border-bottom:1px solid var(--line)}
.zhead b{flex:1;font-size:15px;font-weight:600}
.zclose{background:var(--card2);border:1px solid var(--line);color:var(--fg);
font:600 13px system-ui;padding:9px 14px;border-radius:99px;cursor:pointer}
.zbody{flex:1;overflow:hidden;display:flex;align-items:center;
justify-content:center;padding:0 0 env(safe-area-inset-bottom)}
/* The overworld is 8x8 screens, so square. Without aspect-ratio the image
   was stretched to fill the box. The square is allowed to grow to the
   smaller of width and height, so it always fits completely. */
/* Which dimension should lead depends on the shape of the screen, and CSS
   cannot pick the smaller of two unknown measurements in a single rule:
   set both width and max-height and one of them wins, squashing the
   square. So we switch on orientation instead.
     portrait  -> width leads, height follows
     landscape -> height leads, width follows */
.zbody .mapwrap{position:relative;border-radius:0;touch-action:none;
aspect-ratio:1;flex:0 0 auto}
/* aspect-ratio is set per map in JS - ALTTP is 1:1, Metroid's areas are
   not. The rule below only picks WHICH dimension is allowed to lead. */
@media (orientation:portrait){
  .zbody .mapwrap{width:100%;height:auto;max-height:100%}
}
@media (orientation:landscape){
  .zbody .mapwrap{height:100%;width:auto;max-width:100%}
}
/* ⚠️ A rule `.zbody .mapwrap[style*="aspect-ratio"]` without a media
   query used to sit here. It forced the width to 100% in LANDSCAPE too,
   while max-height capped the height - the proportion then cannot hold,
   and background-size:100% 100% stretched the map. It only hit maps with
   an inline aspect-ratio, that is SMZ3's two; ALTTP's full screen lacks
   that attribute and therefore looked right.
   The declarations were also identical to the portrait rule above, so the
   rule added nothing in portrait either. Removed. */
.zbody .map{width:100%;height:100%;background-size:100% 100%}
.zbtn{position:absolute;right:5px;top:5px;z-index:3;width:30px;height:30px;
border-radius:8px;border:1px solid var(--line);background:rgba(10,11,15,.82);
color:var(--dim);font-size:14px;line-height:1;cursor:pointer;padding:0}
/* NOT will-change:transform - the browser then rasterises the map once at
   1x and scales the finished bitmap when zooming, so everything goes
   blurry however sharp the source image is. Without it the map is
   re-rasterised at the new scale. */
.map{position:relative;transform-origin:0 0;border-radius:6px;overflow:hidden;
background-size:100% 100%;background-position:center}
.map.img .grid{gap:0}
.map.img .grid b{border-radius:0;background:rgba(10,11,15,.72);
box-shadow:inset 0 0 0 1px rgba(255,255,255,.05)}
.map.img .grid b.on{background:rgba(91,157,255,.12);
box-shadow:inset 0 0 0 1px rgba(91,157,255,.55)}
.trk .stats{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;
margin-top:16px;padding-top:14px;border-top:1px solid var(--line);
text-align:center}
.trk .stats div{font-size:11.5px;color:var(--dim)}
.trk .stats em{display:block;font-style:normal;font-size:19px;
font-weight:600;color:var(--fg);margin-bottom:2px}
.trk .warn{color:#ffb454}
/* Collapsed state: the card is hidden when the run is not current, but can
   always be clicked back. It should never feel like the data is gone. */
.trk.stub{padding:0;background:none;border:0}
.stubrow{display:flex;align-items:center;gap:10px;background:var(--card);
border:1px solid var(--line);border-radius:14px;padding:13px 15px;
cursor:pointer;font-size:13px;color:var(--dim)}
.stubrow span{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.stubrow b{color:var(--accent);font-weight:600;font-size:13px;flex:0 0 auto}
.trk .hide{margin-left:auto;color:var(--dim);font-size:12px;cursor:pointer;
padding:2px 6px}
/* Dungeon labels on top of the map: "Y/X" where the dungeon sits. The
   position comes from your own markers and is seed-independent. */
.marks{position:absolute;inset:0;pointer-events:none}
/* ⚠️ The badge is centred on its point and grows in both directions. If
   the point sits near an edge, half the badge sticks out past the map -
   and it grows further when the area's reward is written out, so the
   problem comes and goes with game data. The fix is to grow INWARDS:
   markers at the right edge are right-aligned, markers at the left edge
   left-aligned. They can then never end up outside, however long the text
   gets. */
.marks u.hoger{transform:translate(-100%,-50%)}
.marks u.vanster{transform:translate(0,-50%)}
.marks u{position:absolute;transform:translate(-50%,-50%);
background:rgba(10,11,15,.86);border:1px solid var(--accent);
color:var(--fg);font:600 8.5px/1 ui-monospace,monospace;
padding:2.5px 3.5px;border-radius:4px;text-decoration:none;white-space:nowrap}
.marks u.unk{border-color:var(--line);color:var(--dim)}
.marks u.tapd{pointer-events:auto;cursor:pointer}
.marks u.tapd:active{border-color:var(--fg)}
/* The same language as the map dots: green = everything left is
   reachable, blue = some but not all, red = none, grey = finished. */
/* The same halo as the dots: what you can do now should pull the eye. */
.marks u.can{border-color:var(--ok);color:var(--ok);
box-shadow:0 0 5px 1px rgba(61,220,132,.85),0 0 13px 4px rgba(61,220,132,.4)}
/* Light blue (only the big key is missing) gets a fainter glow - closer to
   done than "partly closed", but not as inviting as fully open. */
.marks u.bigkey{box-shadow:0 0 5px 1px rgba(142,203,255,.5)}
.marks u.part{border-color:var(--accent);color:var(--accent)}
/* Light blue: everything except the big key chest is reachable. Lighter
   than .part so that "only the key is missing" reads as closer to done
   than "partly closed". */
.marks u.bigkey{border-color:#8ecbff;color:#8ecbff}
.marks u.bigkey i{color:#8ecbff}
.marks u.no{border-color:#ff6b6b;color:#ff6b6b}
.marks u.done{border-color:var(--line);color:var(--dim);opacity:.55}
/* The reward on its own line under the counter, so the label does not turn into a long strip. */
.marks u i{display:block;font-style:normal;font-size:7.5px;
color:var(--accent);margin-top:1px;letter-spacing:.02em}
.marks u.can i{color:var(--ok)}
.marks u.no i{color:#ff6b6b}
.marks u.done i{color:var(--dim)}
/* Boss + beloning. SEED-specifikt, till skillnad fran kartmarkeringarna. */
.pick{position:fixed;inset:0;background:rgba(10,11,15,.75);display:none;
align-items:flex-end;justify-content:center;z-index:80}
.pick.show{display:flex}
.pick .box{background:var(--card);border-top-left-radius:20px;
border-top-right-radius:20px;padding:20px 18px calc(22px + env(safe-area-inset-bottom));
width:100%;max-width:520px;max-height:82vh;overflow-y:auto}
.pick h2{margin:0 0 4px;font-size:17px;font-weight:600}
.pick .sub{color:var(--dim);font-size:12.5px;margin-bottom:16px}
.pick .medh{margin:2px 0 8px;font-size:11px;color:var(--dim);font-weight:600;letter-spacing:.06em;text-transform:uppercase}
.pick .opts{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.pick .opts button{background:var(--card2);border:1px solid var(--line);
color:var(--fg);border-radius:11px;padding:13px 9px;font:600 13px system-ui;
cursor:pointer;text-align:left}
.pick .opts button.on{border-color:var(--accent);color:var(--accent);
background:rgba(91,157,255,.12)}
.pick .foot{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-top:14px}
.pick .foot button{border:0;border-radius:12px;padding:14px;
font:600 14px system-ui;cursor:pointer}
.pick .clear{background:var(--card2);color:var(--dim)}
.pick .close{background:var(--accent);color:#04122b}
</style>
<header><div class="bar">
  <h1>Seeds</h1>
  <a class="cog" id="cog" target="_blank" rel="noopener"
     title="Mark locations and set requirements">⚙</a>
  <span class="now" id="now"><i></i><b></b></span>
</div></header>
<div class="spelrader">
<section class="spel">
<div class="trkh"><h2>Zelda: A Link to the Past Randomizer</h2><button class="newbtn" data-g="alttpr">New seed</button></div><div class="bar2" id="bar-ALTTPR"><span></span></div>
<div class="trks" id="trks"></div>
</section>
<section class="spel">
<div class="trkh" id="smz3h"><h2>Zelda + Metroid Combo</h2><button class="newbtn" data-g="smz3">New seed</button></div><div class="bar2" id="bar-SMZ3"><span></span></div>
<div class="trks" id="smz3"></div>
</section>
</div>
<div class="pick" id="pick"><div class="box">
  <h2 id="pkname">Dungeon</h2>
  <div class="sub" id="pksub">Which reward did it give? The boss is marked automatically.</div>
  <div id="pkmed"></div>
  <div class="opts" id="pkopts"></div>
  <div class="foot">
    <button class="clear" id="pkclear">Clear</button>
    <button class="close" id="pkclose">Done</button>
  </div>
</div></div>
<div class="pick" id="info"><div class="box">
  <h2 id="ifname">Location</h2>
  <div class="sub" id="ifsub"></div>
  <div id="ifbody"></div>
  <div class="foot"><button class="close" id="ifclose">Close</button></div>
</div></div>
<div class="zoomov" id="zoomov">
  <div class="zhead"><b id="zttl">Map</b>
    <button class="zclose" id="zclose">✕ Close</button></div>
  <div class="zbody" id="zbody"></div>
</div>
<main id="main"></main>
<div class="toast" id="toast"></div>

<div class="off" id="off">
  <svg width="190" height="150" viewBox="0 0 190 150" aria-hidden="true">
    <g class="z1"><text x="132" y="52" fill="#5b9dff" font-size="17"
       font-family="system-ui" font-weight="700">z</text></g>
    <g class="z2"><text x="146" y="42" fill="#5b9dff" font-size="21"
       font-family="system-ui" font-weight="700">z</text></g>
    <g class="z3"><text x="160" y="32" fill="#5b9dff" font-size="26"
       font-family="system-ui" font-weight="700">z</text></g>
    <g id="box">
      <rect x="26" y="62" width="118" height="62" rx="9"
            fill="#1c2029" stroke="#2c313d" stroke-width="2.5"/>
      <rect x="38" y="76" width="58" height="34" rx="5" fill="#12141a"/>
      <rect x="45" y="83" width="30" height="3.5" rx="1.75" fill="#2c313d"/>
      <rect x="45" y="92" width="44" height="3.5" rx="1.75" fill="#2c313d"/>
      <rect x="45" y="101" width="22" height="3.5" rx="1.75" fill="#2c313d"/>
      <circle id="led" cx="122" cy="93" r="7" fill="#ff6b6b"/>
      <rect x="52" y="124" width="66" height="7" rx="3.5" fill="#232833"/>
    </g>
  </svg>
  <h2>No contact with the MiSTer</h2>
  <p>Make sure the MiSTer FPGA is powered on and connected to the network.</p>
  <button id="retry">Try again</button>
  <div class="hint" id="hint">Retrying automatically every five seconds…</div>
</div>

<script>
const API=window.MISTER_API||'';
const M=document.getElementById('main'),TO=document.getElementById('toast'),
OFF=document.getElementById('off'),NOW=document.getElementById('now');
let groups=[],offline=false,retryTimer=null,poll=null;

function esc(s){return String(s).replace(/[&<>"]/g,
  c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
function toast(m,e){TO.textContent=m;TO.className='toast show'+(e?' err':'');
  clearTimeout(TO._t);TO._t=setTimeout(()=>TO.className='toast',2800);}

async function api(path,opts){
  try{
    const r=await fetch(API+path,Object.assign({cache:'no-store'},opts||{}));
    if(!r.ok&&r.status>=500)throw new Error('HTTP '+r.status);
    online();return r;
  }catch(e){goOffline();throw e;}
}
function goOffline(){if(offline)return;offline=true;OFF.classList.add('show');
  clearInterval(retryTimer);retryTimer=setInterval(ping,5000);}
function online(){if(!offline)return;offline=false;OFF.classList.remove('show');
  clearInterval(retryTimer);retryTimer=null;}
async function ping(){try{const r=await fetch(API+'api/seedgroups',
  {cache:'no-store'});if(r.ok){online();load();}}catch(e){}}
document.getElementById('retry').onclick=()=>ping();

/* The server sends {path, date, mtime} and has already sorted newest
   first. Here the name is only shortened down to the part that says
   something: "alttpr - NoGlitches-open-ganon_DvxnVXQ6Ga" -> "DvxnVXQ6Ga" */
function parse(s){
  const parts=s.path.split('/');
  const file=parts[parts.length-1].replace(/\.[^.]+$/,'');
  let name=file;
  let m=file.match(/_([A-Za-z0-9]+)$/);            // alttpr-hash
  if(m)name=m[1];
  m=file.match(/^SMZ3-v?[\d.]+-(\d+)$/i);          // smz3
  if(m)name='Seed '+m[1];
  return {date:s.date,name:name,path:s.path,mtime:s.mtime};
}

function dateLabel(d){
  const t=new Date(),y=new Date(Date.now()-864e5);
  const iso=x=>x.getFullYear()+'-'+String(x.getMonth()+1).padStart(2,'0')+
    '-'+String(x.getDate()).padStart(2,'0');
  if(d===iso(t))return 'Today';
  if(d===iso(y))return 'Yesterday';
  return d;
}

async function load(){
  let r;try{r=await api('api/seedgroups')}catch(e){return}
  groups=await r.json();
  // SMZ3 gets cards of its own - launch only, no map. The save format is
  // a structure of its own (measured 2026-08-08), so there is no SRAM to
  // read yet.
  // The SMZ3 cards are drawn by drawSMZ3() - the old code here wrote into
  // the same container and wiped it out. An error there also aborted the
  // whole of load(), so the seed list was never drawn.
  M.innerHTML=groups.filter(g=>g.id!=='ALTTPR'&&g.id!=='SMZ3').map(g=>{
    const seeds=g.games.map(parse);
    // The server order is already newest first - keep it, and let
    // the date headings follow in the same order.
    const byDate={},dates=[];
    seeds.forEach(s=>{
      if(!byDate[s.date]){byDate[s.date]=[];dates.push(s.date);}
      byDate[s.date].push(s);
    });
    const list=dates.map(d=>`<div class="datehdr">${esc(dateLabel(d))}</div><ul>`+
      byDate[d].map(s=>`<li data-c="${esc(g.id)}" data-p="${encodeURIComponent(s.path)}">
        <span class="nm">${esc(s.name)}</span><span class="go">&rsaquo;</span></li>`).join('')+
      '</ul>').join('');
    return `<section>
      <div class="sh"><div class="ic">${g.icon}</div>
        <div class="tx"><h2>${esc(g.name)}</h2>
          <div class="sub">${g.count} ${g.count===1?'seed':'seeds'}</div></div>
        <button class="newbtn" data-g="${esc(g.gen)}"${g.gen?'':' disabled'}>New seed</button>
      </div>
      <div class="bar2" id="bar-${esc(g.id)}"><span></span></div>
      ${seeds.length?list:'<div class="none">No seeds yet – press "New seed"</div>'}
    </section>`;}).join('');
  M.querySelectorAll('li').forEach(e=>e.onclick=()=>
    go(e.dataset.c,decodeURIComponent(e.dataset.p)));
  M.querySelectorAll('.newbtn').forEach(e=>e.onclick=()=>gen(e.dataset.g));
  checkGen();
}

async function go(core,path){
  toast('Starting…');
  try{
    const r=await api('api/launch',{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({core:core,path:path})});
    const d=await r.json();toast(d.message,!d.ok);
  }catch(e){}
}

function busy(b){
  document.querySelectorAll('.newbtn').forEach(e=>e.disabled=b||!e.dataset.g);
  document.querySelectorAll('.bar2').forEach(e=>e.classList.toggle('show',b));
}
async function gen(kind){
  if(!kind)return;
  busy(true);toast('Generating…');
  try{
    const r=await api('api/generate',{method:'POST',
      headers:{'Content-Type':'application/json'},body:JSON.stringify({kind:kind})});
    const d=await r.json();
    if(!d.ok){busy(false);return toast(d.message,true)}
    clearInterval(poll);poll=setInterval(checkGen,2500);
  }catch(e){busy(false)}
}
async function checkGen(){
  let d;try{d=await(await api('api/genstatus')).json()}catch(e){return}
  if(d.running){busy(true);return}
  busy(false);
  if(poll){clearInterval(poll);poll=null;
    if(d.done)toast(d.message,!d.ok);
    load();}
}

async function updateNow(){
  try{
    const d=await(await fetch(API+'api/status',{cache:'no-store'})).json();
    if(d.core&&d.core!=='MENU'){NOW.querySelector('b').textContent=d.name||d.core;
      NOW.classList.add('show');}
    else NOW.classList.remove('show');
  }catch(e){NOW.classList.remove('show');}
}
/* The tracker shows where you have been in your ALTTPR run - screens and
   rooms visited, never what was there, so the spoiler stays intact. The
   save file is only written when the OSD is opened, which is why the sync
   time is prominent: a grey box means "not synced yet", not "have not been
   there". */
document.getElementById('cog').href=(API||'/')+'annotate';
const TRKS=document.getElementById('trks');let trkData=[];
/* Optional map image behind the grid: put alttp-lw.png / alttp-dw.png next
   to the page. We try to load it and only set the class once it has
   answered, so a missing image never leaves a broken box. */
const MAPIMG={};
function tryMap(which){
  if(MAPIMG[which]!==undefined)return;
  MAPIMG[which]=false;
  const im=new Image();
  im.onload=()=>{MAPIMG[which]='alttp-'+which+'.png';loadTracker()};
  im.src='alttp-'+which+'.png';
}
// Seeds that have not been played for a long time get no reachability
// logic - see FRESH_HOURS in server.py. Say so plainly, or a colourless map
// looks like a fault.
function staleNote(t){
  return t.fresh===false&&t.started
    ? '<div class="warn2">Idle run — the colours only show what has been cleared. '+
      'Open the OSD in the game and the logic is recalculated.</div>' : '';
}
// The dots are only built for the expanded card. ~120 absolutely
// positioned elements per seed is what costs, and it is pointless work for
// something nobody is looking at.
function worldsHTML(t,tom){
  const dg=tom?null:t.dungeons, pts=tom?null:t.points;
  const rakn=w=>alttpRakn({points:pts,dungeons:dg},w);
  return '<div class="wl" data-w="lw"><h3>Light World</h3>'+cells('lw',dg,pts)+
           '<div class="n2">'+rakn('lw')+'</div></div>'+
         '<div class="wl" data-w="dw"><h3>Dark World</h3>'+cells('dw',dg,pts)+
           '<div class="n2">'+rakn('dw')+'</div></div>';
}
function alttpRakn(t,w){
  const p=(t.points||[]).filter(x=>x.world===w);
  const d=(t.dungeons||[]).filter(x=>x.pos&&x.pos.world===w);
  if(!p.length&&!d.length)return '&nbsp;';
  const k=kistor(p,d);
  return k.open+' / '+k.total+' cleared';
}
function cells(which,dg,pts){
  const src=MAPIMG[which];
  const st=src?' style="background-image:url('+src+')"':'';
  let marks='';
  (dg||[]).forEach((d,di)=>{
    if(!d.pos||d.pos.world!==which)return;
    const f=d.found===null?0:d.found;
    const klar=d.boss_sram===true;
    // The reward stays on the map as long as the dungeon is not cleared -
    // afterwards it has been collected and is just noise.
    const rw=(d.reward&&!klar)?'<i>'+esc(d.reward)+'</i>':'';
    const st=d.state?' '+d.state:'';
    marks+='<u class="tapd'+st+'" data-dg="'+di+'"'+
      ' title="'+esc(d.name)+
      '" style="left:'+(d.pos.x*100)+'%;top:'+(d.pos.y*100)+'%">'+
      (klar?'✓ ':'')+f+'/'+d.chests+rw+'</u>';
  });
  let dots='';
  (pts||[]).forEach((p,ix)=>{
    if(p.world!==which)return;
    // Groups with several chests are shown as "2/5" instead of a dot, so
    // they can be hit even when the locations sit on top of each other.
    const many=p.total>1;
    let cls=many?'grp ':'';
    // The order is the meaning: a cleared location is done regardless of logic, then
    // avgor atkomsten. En prick utan asikt (reach===null, t.ex. om
    // the logic service is down) becomes neutral grey - not green, since
    // that would claim it is reachable without knowing.
    // state comes from the server and means the same as for dungeons:
    // done = all empty, can = everything left is reachable, part = some is,
    // no = none is. Blue therefore means "partly REACHABLE", not "partly
    // cleared" - a group whose remainder can be collected is green.
    if(p.state)cls+=p.state+' ';
    else if(p.open>=p.total)cls+='done ';
    else if(p.reach===false)cls+='no ';
    // Every dot is clickable, but the tap does not tick anything off - it
    // shows the location's name and which items are missing. Ticking off is
    // no longer needed: the chest flags are read exactly from the save.
    cls+='tap';
    dots+='<b class="'+cls+'" data-p="'+ix+'"'+
      (many?' data-n="'+p.open+'/'+p.total+'"':'')+
      ' title="'+esc(p.name)+(p.exact?' (read from the save file)':' (tap to tick off)')+
      '" style="left:'+(p.x*100)+'%;top:'+(p.y*100)+'%"></b>';
  });
  return '<div class="mapwrap"><button class="zbtn" type="button">🔍</button>'+
    '<div class="map'+(src?' img':'')+'"'+st+'>'+
    (dots?'<div class="pts">'+dots+'</div>':'')+
    (marks?'<div class="marks">'+marks+'</div>':'')+'</div></div>';
}
function ago(ts){
  const s=Math.max(0,Math.round(Date.now()/1000-ts));
  if(s<90)return 'nyss';
  if(s<5400)return Math.round(s/60)+' min ago';
  return Math.round(s/3600)+' h ago';
}
/* Chests per dungeon. The total (X) comes from the seed's own spoiler and
   is therefore always right - Ganons Tower varies between seeds. How many
   have been found needs the room -> dungeon mapping; without it "?/X" is
   shown rather than an invented zero. */

/* Boss + reward are filled in by you once you have cleared a dungeon.
   Reading it out of the spoiler would be spoiling - this is your own
   discovery. */
const PICK=$id('pick');let rewards=[],pkIx=null,pkData=[],pkSeed='',ptData=[];
// The information box behind a map dot. The same .pick dialog as the
// reward picker, but its own box - and it has to be looked up here.
// Without it every dot click throws a ReferenceError and the box opens
// aldrig, i bada kartorna.
const INFO=$id('info');

// --- SMZ3 -------------------------------------------------------------
const SMZ3=$id('smz3');
// The markers' position on the world map, as fractions of width/height. Estimated
// ur bilden - knut kan justera dem om nagon sitter snett.
// The markers are placed where there is empty space next to each label, so
// that no name is obscured. The side is decided by where the map ends:
//   Crateria, Brinstar  - fore texten (till vanster)
//   Wrecked Ship, Maridia - efter texten (till hoger)
//   Norfair             - ovanfor
//   Lower Norfair       - saknar egen text, laggs ovanfor bildtexten
// Adjusted 2026-08-12 on request: Norfair down, Wrecked Ship and
// Maridia at vanster.
// ⚠️ The position is the badge's CENTRE (transform:translate(-50%,-50%)),
// and the badge is ~11 % wide. That is why Wrecked Ship was clipped against
// the right edge at 0.945. The map is tight: there is no empty space to the
// left, so a move
// dit lagger badgen over kartans egna etiketter. Justerat i sma steg.
// The right and left edge values are now the badge's OUTER EDGE, not its
// mitt - se .marks u.hoger / .vanster. Marginal 1.5 % in fran kartkanten.
const SM_POS={Crateria:[0.015,0.029],Brinstar:[0.015,0.553],
  WreckedShip:[0.985,0.054],Maridia:[0.985,0.506],
  Norfair:[0.985,0.632],LowerNorfair:[0.545,0.932]};
let smData=[],smMin=[],smInit=false;
function smCard(t,ix){
  const m=t.metroid;
  const st=m?('<div class="smstat">'+smStatsInner(t)+'</div>'):'';
  const min=smMin.indexOf(t.seed)>=0;
  return '<div class="trk show'+(min?' min':'')+'" data-sm="'+ix+'">'+
    '<div class="th"><h2>Zelda + Metroid</h2>'+
    '<span class="sid">'+esc(t.seed||'?')+'</span>'+
    (t.rom?'<button class="play">Start</button>':'')+
    '<button class="del" title="Delete seed">🗑</button>'+
    '<span class="chev">▾</span></div>'+
    '<div class="sync">'+smSyncInner(t)+'</div>'+
    skinHTML(t)+
    '<div class="minis">'+
      mini(ix,'lw','alttp-lw.png','Light World',zrakn(t,'lw'),
           miniPrickar(t,'lw'))+
      mini(ix,'dw','alttp-dw.png','Dark World',zrakn(t,'dw'),
           miniPrickar(t,'dw'))+
      mini(ix,'sm','sm-world.webp','Zebes',
           m?(m.open+' / '+m.total):'',miniPrickar(t,'sm'))+
    '</div>'+st+
    spHTML(t)+
    '</div>';
}
// The seed's skin - the image lives on the MiSTer, not at alttpr.com, so it
// works even when the map is viewed without internet access.
function skinHTML(t){
  const s=t.skin||{};
  // SMZ3 has TWO looks. The Samus image is not a file of its own but a
  // en ruta i samus.links remsa (2752x48, native 32x48 per ruta).
  // The site shows it at 16x24 with background-size:auto 24px; we show it
  // three times as large, so auto 72px - and the cell is then 48px wide.
  // If the seed has its OWN cropped image, that wins. The cell number in
  // the shared strip is only a fallback: if the strip is replaced at
  // samus.link, old seeds' numbers point at the wrong cell and a neighbour
  // is shown instead of the right sprite. Own files cannot drift.
  const sam=s.samus_file
    ? '<i class="sam" style="background-image:url('+API+'api/skin?which=samus'+
      '&seed='+encodeURIComponent(t.seed||'')+');background-position:0 0"></i>'
    : (s.samus&&s.samus_index!=null)
    ? '<i class="sam" style="background-image:url('+API+'api/spritesheet);'+
      'background-position:-'+(48*s.samus_index)+'px 0"></i>' : '';
  return '<div class="skin"><img src="'+API+'api/skin?seed='+
    encodeURIComponent(t.seed||'')+'" alt="" width="48" height="72">'+sam+
    '<div><b>'+esc(s.name||'Link')+'</b><s>'+
    (s.default?'standardutseende':'av '+esc(s.author||'unknown'))+
    (s.samus?'<br>Samus: '+esc(s.samus)+
      (s.samus_author?' av '+esc(s.samus_author):''):'')+
    '</s></div></div>';
}
// The same counter the ALTTP card shows under each map.
function zrakn(t,vy){
  const m=t.metroid||{};
  const p=(m.zpoints||[]).filter(x=>x.world===vy);
  const d=(m.zdungeons||[]).filter(x=>x.pos&&x.pos.world===vy);
  if(!p.length&&!d.length)return '';
  const k=kistor(p,d);
  return k.open+' / '+k.total+' cleared';
}
function mini(ix,vy,bild,rubrik,under,prickar){
  return '<button class="mini" data-s="'+ix+'" data-v="'+vy+'">'+
    '<div class="bild" style="background-image:url(\''+bild+'\')">'+
    (prickar||'')+'</div>'+
    '<div class="txt">'+esc(rubrik)+'<s>'+esc(under||'&nbsp;')+'</s></div>'+
    '</button>';
}
let smPainted='';
function drawSMZ3(){
  if(!SMZ3)return;
  // The same here. The zoom view is updated anyway, so an open full-screen map
  // fortsatter fargas om.
  if(spoilerUpptagen(SMZ3)){uppdateraKartorPaKort();uppdateraZoom();return}
  // Collapse everything except the newest ONCE, on the first draw - not on
  // every update, or what the user expanded folds itself away again every
  // 30 seconds. The same solution as the ALTTP cards' trkInit.
  // ⚠️ MUST come BEFORE the signature: the block changes smMin, which is
  // part of it. Compute the signature first and it went stale in the same
  // breath - the next round saw a "new" structure and rebuilt the cards one
  // extra time.
  if(!smInit&&smData.length){smInit=true;
    smMin=smData.slice(1).map(x=>x.seed).filter(Boolean)}
  // ⚠️ Bara struktur - se noten i loadTracker. Utan detta byggdes alla
  // SMZ3-kort om var 30:e sekund.
  const sign=JSON.stringify(smData.map(t=>[t.seed,t.started,!!t.rom]))+'|'+
    smMin.join(',');
  if(sign===smPainted){uppdateraKartorPaKort();uppdateraZoom();return}
  smPainted=sign;
  SMZ3.innerHTML=smData.map(smCard).join('');
  SMZ3.querySelectorAll('.trk .th').forEach(th=>th.onclick=ev=>{
    // ⚠️ Bada knapparna maste undantas. Utan 'del' i listan fallde kortet
    // collapsed behind the confirmation box when the wastebasket was tapped.
    if(ev.target.classList.contains('play')
       || ev.target.classList.contains('del'))return;
    const card=th.parentNode;
    const t=smData[+card.dataset.sm]; if(!t)return;
    const at=smMin.indexOf(t.seed);
    if(at>=0)smMin.splice(at,1); else smMin.push(t.seed);
    card.classList.toggle('min',at<0);
  });
  SMZ3.querySelectorAll('.mini').forEach(e=>e.onclick=ev=>{
    ev.stopPropagation();
    const t=smData[+e.dataset.s]; if(!t)return;
    const v=e.dataset.v;
    if(v==='sm')openZebes(t); else openZeldaMap(t,v);
  });
  // ⚠️ Look the seed up via the card's data-sm, not via the button's
  // position. A card without a ROM gets no Start button, and the index then
  // points at the wrong seed - you would launch something other than what
  // you tapped.
  uppdateraZoom();
  SMZ3.querySelectorAll('.trk[data-sm]').forEach(kort=>{
    const t=smData[+kort.dataset.sm];
    if(t)bindSpoiler(kort,t.seed);
  });
  // The same confirmation box as the ALTTP cards - it lists the seed's
  // files and deletes via /api/delete_seed, which also cleans up the spoiler
  // log and the tick marks.
  SMZ3.querySelectorAll('.del').forEach(e=>e.onclick=ev=>{
    ev.stopPropagation();
    const kort=e.closest('.trk');
    const t=kort?smData[+kort.dataset.sm]:null; if(!t)return;
    askDelete(t.seed,t.seed);
  });
  SMZ3.querySelectorAll('.play').forEach(e=>e.onclick=async ev=>{
    ev.stopPropagation();
    const kort=e.closest('.trk');
    const t=kort?smData[+kort.dataset.sm]:null; if(!t||!t.rom)return;
    try{const r=await api('api/launch',{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({core:'SMZ3',path:t.rom})});
      const j=await r.json();toast(j.message,!j.ok)}catch(e){}
  });
}
// Fetches the SMZ3 seeds. They are not in the group list load() draws -
// that one filters SMZ3 out - so the cards need their own round to the API.
async function loadSMZ3(){
  if(!SMZ3)return;
  let d;
  try{d=await api('api/smz3').then(r=>r.json())}catch(e){return}
  smData=Array.isArray(d)?d:[];
  drawSMZ3();
}
// Prickarnas farg, samma fyra betydelser som pa ALTTP-kartan:
// gra = tomd, gron = gar att na, rod = last, ingen farg = logiken har
// ingen asikt (tjansten nere, eller en plats den inte kanner - bossarna
// har ingen bit i foremalsfaltet och far egen farg).
function ptCls(p){
  if(p.boss)return 'boss';
  // ⚠️ For en GRUPP ar open ett antal, inte ett ja/nej - "2 av 5 tomda"
  // ar sant men gruppen ar inte klar. Serverns state sager redan vad som
  // galler for grupper, sa den vinner nar den finns.
  if(p.state)return p.state;
  if(p.total>1?p.open>=p.total:p.open)return 'done';
  if(p.reach===false)return 'no';
  if(p.reach===true)return 'can';
  return '';
}
// Prickarna pa en miniatyr. Samma klasser som fullskarm - CSS:en avgor
// vad som faktiskt syns, sa logiken finns pa ett stalle.
function miniPrickar(t,vy){
  const m=t.metroid||{};
  const pts=vy==='sm'?(m.points||[])
                     :((m.zpoints||[]).filter(p=>p.world===vy));
  const dg=vy==='sm'?[]:((m.zdungeons||[]).filter(d=>d.pos&&d.pos.world===vy));
  const b=pts.map((p,i)=>'<b data-i="'+i+'" class="'+ptCls(p)+'" style="left:'+
    (p.x*100)+'%;top:'+(p.y*100)+'%"></b>').join('');
  const u=dg.map((d,i)=>'<u data-i="'+i+'" class="'+(d.state||'')+'" style="left:'+
    (d.pos.x*100)+'%;top:'+(d.pos.y*100)+'%"></u>').join('');
  return (b?'<div class="pts">'+b+'</div>':'')+
         (u?'<div class="marks">'+u+'</div>':'');
}
// Kvarvarande platser i en grupp eller dungeon - samma lista som
// ALTTP-kartan visar nar man trycker pa en prick med flera kistor.
function kvarLista(med){
  const kvar=(med||[]).filter(x=>!x.open);
  if(!kvar.length)return '';
  return '<div class="lbl">Still to open ('+kvar.length+')</div>'+
    '<div class="chests">'+kvar.map(x=>{
      const kort=x.name.split(' - ').slice(1).join(' - ')||x.name;
      return '<div'+(x.reach===false?' class="lock"':'')+'>'+esc(kort)+
        (x.reach===false?' <s>locked</s>':'')+'</div>';
    }).join('')+'</div>';
}
// Kraven bakom en rod prick, samma uppstallning som ALTTP-kartan.
// ⚠️ Fraga aldrig om GRUPPNAMNET ("Kakariko Well") - det finns inte i
// logiken. Och inte om en redan tomd medlem heller, da beskriver svaret
// nagot knut redan hamtat. Forsta ATERSTAENDE platsen ar den som galler.
async function zKrav(p,seed,lista,tomd){
  const kvar=(p.members||[]).filter(m=>!m.open);
  const q=(kvar[0]&&kvar[0].name)||
          (p.members&&p.members[0]&&p.members[0].name)||p.name;
  let d;
  try{
    d=await (await api('api/smz3missing?seed='+encodeURIComponent(seed)+
                       '&name='+encodeURIComponent(q))).json();
  }catch(err){
    $id('ifbody').innerHTML=lista+
      '<div class="warn">Could not load the requirements.</div>';
    return;
  }
  const chips=(arr,cls)=>'<div class="need">'+
    arr.map(x=>'<b'+(cls?' class="'+cls+'"':'')+'>'+esc(x)+'</b>').join('')+
    '</div>';
  // Ett krav i kombon kan ga att uppfylla pa flera satt. Minimeringen ger
  // bara EN giltig uppsattning, sa utan alternativen kan man ge sig ut och
  // leta efter fel foremal - "Space Jump" nar Morph Ball Bombs dugt.
  const kravChips=(arr,alt)=>'<div class="need">'+arr.map(x=>{
    const a=(alt||{})[x]||[];
    if(!a.length)return '<b>'+esc(x)+'</b>';
    return '<span class="grp"><b>'+esc(x)+'</b>'+
      a.map(y=>'<i>eller</i><b>'+esc(y)+'</b>').join('')+'</span>';
  }).join('')+'</div>';
  let h=lista;
  if(d.fel)h+='<div class="warn">'+esc(d.fel)+'</div>';
  else if(tomd)h+='<div class="ok">Already cleared.</div>';
  else if(d.nabar)h+='<div class="ok">'+((p.total||p.chests||1)>1
    ?'The rest is reachable now.':'You can reach this one now.')+'</div>';
  else if(d.belong)h+='<div class="warn">Requires a reward you have not '+
    'collected yet — the crystal or pendant is in a dungeon you have not '+
    'cleared.</div>'+
    (d.behover&&d.behover.length
      ? '<div class="lbl">Also</div>'+kravChips(d.behover,d.alternativ)
      : (d.nagot_av&&d.nagot_av.length
         ? '<div class="lbl">Also one of</div>'+chips(d.nagot_av,'or')
         : ''));
  else if(d.omojlig)h+='<div class="warn">Requires something the tracker does not '+
    'read from the save file.</div>';
  else if(d.nagot_av&&d.nagot_av.length)
    h+='<div class="lbl">Missing one of</div>'+chips(d.nagot_av,'or');
  else if(d.behover&&d.behover.length)
    h+='<div class="lbl">Missing</div>'+kravChips(d.behover,d.alternativ);
  else h+='<div class="warn">No answer from the logic service.</div>';
  // Helt andra vagar dit. Visas efter huvudsvaret sa det inte konkurrerar
  // med det - de ar likvardiga, inte battre.
  // ⚠️ Bara nar ett KRAV visas. Servern skickar aldrig vagar utan krav,
  // men sidan ska inte lita pa det: i ett test med syntetiskt svar dok
  // "Eller den har vagen" up under "Redan tomd", vilket ar nonsens.
  if(d.behover&&d.behover.length&&!tomd&&!d.nabar)
    (d.vagar||[]).forEach(v=>{
      h+='<div class="lbl">Or this way instead</div>'+kravChips(v,null);
    });
  $id('ifbody').innerHTML=h;
}
function openZebes(t){
  const m=t.metroid;
  const mk=(m?m.areas:[]).map((a,ai)=>{
    const p=SM_POS[a.id]||[0.5,0.5];
    // Samma fyra lagen som Zelda-dungeons; servern har raknat ut dem.
    // Faller tillbaka pa "allt tomt" om logiken inte svarat.
    const st=a.state||(a.open>=a.total?'done':'');
    // Nara kanten? Vaxa inat i stallet for utat.
    const sida=p[0]>0.8?' hoger':(p[0]<0.2?' vanster':'');
    return '<u class="tapd'+(st?' '+st:'')+sida+'" data-a="'+ai+
      '" style="left:'+(p[0]*100)+'%;top:'+(p[1]*100)+'%">'+
      a.open+'/'+a.total+'<i>'+esc(a.name)+
      // Belongen syns pa kartan i spelet innan man gar in, sa den ar
      // ingen spoiler. Doljs nar omradet ar tomt - da ar den hamtad.
      (a.reward&&a.state!=='done'?' · '+esc(a.reward):'')+'</i></u>';
  }).join('');
  const b=$id('zbody');
  const pr=(m&&m.points?m.points:[]).map((p,pi)=>
    '<b class="'+ptCls(p)+' tap" data-p="'+pi+
    '" title="'+esc(p.name)+'" style="left:'+(p.x*100)+'%;top:'+
    (p.y*100)+'%"></b>').join('');
  b.innerHTML='<div class="mapwrap" style="aspect-ratio:'+(1097/1120)+'">'+
    '<div class="map img" style="background-image:url(\'sm-world.webp\')">'+
    '<div class="pts">'+pr+'</div>'+
    '<div class="marks">'+mk+'</div></div></div>';
  $id('zttl').textContent='Zebes · '+(m?m.open+'/'+m.total:'');
  zovNu={typ:'zebes',seed:t.seed,vy:'sm'};
  ZOV.classList.add('show');
  const w=b.querySelector('.mapwrap');
  bindZoom(w);
  w.querySelectorAll('.marks u.tapd').forEach(e=>e.onclick=ev=>{
    ev.stopPropagation();
    const a=t.metroid.areas[+e.dataset.a]; if(a)openArea(a,t);
  });
  w.querySelectorAll('.pts b.tap').forEach(e=>e.onclick=ev=>{
    ev.stopPropagation();
    const p=t.metroid.points[+e.dataset.p]; if(!p)return;
    $id('ifname').textContent=p.name;
    $id('ifsub').textContent=p.area+' · '+(p.open?'cleared':'not cleared');
    $id('ifsub').textContent=p.area+(p.boss?' · boss':
      ' · '+(p.open?'cleared':'not cleared'));
    if(p.boss){
      $id('ifbody').innerHTML='<div class="warn">Bosses have no bit in the '+
        'item field, so whether one is defeated cannot be read from '+
        'the save file.</div>';
      INFO.classList.add('show');
      return;
    }
    $id('ifbody').innerHTML='<div class="warn">Calculating…</div>';
    INFO.classList.add('show');
    zKrav(p,t.seed||'','',p.open);
  });
}
function openZeldaMap(t,vy){
  const b=$id('zbody');
  // Kartpositionerna ar seedoberoende och delas med ALTTP-trackern - det
  // ar samma varld, bara ett annat spel runt omkring.
  const m=t.metroid;
  const zp=((m&&m.zpoints)||[]).filter(p=>p.world===vy);
  const dg=((m&&m.zdungeons)||[]).filter(d=>d.pos&&d.pos.world===vy);
  const marks=dg.map((d,di)=>
    '<u class="tapd'+(d.state?' '+d.state:'')+'" data-dg="'+di+
    '" title="'+esc(d.name)+'" style="left:'+(d.pos.x*100)+'%;top:'+
    (d.pos.y*100)+'%">'+(d.found===null?'?':d.found)+'/'+d.chests+
    (d.reward&&d.state!=='done'?'<i>'+esc(d.reward)+'</i>':'')+
    '</u>').join('');
  const pr=zp.map((p,pi)=>{
    // Grupper visas som "2/5" i stallet for en prick, sa de gar att traffa
    // aven nar platserna ligger ovanpa varandra.
    const many=p.total>1;
    let cls=many?'grp ':'';
    if(p.state)cls+=p.state+' ';
    else if(p.open>=p.total)cls+='done ';
    else if(p.reach===false)cls+='no ';
    else if(p.reach===true)cls+='can ';
    return '<b class="'+cls+'tap" data-z="'+pi+'"'+
      (many?' data-n="'+p.open+'/'+p.total+'"':'')+
      ' title="'+esc(p.name)+'" style="left:'+(p.x*100)+'%;top:'+
      (p.y*100)+'%"></b>';
  }).join('');
  b.innerHTML='<div class="mapwrap" style="aspect-ratio:1">'+
    '<div class="map img" style="background-image:url(\'alttp-'+vy+
    '.png\')">'+(pr?'<div class="pts">'+pr+'</div>':'')+
    (marks?'<div class="marks">'+marks+'</div>':'')+'</div></div>';
  $id('zttl').textContent=(vy==='lw'?'Light World':'Dark World')+' · '+
    (t.seed||'');
  zovNu={typ:'zelda',seed:t.seed,vy:vy};
  ZOV.classList.add('show');
  const w=b.querySelector('.mapwrap');
  bindZoom(w);
  w.querySelectorAll('.pts b.tap').forEach(e=>e.onclick=ev=>{
    ev.stopPropagation();
    const p=zp[+e.dataset.z]; if(!p)return;
    $id('ifname').textContent=p.name;
    $id('ifsub').textContent = p.total>1
      ? (p.open+' av '+p.total+' locations cleared')
      : ((p.open?'Cleared':'Not cleared')+(p.exact?'':' · estimated'));
    $id('ifbody').innerHTML='<div class="warn">Calculating…</div>';
    INFO.classList.add('show');
    zKrav(p,t.seed||'',kvarLista(p.members),p.open>=p.total);
  });
  w.querySelectorAll('.marks u.tapd').forEach(e=>e.onclick=ev=>{
    ev.stopPropagation();
    const d=dg[+e.dataset.dg]; if(!d)return;
    $id('ifname').textContent=d.name;
    $id('ifsub').textContent=(d.found===null?'?':d.found)+' av '+d.chests+
      ' chests cleared'+(d.exact?'':' · partly estimated');
    $id('ifbody').innerHTML='<div class="warn">Calculating…</div>';
    INFO.classList.add('show');
    zKrav(d,t.seed||'',kvarLista(d.members),d.state==='done');
  });
}
function openArea(a,t){
  $id('ifname').textContent=a.name;
  $id('ifsub').textContent=a.open+' av '+a.total+' locations cleared';
  const kvar=(a.locs||[]).filter(l=>!l.open);
  const tagna=(a.locs||[]).filter(l=>l.open);
  let h='';
  if(tagna.length)h+='<div class="lbl">Cleared ('+tagna.length+')</div>'+
    '<div class="chests">'+tagna.map(l=>'<div class="lock">'+esc(l.name)+
    '</div>').join('')+'</div>';
  // Markera de onabara, precis som Zeldas dungeonlista gor.
  h+='<div class="lbl">Kvar ('+kvar.length+')</div>'+
     (kvar.length?'<div class="chests">'+kvar.map(l=>
       '<div'+(l.reach===false?' class="lock"':'')+'>'+esc(l.name)+
       (l.reach===false?' <s>locked</s>':'')+'</div>').join('')+'</div>'
      :'<div class="ok">This area is cleared.</div>');
  $id('ifbody').innerHTML=h;
  INFO.classList.add('show');
}
// Kistlistan for en dungeon. Bara NAMN pa kistorna - aldrig vad som ligger
// i dem. Vilka kistor som finns ar seedens geografi, inte dess innehall.
async function showDungeon(d,seed,ix,alla){
  $id('ifname').textContent=d.name;
  $id('ifsub').textContent=(d.found||0)+' av '+d.chests+' chests cleared'+
    (d.boss_sram===true?' · boss defeated':'');
  $id('ifbody').innerHTML='<div class="warn">Fetching…</div>';
  INFO.classList.add('show');
  let r;
  try{
    r=await (await api('api/dungeon?seed='+encodeURIComponent(seed)+
                       '&name='+encodeURIComponent(d.name))).json();
  }catch(err){
    $id('ifbody').innerHTML='<div class="warn">Could not load the chests.</div>';
    return;
  }
  const kvar=(r.chests||[]).filter(c=>!c.open);
  let h='';
  // "Known reward": the prize icon is visible on the map before you go in,
  // so this is what the dungeon WILL give - not something you are carrying.
  if(d.reward)h+='<div class="lbl">'+
    (d.boss_sram===true?'Reward':'Known reward')+'</div>'+
    '<div class="need"><b class="or">'+esc(d.reward)+'</b></div>';
  if(!kvar.length){
    h+='<div class="ok">All chests cleared.</div>';
  }else{
    // Onabara kistor markeras - listan sager da inte bara VAD som ar kvar
    // but what can be collected right now.
    const nu=kvar.filter(c=>c.reach!==false);
    h+='<div class="lbl">Still to open ('+kvar.length+')</div>'+
       '<div class="chests">'+
       kvar.map(c=>'<div'+(c.reach===false?' class="lock"':'')+'>'+
         esc(c.name)+(c.reach===false?' <s>locked</s>':'')+'</div>').join('')+
       '</div>';
    if(!nu.length)h+='<div class="warn" style="margin-top:8px">'+
      'None of them are reachable with your current items.</div>';
  }
  h+='<div class="foot2"><button class="setrw" id="ifrw">'+
     (d.reward?'Change reward':'Set reward')+'</button></div>';
  $id('ifbody').innerHTML=h;
  $id('ifrw').onclick=()=>{
    INFO.classList.remove('show');
    pkData=alla;pkSeed=seed;openPick(ix);
  };
}

// Vad heter platsen och vad saknas for att na den? Kravet ar en egenskap
// hos varlden, inte hos seeden, sa det avslojar aldrig vad som ligger dar.
async function showInfo(g,seed){
  $id('ifname').textContent=g.name;
  const tomd=g.open>=g.total;
  $id('ifsub').textContent = g.total>1
    ? (g.open+' av '+g.total+' locations cleared')
    : (tomd?'Cleared':'Not cleared');
  $id('ifbody').innerHTML='<div class="warn">Calculating…</div>';
  INFO.classList.add('show');

  // Flera platser under en prick listas var for sig, precis som en dungeons
  // kistor. Medlemmarna har redan egen open/reach fran /api/tracker, sa
  // listan kostar inget extra anrop.
  let lista='';
  const kvar=(g.members||[]).filter(m=>!m.open);
  if(g.total>1&&kvar.length){
    lista='<div class="lbl">Still to open ('+kvar.length+')</div>'+
      '<div class="chests">'+kvar.map(m=>{
        const kort=m.name.split(' - ').slice(1).join(' - ')||m.name;
        return '<div'+(m.reach===false?' class="lock"':'')+'>'+esc(kort)+
          (m.reach===false?' <s>locked</s>':'')+'</div>';
      }).join('')+'</div>';
  }

  // Kraven galler den forsta plats som faktiskt aterstar - fragar vi pa
  // gruppnamnet far vi svar om en plats knut redan tomt.
  const q=(kvar[0]&&kvar[0].name)||
          (g.members&&g.members[0]&&g.members[0].name)||g.name;
  let d;
  try{
    d=await (await api('api/missing?seed='+encodeURIComponent(seed)+
                       '&name='+encodeURIComponent(q))).json();
  }catch(err){
    $id('ifbody').innerHTML=lista+
      '<div class="warn">Could not load the requirements.</div>';
    return;
  }
  const chips=(arr,cls)=>'<div class="need">'+
    arr.map(x=>'<b'+(cls?' class="'+cls+'"':'')+'>'+esc(x)+'</b>').join('')+
    '</div>';
  let h=lista;
  if(d.fel){
    h+='<div class="warn">'+esc(d.fel)+'</div>';
  }else if(tomd){
    h+='<div class="ok">Already cleared.</div>';
  }else if(d.nabar){
    h+='<div class="ok">'+(g.total>1?'The rest is reachable now.'
                                    :'You can reach this one now.')+'</div>';
  }else if(d.omojlig){
    h+='<div class="warn">Requires something the tracker cannot read from the save file — '+
      'crystals and pendants from dungeons, or bottle and mushroom. '+
      'The logic cannot resolve this location.</div>';
  }else if(d.nagot_av&&d.nagot_av.length){
    h+='<div class="lbl">Missing one of</div>'+chips(d.nagot_av,'or');
  }else if(d.behover&&d.behover.length){
    h+='<div class="lbl">Missing</div>'+chips(d.behover);
  }else{
    h+='<div class="warn">No information about the requirements.</div>';
  }
  $id('ifbody').innerHTML=h;
}

function $id(i){return document.getElementById(i)}
async function openPick(ix){
  pkIx=ix;const d=pkData[ix];
  $id('pkname').textContent=d.name;
  const s0=$id('pksub');
  if(s0)s0.textContent='Which reward did it give? The boss is marked automatically.';
  $id('pkopts').className='opts';        // kistlistan kan ha bytt klass
  $id('pkclear').style.display='';
  if(!rewards.length){
    try{rewards=await(await api('api/rewards')).json()}catch(e){rewards=[]}}
  // Medaljongdungeons far ett extra val. Vardet lases INTE ur spoilern -
  // det avslojas i spelet vid dorren, och trackern ska aldrig ga fore.
  const MED=[['','Unknown'],['bombos','Bombos'],['ether','Ether'],
             ['quake','Quake']];
  $id('pkmed').innerHTML=!d.medal_key?'':
    '<h3 class="medh">Medallion</h3><div class="chips">'+MED.map(m=>
    '<button data-m="'+m[0]+'" class="'+((d.medallion||'')===m[0]?'on':'')+
    '">'+m[1]+'</button>').join('')+'</div>';
  $id('pkmed').querySelectorAll('button').forEach(b=>b.onclick=async()=>{
    d.medallion=b.dataset.m;
    $id('pkmed').querySelectorAll('button').forEach(x=>
      x.classList.toggle('on',x===b));
    try{await api('api/medallion',{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({seed:pkSeed,dungeon:d.medal_key,value:d.medallion})});
      toast(d.name+': '+(b.textContent))}
    catch(e){toast('Could not save',true)}
  });
  $id('pkopts').innerHTML=rewards.map(r=>
    '<button data-r="'+esc(r)+'" class="'+(d.reward===r?'on':'')+'">'+
    esc(r)+'</button>').join('');
  $id('pkopts').querySelectorAll('button').forEach(b=>b.onclick=()=>{
    const r=b.dataset.r;
    saveProg(d.name,true,pkData[pkIx].reward===r?'':r);
  });
  PICK.classList.add('show');
}
async function saveProg(name,boss,reward){
  try{
    await api('api/progress',{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({seed:pkSeed,dungeon:name,
                           boss:reward?true:boss,reward:reward})});
    toast(reward?name+': '+reward:name+' rensad');
  }catch(e){toast('Could not save',true)}
  PICK.classList.remove('show');
  loadTracker();
}
$id('pkclose').onclick=()=>PICK.classList.remove('show');
$id('ifclose').onclick=()=>INFO.classList.remove('show');

/* A click outside closes the box. Two conditions, both necessary:
   ⚠️ the hit must be the BACKGROUND itself - otherwise every click inside
      the box would close it immediately;
   ⚠️ it must not be the end of a DRAG. The map is panned with a finger and
      the release then often lands outside the image; without the limit the
      map would close in the middle of being dragged. The same 8 px
      bindZoom already uses to tell a drag from a tap. */
function stangVidKlickUtanfor(ov, arBakgrund, stang){
  let x=0,y=0;
  ov.addEventListener('pointerdown',e=>{x=e.clientX;y=e.clientY},true);
  ov.addEventListener('click',e=>{
    if(!arBakgrund(e.target))return;
    if(Math.abs(e.clientX-x)>8||Math.abs(e.clientY-y)>8)return;
    stang();
  });
}
stangVidKlickUtanfor(PICK,t=>t===PICK,()=>PICK.classList.remove('show'));
stangVidKlickUtanfor(INFO,t=>t===INFO,()=>INFO.classList.remove('show'));
$id('pkclear').onclick=()=>saveProg(pkData[pkIx].name,false,'');

/* The tracker belongs to a run in progress - not to the menu. The MiSTer
   only reports which CORE is running, not which ROM, so "the SNES core is
   running" is as close to "the player is on their seed" as we can get. If
   it sits in MENU or on another core the card is hidden entirely. */
const TRACKER_CORES=['SNES'],STALE_H=24;
let trkForced=[],trkMin=[],trkInit=false;
/* One card per seed. The run is CHOSEN, not derived: guessing at "most
   recently written save file" pointed at the wrong run when two were going
   at once. Each card is bound to its seed and carries its own map, its own
   chests and its own rewards. */
// Sista svaret sparas lokalt och ritas direkt vid sidladdning. Kartan och
// positionerna andras aldrig mellan tva laddningar - bara prickarnas farg -
// sa den gamla bilden ar ratt i allt utom logiken, och den hinner uppdateras
// innan man last klart.
const TRKKEY='mistergames.trk';
let trkPainted='';
function cachedTracker(){
  try{const r=localStorage.getItem(TRKKEY);return r?JSON.parse(r):null}
  catch(e){return null}
}
let sistaCore=null;
async function loadTracker(cached){
  let core=null,d;
  if(cached){
    d=cached;                    // ritas direkt, utan att vanta pa natet
    // ⚠️ Behall senast kanda core. Nollstalldes den har blev signaturen
    // en annan an den fran forra farska rundan, och nasta poll byggde om
    // korten i onodan - vilket ryckte bort allt man hade uppe.
    core=sistaCore;
  }else{
    // Parallellt: statusen behovs inte for att bygga kartan.
    const pS=fetch(API+'api/status',{cache:'no-store'})
      .then(r=>r.json()).then(j=>j.core).catch(()=>null);
    const pT=api('api/tracker').then(r=>r.json());
    try{d=await pT}catch(e){return}
    core=await pS;
    sistaCore=core;
    try{localStorage.setItem(TRKKEY,JSON.stringify(d))}catch(e){}
  }
  trkData=d||[];
  if(!trkData.length){TRKS.innerHTML='';trkPainted='';return}
  // Bygg inte om DOM:en nar ingenting andrats - tryck som landar mitt i en
  // ombyggnad kanns som lagg. Signaturen maste innehalla vad som ar utfallt,
  // annars hoppas en omritning som faktiskt behovs over.
  // ⚠️ Signaturen beskriver STRUKTUREN, inte innehallet. Forut lag hela
  // payloaden har, sa varje ny sparfil ritade om alla kort - och da rycktes
  // spoilerrutan, det man skrivit och utfallda lagen bort mitt i.
  // Nu ritas kortet om bara nar listan faktiskt andras (ny seed, raderad
  // seed, ut- eller ihopfallt kort). Ny KARTDATA uppdateras pa plats.
  // ⚠️ trkInit andrar trkMin, som ingar i signaturen - darfor FORE den.
  // Se samma not i drawSMZ3.
  if(!trkInit){trkInit=true;
    trkMin=trkData.slice(1).map(x=>x.seed).filter(Boolean)}
  const sign=JSON.stringify(trkData.map(t=>[t.seed,t.started,!!t.rom]))+'|'+
    (core||'')+'|'+trkForced.join(',')+'|'+trkMin.join(',');
  if(sign===trkPainted){uppdateraKartorPaKort();uppdateraZoom();return}
  // Skjut upp omritningen tills spoilerrutan stangts. Tom signatur gor att
  // den kors sa fort rutan ar ur vagen.
  if(spoilerUpptagen(TRKS)){trkPainted='';uppdateraKartorPaKort();
    uppdateraZoom();return}
  trkPainted=sign;
  // Servern sorterar nyast forst. Fall ihop resten en gang, vid forsta
  // laddningen - inte vid varje uppdatering, annars aker det knut fallt ut
  // igen var 20:e sekund.
  tryMap('lw');tryMap('dw');
  const noCore=!core||TRACKER_CORES.indexOf(core)<0;
  TRKS.innerHTML=trkData.map((t,ix)=>{
    // Tva skal att falla ihop: ingen run igang, eller en run som legat dod.
    let why=null;
    if(!t.started)why='not started';
    else if(noCore)why='The MiSTer is not playing anything right now';
    else if((Date.now()/1000-t.synced)/3600>STALE_H)why='synkad '+ago(t.synced);
    if(why&&trkForced.indexOf(t.seed)<0)
      return '<div class="trk show stub" data-s="'+ix+'">'+
        // ⚠️ Bocken star direkt efter seed-id:t, inte sist. Raden ar en
        // enda flexrad med ellips - sist hade den kapats pa en smal skarm,
        // och det ar just da man behover se att runden ar klar.
        '<div class="stubrow"><span>🗡️ '+esc(t.seed||'?')+
        (t.klar?' <b class="klar">✅</b>':'')+' · '+esc(why)+
        // Raknaren folger med ner i stubbraden - annars tappar man den
        // enda siffra som sager nagot om hur langt runden kommit.
        // ⚠️ SAMMA raknare som kortet. Stubbraden hade en egen kopia som
        // raknade tomda PUNKTER ("54/60") medan kortet raknade platser
        // ("209 av 216") - tva olika sanningar om samma run.
        (alttpTotalt(t)
          ? ' · '+alttpTotalt(t).open+'/'+alttpTotalt(t).total+' platser' : '')+
        '</span><b>Show</b></div></div>';
    const min=trkMin.indexOf(t.seed)>=0;
    return '<div class="trk show'+(min?' min':'')+'" data-s="'+ix+'">'+
      '<div class="th"><h2>Your run</h2>'+
      '<span class="sid">'+esc(t.seed||'?')+'</span>'+
      (t.rom?'<button class="play">Start</button>':'')+
      '<button class="del" title="Delete seed">🗑</button>'+
      (trkForced.indexOf(t.seed)>=0?'<span class="hide">Hide</span>':'')+
      '<span class="chev">▾</span></div>'+
      '<div class="sync'+(t.started?'':' warn')+'">'+syncInner(t)+'</div>'+
      staleNote(t)+skinHTML(t)+
      '<div class="worlds">'+worldsHTML(t,min)+'</div>'+
      spHTML(t)+
      '<div class="stats">'+statsInner(t)+'</div></div>';
  }).join('');
  bindCards();
  uppdateraZoom();
  document.querySelectorAll('.trkh .newbtn').forEach(e=>
    e.onclick=()=>gen(e.dataset.g));
}

/* All interaktion slar upp sitt kort forst, sa ratt seed alltid skrivs. */
async function askDelete(seed,label){
  let files=[];
  try{files=(await(await fetch(API+'api/seedfiles?seed='+
    encodeURIComponent(seed))).json()).files||[]}catch(e){}
  $id('pkname').textContent='Delete '+label+'?';
  // ⚠️ The box is shared with the reward picker, which leaves its subtitle
  // ("Which reward did it give?") sitting in the middle of a delete dialog.
  const sub=$id('pksub');
  if(sub)sub.textContent='Everything belonging to the seed is removed.';
  $id('pkmed').innerHTML='<div class="files">'+
    (files.map(f=>'<div>'+esc(f)+'</div>').join('')||'<div>no files</div>')+
    '</div><p class="warn2">The files above are deleted permanently — ROM, spoiler, '+
    'save file, save states and screenshots — as well as your check marks, rewards '+
    'and spoiler lookups for the seed. This cannot be undone.</p>';
  $id('pkopts').className='';$id('pkopts').innerHTML='';
  $id('pkclear').style.display='';
  $id('pkclear').textContent='Cancel';
  $id('pkclear').onclick=()=>PICK.classList.remove('show');
  const cl=$id('pkclose');cl.textContent='Delete';cl.className='danger';
  cl.onclick=async()=>{
    try{const r=await api('api/delete_seed',{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({seed:seed})});
      const j=await r.json();toast(j.message,!j.ok)}catch(e){}
    cl.textContent='Done';cl.className='close';
    cl.onclick=()=>PICK.classList.remove('show');
    // ⚠️ loadSMZ3 maste med - annars lag ett raderat SMZ3-kort kvar tills
    // sidan laddades om, och sag ut som om raderingen inte tagit.
    PICK.classList.remove('show');load();loadTracker();loadSMZ3();
  };
  PICK.classList.add('show');
}

// Egen funktion: bindningarna maste sattas om nar ett hopfallt kort ritar
// sina prickar forst vid utfallning.
// Nypa, dra och dubbeltryck pa kartan. Prickarna ar procentpositionerade,
// sa de foljer med skalningen utan egen kod.
// 1020 px ar kartans bredd i en vanlig datorvy - dar kandes 8.5 px ratt,
// och det ar den proportionen knut vill ha kvar pa telefonen.
const ETIKETT_REF=1020;
function etikettSkala(wrap){
  if(!wrap)return;
  // ⚠️ offsetWidth, INTE getBoundingClientRect: den senare rakhar in
  // zoomens transform, sa etiketterna hade krympt nar man zoomade in.
  const b=wrap.offsetWidth;
  if(!b)return;
  const sk=Math.max(0.4,Math.min(1,b/ETIKETT_REF));
  wrap.style.setProperty('--eskala',sk.toFixed(3));
}
addEventListener('resize',()=>{
  const w=$id('zbody')&&$id('zbody').querySelector('.mapwrap');
  if(w&&ZOV.classList.contains('show'))etikettSkala(w);
});
function bindZoom(wrap){
  etikettSkala(wrap);
  if(!wrap)return;
  const map=wrap.querySelector('.map');if(!map)return;
  let sc=1,tx=0,ty=0;
  const pts=new Map();
  let start=null,moved=0,lastTap=0;
  const MAXSC=6;
  const apply=()=>{
    // Hall kartan inom wrappern - annars gar den att dra ut i tomma intet.
    const w=wrap.clientWidth,h=wrap.clientHeight;
    tx=Math.min(0,Math.max(w-w*sc,tx));
    ty=Math.min(0,Math.max(h-h*sc,ty));
    map.style.transform='translate('+tx+'px,'+ty+'px) scale('+sc+')';
    wrap.classList.toggle('zoomed',sc>1.01);
  };
  const mitt=()=>{
    const a=[...pts.values()];
    return a.length<2?a[0]:{x:(a[0].x+a[1].x)/2,y:(a[0].y+a[1].y)/2};
  };
  const dist=()=>{
    const a=[...pts.values()];
    return Math.hypot(a[0].x-a[1].x,a[0].y-a[1].y);
  };
  wrap.addEventListener('pointerdown',e=>{
    pts.set(e.pointerId,{x:e.clientX,y:e.clientY});
    // INTE setPointerCapture har: da levereras klicket till wrappern i
    // stallet for till pricken, och dialogerna slutade oppnas pa datorn.
    // Vi fangar forst nar en gest faktiskt borjat, se pointermove.
    moved=0;
    start={sc:sc,tx:tx,ty:ty,d:pts.size>1?dist():0,m:mitt()};
  });
  wrap.addEventListener('pointermove',e=>{
    if(!pts.has(e.pointerId))return;
    pts.set(e.pointerId,{x:e.clientX,y:e.clientY});
    if(!start)return;
    const r=wrap.getBoundingClientRect();
    if(pts.size>1){
      if(!wrap.hasPointerCapture(e.pointerId))
        try{wrap.setPointerCapture(e.pointerId)}catch(err){}
      const f=dist()/(start.d||1);
      const ny=Math.min(MAXSC,Math.max(1,start.sc*f));
      const m=mitt(),mx=m.x-r.left,my=m.y-r.top;
      // Skala runt fingrarnas mittpunkt: den punkten ska sta stilla.
      sc=ny;
      tx=mx-(mx-start.tx)*(sc/start.sc);
      ty=my-(my-start.ty)*(sc/start.sc);
      moved=99;apply();
    }else if(sc>1.01){
      const a=[...pts.values()][0],m=start.m;
      const dx=a.x-m.x,dy=a.y-m.y;
      moved=Math.max(moved,Math.hypot(dx,dy));
      if(moved>8&&!wrap.hasPointerCapture(e.pointerId))
        try{wrap.setPointerCapture(e.pointerId)}catch(err){}
      if(moved>8){tx=start.tx+dx;ty=start.ty+dy;apply();}
    }
  });
  const slut=e=>{
    pts.delete(e.pointerId);
    if(pts.size===0){
      start=null;
      // Dubbeltryck: vaxla mellan 1x och 2,5x kring tryckpunkten.
      if(moved<8){
        const nu=Date.now();
        if(nu-lastTap<300){
          const r=wrap.getBoundingClientRect();
          const mx=e.clientX-r.left,my=e.clientY-r.top;
          if(sc>1.01){sc=1;tx=0;ty=0;}
          else{const ny=2.5;tx=mx-(mx-tx)*(ny/sc);ty=my-(my-ty)*(ny/sc);sc=ny;}
          apply();lastTap=0;
        }else lastTap=nu;
      }
    }else start={sc:sc,tx:tx,ty:ty,d:pts.size>1?dist():0,m:mitt()};
  };
  // En dragning far inte rakna som ett tryck pa pricken man slappte over.
  wrap.addEventListener('click',e=>{
    if(moved>8){e.stopPropagation();e.preventDefault();moved=0;}
  },true);
  wrap.addEventListener('pointerup',slut);
  wrap.addEventListener('pointercancel',slut);
  // Mushjul pa datorn.
  wrap.addEventListener('wheel',e=>{
    e.preventDefault();
    const r=wrap.getBoundingClientRect();
    const mx=e.clientX-r.left,my=e.clientY-r.top;
    const ny=Math.min(MAXSC,Math.max(1,sc*(e.deltaY<0?1.15:1/1.15)));
    tx=mx-(mx-tx)*(ny/sc);ty=my-(my-ty)*(ny/sc);sc=ny;
    if(sc<=1.01){sc=1;tx=0;ty=0;}
    apply();
  },{passive:false});
}
// Fullskarmsvyn: kartan klonas dit och far hela ytan. Prickarna behaller
// sina data-attribut, sa samma handlare kan bindas om - man vill kunna
// trycka pa en kista aven nar man zoomat in for att hitta den.
const ZOV=$id('zoomov');
// --- fullskarmsvyn uppdateras pa plats -------------------------------
// ⚠️ Rita INTE om vyn nar ny data kommer in. Zoom och panorering ligger i
// bindZooms closure och skulle nollstallas mitt i att man tittar - och det
// ar just nar man vantar pa nya foremal som man star inzoomad nagonstans.
// Byt bara klasser och siffror pa de element som redan finns.
let zovNu=null;

function zoomCls(p,typ){
  if(typ==='zebes')return ptCls(p)+' tap';
  let c=(p.total>1?'grp ':'');
  if(p.state)c+=p.state+' ';
  else if(p.open>=p.total)c+='done ';
  else if(p.reach===false)c+='no ';
  else if(p.reach===true)c+='can ';
  return c+'tap';
}

/* The cards' maps are updated IN PLACE. ⚠️ The same technique as
   updateZoom: only className and text on elements that already exist. If
   we redrew the card everything else would be torn away - the spoiler box,
   what you have typed, expanded states - and a tap landing in the middle
   of the rebuild does nothing at all. The rule: only the maps update, not
   the rest of the page. */
/* ⚠️ The edge class (.hoger/.vanster) MUST survive a rewrite of
   className. The updaters built the class name from scratch and wiped it
   out - the badge became centred and stuck out over the map again after
   the first update. The symptom was tricky: it looked right when you
   opened the map and wrong half a minute later. */
function medSida(e, nytt){
  return nytt + (e.classList.contains('hoger') ? ' hoger'
               : e.classList.contains('vanster') ? ' vanster' : '');
}
function uppdateraKartorPaKort(){
  // ALTTP-korten: prickar och dungeonmarkorer bar redan data-p / data-dg.
  TRKS.querySelectorAll('.trk[data-s]').forEach(kort=>{
    const t=trkData[+kort.dataset.s]; if(!t)return;
    // Synkrad och statistik pa plats. ⚠️ Bara textinnehallet - kortet far
    // inte byggas om, det ar hela poangen med den har funktionen.
    const sy=kort.querySelector('.sync');
    if(sy){sy.innerHTML=syncInner(t);
      sy.classList.toggle('warn',!t.started);}
    const stt=kort.querySelector('.stats');
    if(stt)stt.innerHTML=statsInner(t);
    const pts=t.points||[], dg=t.dungeons||[];
    kort.querySelectorAll('.wl').forEach(wl=>{
      wl.querySelectorAll('.pts b').forEach(e=>{
        const p=pts[+e.dataset.p]; if(!p)return;
        const many=p.total>1;
        e.className=(many?'grp ':'')+ptCls(p)+' tap';
        if(many)e.dataset.n=p.open+'/'+p.total;
      });
      wl.querySelectorAll('.marks u').forEach(e=>{
        const d=dg[+e.dataset.dg]; if(!d)return;
        const klar=d.boss_sram===true;
        e.className=medSida(e,'tapd'+(d.state?' '+d.state:''));
        e.innerHTML=(klar?'✓ ':'')+(d.found===null?0:d.found)+'/'+d.chests+
          ((d.reward&&!klar)?'<i>'+esc(d.reward)+'</i>':'');
      });
      const n2=wl.querySelector('.n2');
      if(n2)n2.innerHTML=alttpRakn(t,wl.dataset.w);
    });
  });
  // SMZ3-korten: tre miniatyrer, prickarna nycklade pa data-i.
  if(!SMZ3)return;
  SMZ3.querySelectorAll('.trk[data-sm]').forEach(kort=>{
    const t=smData[+kort.dataset.sm]; if(!t)return;
    const sy=kort.querySelector('.sync');
    if(sy)sy.innerHTML=smSyncInner(t);
    const stt=kort.querySelector('.smstat');
    if(stt)stt.innerHTML=smStatsInner(t);
    const m=t.metroid||{};
    kort.querySelectorAll('.mini').forEach(kn=>{
      const vy=kn.dataset.v;
      const pts=vy==='sm'?(m.points||[])
                         :((m.zpoints||[]).filter(x=>x.world===vy));
      const dg=vy==='sm'?[]
                        :((m.zdungeons||[]).filter(x=>x.pos&&x.pos.world===vy));
      kn.querySelectorAll('.pts b').forEach(e=>{
        const p=pts[+e.dataset.i]; if(p)e.className=ptCls(p);
      });
      kn.querySelectorAll('.marks u').forEach(e=>{
        const d=dg[+e.dataset.i]; if(d)e.className=medSida(e,d.state||'');
      });
      const s=kn.querySelector('.txt s');
      if(s)s.innerHTML=vy==='sm'
        ? (m.open!=null?(m.open+' / '+m.total):'&nbsp;')
        : (zrakn(t,vy)||'&nbsp;');
    });
  });
}
function uppdateraZoom(){
  if(!zovNu||!ZOV.classList.contains('show'))return;
  const w=$id('zbody').querySelector('.mapwrap'); if(!w)return;
  const kalla=zovNu.typ==='alttp'?trkData:smData;
  const t=(kalla||[]).find(x=>x&&x.seed===zovNu.seed); if(!t)return;
  const m=t.metroid||{};
  let pts=[],mk=[];
  if(zovNu.typ==='alttp'){pts=t.points||[];mk=t.dungeons||[];}
  else if(zovNu.typ==='zebes'){pts=m.points||[];mk=m.areas||[];}
  else{pts=(m.zpoints||[]).filter(p=>p.world===zovNu.vy);
       mk=(m.zdungeons||[]).filter(d=>d.pos&&d.pos.world===zovNu.vy);}

  w.querySelectorAll('.pts b').forEach(e=>{
    const ix=+(e.dataset.p!==undefined?e.dataset.p:e.dataset.z);
    const p=pts[ix]; if(!p)return;
    e.className=zoomCls(p,zovNu.typ);
    if(p.total>1)e.dataset.n=p.open+'/'+p.total;
  });
  w.querySelectorAll('.marks u').forEach(e=>{
    const ix=+(e.dataset.a!==undefined?e.dataset.a:e.dataset.dg);
    const d=mk[ix]; if(!d)return;
    if(zovNu.typ==='zebes'){
      const st=d.state||(d.open>=d.total?'done':'');
      e.className=medSida(e,'tapd'+(st?' '+st:''));
      e.innerHTML=d.open+'/'+d.total+'<i>'+esc(d.name)+
        (d.reward&&d.state!=='done'?' · '+esc(d.reward):'')+'</i>';
    }else if(zovNu.typ==='zelda'){
      e.className=medSida(e,'tapd'+(d.state?' '+d.state:''));
      e.innerHTML=(d.found===null?'?':d.found)+'/'+d.chests+
        (d.reward&&d.state!=='done'?'<i>'+esc(d.reward)+'</i>':'');
    }else{
      const klar=d.boss_sram===true;
      e.className=medSida(e,'tapd'+(d.state?' '+d.state:''));
      e.innerHTML=(klar?'✓ ':'')+(d.found===null?0:d.found)+'/'+d.chests+
        ((d.reward&&!klar)?'<i>'+esc(d.reward)+'</i>':'');
    }
  });
  if(zovNu.typ==='zebes')
    $id('zttl').textContent='Zebes · '+(m.open+'/'+m.total);
}

function closeZoom(){zovNu=null;ZOV.classList.remove('show');
  $id('zbody').innerHTML=''}
$id('zclose').onclick=closeZoom;
// Ytan runt kartbilden racknas som utanfor. .zhead undantas - dar sitter
// stangknappen, och ett tryck bredvid den ska inte gora nagot.
stangVidKlickUtanfor(ZOV,
  t=>t===ZOV||t.classList.contains('zbody'), closeZoom);
function openZoom(wrap,t,rubrik){
  const src=wrap.querySelector('.map');if(!src)return;
  const b=$id('zbody');
  b.innerHTML='<div class="mapwrap">'+src.outerHTML+'</div>';
  $id('zttl').textContent=rubrik;
  zovNu={typ:'alttp',seed:t.seed,vy:null};
  ZOV.classList.add('show');
  const nw=b.querySelector('.mapwrap');
  bindZoom(nw);
  bindDots(nw,t);
}
function bindDots(root,t){
  root.querySelectorAll('.marks u.tapd').forEach(e=>e.onclick=ev=>{
    ev.stopPropagation();
    const ix=+e.dataset.dg;const d=(t.dungeons||[])[ix];
    if(d)showDungeon(d,t.seed||'',ix,t.dungeons||[]);});
  root.querySelectorAll('.pts b.tap').forEach(e=>e.onclick=ev=>{
    ev.stopPropagation();
    const g=(t.points||[])[+e.dataset.p];
    if(g)showInfo(g,t.seed||'');
  });
}
function bindMap(card,t){
  card.querySelectorAll('.wl .mapwrap').forEach(w=>{
    if(w.dataset.b)return;
    w.dataset.b='1';
    const h3=w.parentNode&&w.parentNode.querySelector('h3');
    w.onclick=ev=>{ev.stopPropagation();
      openZoom(w,t,(h3?h3.textContent:'Map')+' · '+(t.seed||''));};
  });
  bindDots(card,t);
}
// ⚠️ Rita ALDRIG om ett kort medan spoilerrutan anvands. Korten byggs om
// var 20:e (ALTTP) respektive var 30:e sekund, och omritningen nollstaller
// det man skrivit, bekraftelserutan OCH det avslojade svaret. Varre an sa:
// raknaren ligger i kortdatan, sa ett avslojande andrar payloaden och
// GARANTERAR en omritning direkt efteron - svaret man just betalat for
// hann knappt synas. Ett tryck som landar mitt i ombyggnaden gor dessutom
// ingenting alls, for elementet man traffade ar redan utbytt.
function spoilerUpptagen(root){
  return !!(root && root.querySelector('.sp.open'));
}
// ⚠️ "Completed" betyder att man stod i SLUTSTRIDEN - alla kristaller,
// Agahnim 2 besegrad och Ganons rum besokt. Nagon exakt "Ganon defeated"-
// stampel finns inte i sparfilen: spelet rullar eftertexter och sparar
// aldrig igen. Speltiden ar medvetet bortvald - se noten i server.py.
/* Sync row and statistics are built in ONE place, so the card and the
   updater can never drift apart. The timer no longer redraws the card (see
   the note about the spoiler box), so these texts have to be updated in
   place instead - otherwise "Synced 3 h ago" stays there for hours. */
/* The whole seed, just like the SMZ3 card. This used to show the number of
   CLEARED POINTS ("54/60 cleared") - neither chests nor dungeons, so a run
   could look nearly finished with a hundred chests left inside the
   dungeons. Now: the map locations' chests plus the dungeon chests. The
   total comes from the seed's own spoiler, so it is right for that
   particular seed.
   ⚠️ The points' "open" is an approximation - see the note at points() in
   server.py. Dungeon chests are read exactly from SRAM. */
/* Chests, not points. A "point" on the map can be a group of five chests,
   and dungeons were not counted at all before - which is why a run looked
   nearly finished with a hundred chests left. The sum per map is exactly
   the card's total: ALTTP 90+112 = 202/209, SMZ3 61+32+27 = 120/316. */
function kistor(pts,dg){
  let o=0,tot=0;
  (pts||[]).forEach(x=>{o+=x.open||0; tot+=x.total||1});
  (dg||[]).forEach(x=>{o+=x.found||0; tot+=x.chests||0});
  return {open:o,total:tot};
}
/* ⚠️ Fallback total when the seed has no spoiler file - we then do not
   know the dungeons' chest counts. Without this it said "0 of 94", as if
   the seed only had 94 locations. The numbers are the usual ones for each
   game; a seed built with different settings can differ, and it is right
   again as soon as the spoiler exists. */
const TOT_ALTTP=216, TOT_SMZ3=316;
function alttpTotalt(t){
  const p=t.points||[], dg=t.dungeons||[];
  if(!p.length&&!dg.length)return null;
  // Saknas dungeondata (ingen spoilerfil) blir namnaren fel - visa den
  // vanliga totalen i stallet for en som ljuger om seedens storlek.
  if(!dg.length)return {open:0,total:TOT_ALTTP};
  return kistor(p,dg);
}
function syncInner(t){
  const s=alttpTotalt(t);
  return (t.started?('Synced '+ago(t.synced)+
      ' — open the OSD on the MiSTer to refresh')
      :'⚠️ No running game found — press Start to launch it')+
    (t.intact?'':'<br>⚠️ the backup copy in the save file differs')+
    // Raknaren bor i synkraden sa den syns aven nar kortet ar ihopfallt.
    (s?' <b>'+s.open+' av '+s.total+' platser</b>':'')+
    (klarTxt(t)?' '+klarTxt(t):'');
}
function statsInner(t){
  return '<div><em>'+t.screens+'</em>screens</div>'+
    '<div><em>'+t.rooms+'</em>rum</div>'+
    '<div><em>'+t.hearts+'</em>hearts</div>'+
    '<div><em>'+t.rupees+'</em>rupier</div>';
}
/* The whole seed, not just Metroid. The sum comes to 316 - exactly as many
   as TotalSMZ3 has in an SMZ3 seed (100 Metroid + 94 Zelda locations + 122
   dungeon chests), so nothing is double counted.
   ⚠️ The Zelda points' "open" is an approximation (see the note at points()
   in server.py) - the overworld flags sit per SCREEN, not per location. It
   is the same number the mini maps' counter already shows, so the card is
   at least consistent with itself. */
function smTotalt(t){
  const m=t.metroid;
  // ⚠️ Ger ALLTID ett svar. En opaborjad seed har ingen sparfil och darmed
  // inget metroid-block, men den har lika manga platser anda - "0 av 316"
  // sager mer an "ej paborjad", som knut papekade.
  if(!m)return {open:0,total:TOT_SMZ3};
  if(!(m.zdungeons||[]).length)return {open:0,total:TOT_SMZ3};
  const zp=m.zpoints||[], zd=m.zdungeons||[];
  let o=m.open||0, tot=m.total||0;
  zp.forEach(p=>{o+=p.open||0; tot+=p.total||1});
  zd.forEach(d=>{o+=d.found||0; tot+=d.chests||0});
  return {open:o,total:tot};
}
function smSyncInner(t){
  const s=smTotalt(t);
  // The warning only applies to a STARTED seed whose save file lacks the
  // Metroid block - the number is then unreliable and must not be shown.
  const txt=(t.started&&!t.metroid)
    ? 'save file without Metroid data'
    : s.open+' av '+s.total+' platser';
  return txt+(klarTxt(t)?' '+klarTxt(t):'');
}
function smStatsInner(t){
  const m=t.metroid; if(!m)return '';
  return '<div><em>'+m.energi+'</em>energi</div>'+
    '<div><em>'+m.missiler+'</em>missiler</div>'+
    '<div><em>'+m.supers+'</em>supers</div>'+
    '<div><em>'+m.pb+'</em> power bombs</div>';
}
function klarTxt(t){
  return t.klar? '<b class="klar">✅ Completed</b>' : '';
}
// Raknaren visas som 0-5 och sedan "5+".
function spTxt(n){n=n||0;return n>5?'5+':(''+n)}
// Spoilerrutan ar IDENTISK for ALTTP och SMZ3 - samma tvastegsflode, samma
// rakning. Bara varningstexten skiljer, for SMZ3:s .txt ar ofullstandig
// (men placeringen laser vi ur ROM:en, sa sokningen ar anda komplett).
function spHTML(t,extra){
  const n=t.spoilers||0;
  return '<div class="sp"><b>🔒 Spoiler<i class="cnt'+(n>5?' nog':'')+'">'+
    spTxt(n)+'</i></b><div class="box">'+
    '<div class="lage"><button data-m="item" class="pa">Item</button>'+
    '<button data-m="plats">Location</button></div>'+
    '<input placeholder="search items – e.g. Hammer, Morph">'+
    '<p class="warn2">First you choose <b>vad</b> you are looking for. The list then shows '+
    'names only — nothing is revealed until you confirm.'+(extra?' '+extra:'')+
    '</p><ul></ul></div></div>';
}
function bindSpoiler(card,seed){
  const sp=card.querySelector('.sp');if(!sp)return;
  sp.querySelector('b').onclick=ev=>{ev.stopPropagation();
    const oppen=sp.classList.toggle('open');
    // Fokusera faltet direkt - annars kravs ett andra tryck bara for att
    // borja skriva. preventScroll sa sidan inte hoppar pa mobilen.
    if(oppen){const i=sp.querySelector('input');
      if(i)setTimeout(()=>i.focus({preventScroll:true}),0);
      if(!i.value.trim())visaLogg();}};
  sp.querySelector('.box').onclick=ev=>ev.stopPropagation();
  const inp=sp.querySelector('input'),ul=sp.querySelector('ul');
  const cnt=sp.querySelector('.cnt');
  let mode='item',tm=null;

  function raknaOm(n){
    if(cnt){cnt.textContent=spTxt(n);cnt.classList.toggle('nog',(n||0)>5)}
    // Kortdatan far folja med, annars hoppar siffran tillbaka nasta gang
    // kortet ritas om ur minnet. ⚠️ De tva korttyperna indexeras olika:
    // ALTTP pa data-s, SMZ3 pa data-sm.
    const a=trkData[+card.dataset.s];if(a&&a.seed===seed)a.spoilers=n;
    const b=smData[+card.dataset.sm];if(b&&b.seed===seed)b.spoilers=n;
  }
  function rensa(){const g=sp.querySelector('.konf'),v=sp.querySelector('.svar');
    if(g)g.remove();if(v)v.remove()}

  sp.querySelectorAll('.lage button').forEach(b=>{
    b.onclick=ev=>{ev.stopPropagation();
      mode=b.dataset.m;
      sp.querySelectorAll('.lage button').forEach(x=>
        x.classList.toggle('pa',x===b));
      inp.placeholder=mode==='item'
        ? 'search items – e.g. Hammer, Morph'
        : 'search locations – e.g. Ice Palace, Wrecked Ship';
      rensa();ul.innerHTML='';sok();
      inp.focus({preventScroll:true});};
  });

  // ⚠️ Called when the box opens and when the search field is empty - that
  // is, in exactly the states where the list would otherwise be empty and
  // you cannot see what you have already spent.
  async function visaLogg(){
    try{
      const r=await fetch(API+'api/spoilerlog?seed='+encodeURIComponent(seed));
      const j=await r.json();
      if(j.count!=null)raknaOm(j.count);
      if(!(j.poster||[]).length){ul.innerHTML='';return}
      ul.innerHTML='<div class="logg"><p class="rub">Already revealed ('+
        j.poster.length+')</p>'+j.poster.map(x=>'<li><em>'+
        (x.mode==='item'?'Item':'Location')+'</em>'+esc(x.namn)+
        '<br><b>'+esc((x.svar||[]).join(', ')||'—')+'</b></li>').join('')+
        '</div>';
    }catch(e){}
  }
  async function sok(){
    const q=inp.value.trim();
    if(q.length<3){visaLogg();return}
    try{
      const r=await fetch(API+'api/spoilernames?seed='+encodeURIComponent(seed)+
        '&mode='+mode+'&q='+encodeURIComponent(q));
      const j=await r.json();
      if(j.count!=null)raknaOm(j.count);
      // ⚠️ Bara NAMN har. Skulle vi visa vad som ligger var vore hela
      // bekraftelsesteget meningslost - man hade spoilat sig genom att skriva.
      ul.innerHTML=(j.namn||[]).map(n=>'<li class="val'+(n.sedd?' sedd':'')+
        '" data-n="'+esc(n.namn)+'">'+esc(n.namn)+
        (n.antal>1?'<s>'+n.antal+' platser</s>':'')+'</li>').join('')||
        '<li><s>no match</s></li>';
      ul.querySelectorAll('li.val').forEach(li=>{
        li.onclick=ev=>{ev.stopPropagation();fraga(li.dataset.n)};
      });
    }catch(e){}
  }
  inp.oninput=()=>{clearTimeout(tm);rensa();tm=setTimeout(sok,350)};

  function fraga(namn){
    rensa();
    const d=document.createElement('div');
    d.className='konf';
    d.innerHTML='<p>Show '+(mode==='item'?'<b>var ':'<b>what is in ')+
      esc(namn)+'</b>'+(mode==='item'?' ligger':'')+'?<br>'+
      'It is recorded as a spoiler and cannot be undone.</p>'+
      '<div class="rad"><button class="ja">Yes, show it</button>'+
      '<button class="nej">Cancel</button></div>';
    ul.parentNode.insertBefore(d,ul.nextSibling);
    d.onclick=ev=>ev.stopPropagation();
    d.querySelector('.nej').onclick=()=>d.remove();
    d.querySelector('.ja').onclick=async()=>{
      d.querySelector('.rad').innerHTML='<button disabled>fetching…</button>';
      try{
        const r=await fetch(API+'api/spoilerreveal',{method:'POST',
          headers:{'Content-Type':'application/json'},
          body:JSON.stringify({seed:seed,mode:mode,namn:namn})});
        const j=await r.json();
        d.remove();
        if(j.count!=null)raknaOm(j.count);
        if(!j.ok){toast(j.message||'could not show',true);return}
        const v=document.createElement('div');
        v.className='svar';
        v.innerHTML='<b>'+esc(namn)+'</b><ul>'+(j.hits||[]).map(h=>'<li>'+
          (mode==='item'
            ? esc((h.region?h.region+' — ':'')+h.name)
            : esc(h.item))+'</li>').join('')+'</ul>';
        ul.parentNode.insertBefore(v,ul.nextSibling);
        v.onclick=ev=>ev.stopPropagation();
        sok();                       // listan far sin bock; tomt falt -> loggen
      }catch(e){d.remove();toast('could not show',true)}
    };
  }
}

function bindCards(){
  TRKS.querySelectorAll('.trk').forEach(card=>{
    const ix=+card.dataset.s,t=trkData[ix];
    if(!t)return;
    if(card.classList.contains('stub')){
      // Rita om fran datan vi redan har - ett natverksanrop bara for att
      // falla ut ett kort kostade 0,3-0,5 s helt i onodan.
      // Ett tryck ska racka. Kortet maste ocksa ut ur trkMin - vid forsta
      // laddningen faller allt utom det nyaste ihop, sa annars kommer det
      // tillbaka minimerat och man far trycka en gang till.
      card.onclick=()=>{
        trkForced.push(t.seed);
        const at=trkMin.indexOf(t.seed);
        if(at>=0)trkMin.splice(at,1);
        loadTracker(trkData)};
      return;
    }
    // Rubriken OCH synkraden faller ihop kortet. Bada behovs: rubriken
    // ensam ar en smal remsa, och trycker man strax under hander
    // ingenting - det kandes som att ihopfallning kravde tva klick.
    // Later inte "Dolj"-lanken eller knapparna triggas med.
    const vaxla=ev=>{
      const k=ev.target.classList;
      if(k.contains('hide')||k.contains('play')||k.contains('del'))return;
      // Ett tryck ska falla ihop HELA vagen. Kort som knut sjalv fallt ut
      // ur en stubbrad gar tillbaka dit direkt - det ar samma sak som
      // "Dolj"-lanken gjorde, och att forst behova minimera och sedan
      // dolja var de tva klick han retade sig pa.
      const fi=trkForced.indexOf(t.seed);
      if(fi>=0){
        trkForced.splice(fi,1);
        const am=trkMin.indexOf(t.seed);
        if(am>=0)trkMin.splice(am,1);
        loadTracker(trkData);
        return;
      }
      // Den aktiva runden har ingen stubbrad att falla tillbaka till -
      // den far det minimerade laget i stallet.
      const at=trkMin.indexOf(t.seed);
      if(at>=0)trkMin.splice(at,1); else trkMin.push(t.seed);
      if(!card.classList.toggle('min',at<0))fyll();
    };
    const th=card.querySelector('.th');
    if(th)th.onclick=vaxla;
    const sy=card.querySelector('.sync');
    if(sy)sy.onclick=vaxla;
    const fyll=()=>{
      const w=card.querySelector('.worlds');
      if(w&&!w.dataset.full){w.dataset.full='1';
        w.innerHTML=worldsHTML(t,false);bindMap(card,t);}
    };
    if(!card.classList.contains('min'))fyll();
    const db=card.querySelector('.del');
    if(db)db.onclick=ev=>{ev.stopPropagation();askDelete(t.seed,t.seed)};
    const pb=card.querySelector('.play');
    if(pb)pb.onclick=async ev=>{ev.stopPropagation();
      try{const r=await api('api/launch',{method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({core:'ALTTPR',path:t.rom})});
        const j=await r.json();toast(j.message,!j.ok)}catch(e){}};
    bindSpoiler(card,t.seed);
    if(false){
      sp.querySelector('b').onclick=ev=>{ev.stopPropagation();
        sp.classList.toggle('open')};
      sp.querySelector('.box').onclick=ev=>ev.stopPropagation();
      const inp=sp.querySelector('input'),ul=sp.querySelector('ul');
      let tm=null;
      inp.oninput=()=>{clearTimeout(tm);tm=setTimeout(async()=>{
        const q=inp.value.trim();
        if(q.length<3){ul.innerHTML='';return}
        try{
          const r=await fetch(API+'api/spoiler?seed='+encodeURIComponent(t.seed)+
            '&item='+encodeURIComponent(q));
          const j=await r.json();
          ul.innerHTML=(j.hits||[]).map(h=>'<li>'+esc(h.item)+
            '<s>'+esc(h.region)+' — '+esc(h.name)+'</s></li>').join('')||
            '<li><s>no match</s></li>';
        }catch(e){}
      },350)};
    }
    const hb=card.querySelector('.hide');
    if(hb)hb.onclick=()=>{
      trkForced=trkForced.filter(i=>i!==t.seed);loadTracker(trkData)};
    // Prickraden ar raknaren; resten av raden oppnar belongsdialogen.
    // Raden visar nu kistlistan. Kistantalen lases exakt ur SRAM, sa det
    // finns inget kvar att rakna for hand.
    bindMap(card,t);
  });
}

updateNow();setInterval(updateNow,6000);
loadSMZ3();setInterval(loadSMZ3,30000);
loadTracker(cachedTracker());   // gammal bild direkt
loadTracker();                  // farsk strax efter
setInterval(loadTracker,20000);
load();
</script>
"""
