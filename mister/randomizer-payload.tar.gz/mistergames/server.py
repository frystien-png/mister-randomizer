#!/usr/bin/env python3
"""A small web server on the MiSTer for browsing cores and ROMs
and starting a game by tapping it.

Built for phones - meant to be shown in a Webpage card in Home Assistant,
but works just as well as a bookmark on a phone or tablet.

The launch technique (verified empirically 2026-08-06):
  - write a .mgl file somewhere on the SD card
  - the path attribute is relative to the CORE'S GAMES FOLDER, not the SD root
  - send "load_core <path to mgl>" to /dev/MiSTer_cmd
  - zip files work directly, nothing has to be unpacked

Standard library only - the MiSTer has Python 3.9 but no pip.
"""

import base64
import html
import json
import os
import posixpath
import re
import socket
import socketserver
import struct
import sys
import subprocess
import threading
import time
import urllib.parse
import urllib.request
import zipfile
from http.server import BaseHTTPRequestHandler

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from page import PAGE  # noqa: E402
from seedpage import SEEDPAGE  # noqa: E402
from annotatepage import ANNOTATE  # noqa: E402
import language  # noqa: E402

PORT = 8182
GAMES = "/media/fat/games"
SAVES = "/media/fat/saves"
SAVESTATES = "/media/fat/savestates"
MGL_PATH = "/media/fat/_hagames.mgl"
MENU_RBF = "/media/fat/menu.rbf"
CMD = "/dev/MiSTer_cmd"

# folder: (rbf base name, delay, index, [extensions], setname)
# delay/index follow the MiSTer documentation: index 1 for Gameboy and NeoGeo,
# delay 2 for SNES and N64, 1 for the other consoles.
CORES = {
    "NES":       ("NES",       1, 0, ["nes", "zip", "fds"], None),
    "SNES":      ("SNES",      2, 0, ["sfc", "smc", "zip"], None),
    "GAMEBOY":   ("Gameboy",   1, 1, ["gb", "zip"], None),
    "GBC":       ("Gameboy",   1, 1, ["gbc", "zip"], "GBC"),
    "SMS":       ("SMS",       1, 0, ["sms", "zip"], None),
    "MegaDrive": ("MegaDrive", 1, 0, ["gen", "md", "bin", "zip"], None),
    "N64":       ("N64",       2, 0, ["z64", "n64", "zip"], None),
    "PSX":       ("PSX",       1, 1, ["chd", "cue"], None),
    # Saturn needs 128 MB SDRAM as the primary module, and dual modules for full
    # compatibility according to the core's README.
    "Saturn":    ("Saturn",    1, 0, ["chd", "cue"], None),
    # The remaining systems. The extensions are deliberately narrow - most ".rom"
    # files in the games folders are BIOS images, not games, and must not be listed.
    "GBA":       ("GBA",       1, 0, ["gba", "zip"], None),
    "TGFX16":    ("TurboGrafx16", 1, 0, ["pce", "sgx", "zip"], None),
    "S32X":      ("S32X",     1, 0, ["32x", "zip"], None),
    "SGB":       ("SGB",      1, 0, ["sfc", "smc", "zip"], None),
    "C64":       ("C64",      1, 1, ["d64", "g64", "t64", "prg", "crt"], None),
    "C128":      ("C128",     1, 1, ["d64", "d71", "g64", "g71", "prg"], None),
    "PET2001":   ("PET2001",  1, 1, ["d64", "d80", "d82", "prg"], None),
    "Amiga":     ("Minimig",  1, 0, ["adf"], None),
    "MACPLUS":   ("MacPlus",  1, 0, ["dsk", "img"], None),
    "X68000":    ("X68000",   1, 0, ["d88", "vhd"], None),
    "QL":        ("QL",       1, 0, ["mdv"], None),
    "TRS-80":    ("TRS-80",   1, 0, ["cas"], None),
    "TomyTutor": ("TomyTutor", 1, 0, ["cas"], None),
    "AcornAtom": ("AcornAtom", 1, 0, ["zip"], None),
    "TSConf":    ("TSConf",   1, 0, ["zip"], None),
    "ZXNext":    ("ZXNext",   1, 0, ["zip"], None),
}

# Arcade games are not ROM files but MRA recipes in /media/fat/_Arcade. They are
# loaded directly with "load_core <path to .mra>" - no MGL needed. Only the top
# level is included; _alternatives holds 1852 region and hack variants.
ARCADE_DIR = "/media/fat/_Arcade"
ARCADE_ID = "ARCADE"

# CD-based cores MOUNT the disc (type="s") instead of loading it into memory
# (type="f"). The wrong type gives you a core that starts without a game.
TYPES = {"PSX": "s", "Saturn": "s"}

ICONS = {
    "NES": "🎮", "SNES": "🕹️", "GAMEBOY": "📟", "GBC": "🌈",
    "SMS": "🎯", "MegaDrive": "🦔", "N64": "🎲", "PSX": "💿", "ARCADE": "🕹",
    "Saturn": "🪐",
    "GBA": "🔋", "TGFX16": "🌀", "S32X": "💥", "SGB": "🧩",
    "C64": "🖥", "C128": "🖥", "PET2001": "🖳", "Amiga": "🅰",
    "MACPLUS": "🍏", "X68000": "🗾", "QL": "📐", "TRS-80": "📼",
    "TomyTutor": "📼", "AcornAtom": "🌰", "TSConf": "⚡", "ZXNext": "⚡",
    "ALTTPR": "🗡️", "SMZ3": "🌌",
}

# Subfolders broken out into groups of their own in the interface. They run on
# the same core as the parent, but are listed separately and hidden from it.
# Groups collect games from one or more paths. The files are NEVER moved on
# disk - the generators still write to games/SNES/ALTTPR/<date>/ and the older
# seeds stay where they have always been. Only the presentation changes.
GROUPS = {
    "ALTTPR": ("SNES", ["ALTTPR/",
                        "Alltp Randomizer/Randomized roms/Alttp/"]),
    "SMZ3":   ("SNES", ["SMZ3/",
                        "Alltp Randomizer/Randomized roms/Both/"]),
}

# The groups are shown on the seed page rather than among the consoles.
GROUP_GEN = {"ALTTPR": "alttpr", "SMZ3": "smz3"}

# Top folders hidden from the parent's own list. Anything not picked up by a
# group disappears entirely - which is how "Alltp Randomizer/Orginal/" (the
# base ROMs) stays out of the game list.
HIDE_FROM_PARENT = {"SNES": ["ALTTPR/", "SMZ3/", "Alltp Randomizer/"]}

# File names that are never listed, whatever the core. The PS1 collection holds
# over 100 demo discs - both "<game> (Demo)" and pure demo discs such as "Euro
# Demo 82" and "McDonald's - Demo 01" - and they are not games to browse.
# The files stay where they are; they are only hidden from the index.
# The \b boundaries keep "Demolition Racer" and "Star Wars - Demolition" from
# being swept up with them.
SKIP_RE = re.compile(r"\bdemos?\b|^mister-boot\.", re.I)

# Real console names for the interface. The keys are the folder names on the
# card and must not be changed - they are used to build MGL paths.
NAMES = {
    "NES": "Nintendo Entertainment System",
    "SNES": "Super Nintendo",
    "GAMEBOY": "Game Boy",
    "GBC": "Game Boy Color",
    "SMS": "Sega Master System",
    "MegaDrive": "Sega Mega Drive",
    "N64": "Nintendo 64",
    "PSX": "PlayStation",
    "Saturn": "Sega Saturn",
    "ARCADE": "Arcade",
    "GBA": "Game Boy Advance",
    "TGFX16": "TurboGrafx-16",
    "S32X": "Sega 32X",
    "SGB": "Super Game Boy",
    "C64": "Commodore 64",
    "C128": "Commodore 128",
    "PET2001": "Commodore PET",
    "Amiga": "Amiga",
    "MACPLUS": "Macintosh Plus",
    "X68000": "Sharp X68000",
    "QL": "Sinclair QL",
    "TRS-80": "TRS-80",
    "TomyTutor": "Tomy Tutor",
    "AcornAtom": "Acorn Atom",
    "TSConf": "ZX Evolution TSConf",
    "ZXNext": "ZX Spectrum Next",
    "ALTTPR": "Zelda Randomizer",
    "SMZ3": "Zelda + Metroid Combo",
}

# Cores with fewer games than this do not get a tile of their own on the start
# page but are collected behind the "Other" tile. These are the home computers
# and the half-empty cores that would otherwise fill half the page with ones
# and twos. The server only sets the "small" flag - page.py does the grouping.
SMALL_CORE_MAX = 10

# Display order on the start page. Anything not named ends up last, alphabetically.
CORE_ORDER = ["NES", "SNES", "GAMEBOY", "GBC", "GBA", "SGB", "SMS", "MegaDrive",
              "S32X", "TGFX16", "N64", "Saturn", "PSX", "ARCADE", "Amiga",
              "C64", "C128",
              "PET2001", "MACPLUS", "X68000", "QL", "TRS-80", "TomyTutor",
              "AcornAtom", "TSConf", "ZXNext"]

# Generators that can be started from the interface.
GENERATORS = {
    "alttpr": ("Ny ALTTPR-seed", "/media/fat/Scripts/.randomizer/gen_alttpr.py"),
    "smz3": ("Ny SMZ3-seed", "/media/fat/Scripts/.randomizer/gen_smz3.py"),
}
_gen = {"running": None, "done": False, "ok": False, "message": ""}

# The result of the last finished run, per generator. _gen is wiped as soon as
# the next run starts, and the page gets exactly one chance to show its toast -
# a generator takes minutes, and nobody is watching the panel when it ends. The
# warning box on the seed page is built from this, so a reason like "samus.link
# is down" is still readable an hour later, and after a page reload.
_gen_last = {}

_index = {}
_rbf = {}
_lock = threading.Lock()


def find_rbf(basename):
    """Finds the core's rbf and returns the path without date stamp and
        file extension, the way <rbf> wants it.
    """
    for sub in ("_Console", "_Computer", "_Other", "_Utility", "_Arcade"):
        d = os.path.join("/media/fat", sub)
        if not os.path.isdir(d):
            continue
        for f in os.listdir(d):
            if f.endswith(".rbf") and re.match(
                r"^%s(_\d{8})?\.rbf$" % re.escape(basename), f
            ):
                return "%s/%s" % (sub, basename)
    return None


def scan():
    """Rebuilds the ROM index. The paths stored are relative to the
        core's games folder, which is exactly what the MGL wants.
    """
    idx, rbfs = {}, {}
    for folder, (base, delay, slot, exts, setname) in CORES.items():
        root = os.path.join(GAMES, folder)
        if not os.path.isdir(root):
            continue
        rbf = find_rbf(base)
        if not rbf:
            continue
        rbfs[folder] = rbf
        wanted = tuple("." + e for e in exts)
        games = []
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if not d.startswith(".")
                           and d.lower() not in ("palettes", "docs")]
            for fn in filenames:
                if fn.startswith(".") or SKIP_RE.search(fn):
                    continue
                if fn.lower().endswith(wanted):
                    rel = os.path.relpath(os.path.join(dirpath, fn), root)
                    games.append(rel)
        games.sort(key=lambda s: s.lower())
        all_games = list(games)
        hide = HIDE_FROM_PARENT.get(folder, [])
        if hide:
            games = [g for g in games
                     if not any(g.replace(os.sep, "/").startswith(h)
                                for h in hide)]
        for grp, (parent, prefixes) in GROUPS.items():
            if parent != folder:
                continue
            picked = [g for g in all_games
                      if any(g.replace(os.sep, "/").startswith(pre)
                             for pre in prefixes)]
            if picked:
                picked.sort(key=lambda s: s.lower())
                idx[grp] = picked
        idx[folder] = games
    if os.path.isdir(ARCADE_DIR):
        mras = sorted((f for f in os.listdir(ARCADE_DIR)
                       if f.lower().endswith(".mra")), key=str.lower)
        if mras:
            idx[ARCADE_ID] = mras

    with _lock:
        _index.clear(); _index.update(idx)
        _rbf.clear(); _rbf.update(rbfs)
    return sum(len(v) for v in idx.values())


def inne_i_zip(full, folder):
    """Path inside a .zip, or "" if it is not one.

    ⚠️ An MGL cannot mount a zip archive as such - the path has to point at the
    file INSIDE it: "Alien-3.zip/Alien-3.smc". Given only the archive, the core
    loads with no ROM at all: it looks like a game that will not start, and
    reloading it by hand from the OSD works, which sends you looking in the
    wrong place. Measured 2026-08-15 by reading the SNES header over SNI:
    zip alone gave an empty ROM area, zip/file gave "ALIEN-3".

    That is why loose files (the generated ALTTPR and SMZ3 seeds are .sfc) have
    always worked while the zipped library never did.
    """
    if not full.lower().endswith(".zip"):
        return ""
    andelser = CORES.get(folder, (None, 0, 0, [], None))[3]
    goda = tuple("." + e for e in andelser if e != "zip")
    try:
        with zipfile.ZipFile(full) as z:
            namn = [i for i in z.infolist() if not i.is_dir()]
    except (OSError, zipfile.BadZipFile):
        return ""
    if not namn:
        return ""
    traff = [i for i in namn if i.filename.lower().endswith(goda)] or namn
    # Flera filer i arkivet: den storsta ar rommen, resten ar lasmig-filer.
    traff.sort(key=lambda i: i.file_size)
    return traff[-1].filename


def to_menu():
    """Unloads whatever is running and returns to the MiSTer main menu.

    ⚠️ There is no "unload" command. /dev/MiSTer_cmd understands load_core
    and a handful of video and audio commands, nothing else - so the way back
    is to load the menu core like any other core. menu.rbf sits in the root of
    the SD card on every MiSTer.

    Same caveat as any other core switch: the FPGA holds save memory until the
    OSD is opened, so anything unsaved is lost. The page asks first.
    """
    if not os.path.isfile(MENU_RBF):
        return False, language.word("menu.rbf not found - is this a MiSTer?")
    try:
        with open(CMD, "w") as f:
            f.write("load_core %s\n" % MENU_RBF)
    except OSError as e:
        return False, language.word("could not return to the menu: %s") % e
    return True, language.word("back to the menu")


def launch(folder, relpath):
    if folder == ARCADE_ID:
        full = os.path.join(ARCADE_DIR, relpath)
        if not os.path.isfile(full):
            return False, language.word("file not found: %s") % relpath
        try:
            with open(CMD, "w") as f:
                f.write("load_core %s\n" % full)
        except OSError as e:
            return False, language.word("could not launch: %s") % e
        return True, language.word("launching %s") % os.path.splitext(relpath)[0]
    if folder in GROUPS:
        folder = GROUPS[folder][0]
    if folder not in CORES or folder not in _rbf:
        return False, language.word("unknown core: %s") % folder
    full = os.path.join(GAMES, folder, relpath)
    if not os.path.isfile(full):
        return False, language.word("file not found: %s") % relpath
    _, delay, slot, _, setname = CORES[folder]
    parts = ["<mistergamedescription>",
             "\t<rbf>%s</rbf>" % _rbf[folder]]
    if setname:
        parts.append("\t<setname>%s</setname>" % setname)
    inre = inne_i_zip(full, folder)
    mgl_path = relpath + "/" + inre if inre else relpath
    parts.append('\t<file delay="%d" type="%s" index="%d" path="%s"/>'
                 % (delay, TYPES.get(folder, "f"), slot,
                    html.escape(mgl_path, quote=True)))
    parts.append("</mistergamedescription>")
    try:
        with open(MGL_PATH, "w") as f:
            f.write("\n".join(parts) + "\n")
        with open(CMD, "w") as f:
            f.write("load_core %s\n" % MGL_PATH)
    except OSError as e:
        return False, language.word("could not launch: %s") % e
    return True, language.word("launching %s") % os.path.basename(relpath)


# Why a generator failed, as the page shows it. The generator works out WHAT
# went wrong (net_reason.py in .randomizer/) and hands back the facts on a
# REASON line; the sentence is put together here so it can be translated -
# lang_check only looks for keys in the pages and in server.py.
#
# ⚠️ One string per line: lang_check greps the source for every key. Keep them
# in step with TEXTS in net_reason.py, which is what the Scripts menu shows.
GEN_REASONS = {
    "cert_expired": "%(host)s's security certificate expired on %(date)s, so the connection is refused. The fault is on %(host)s's side - try again once they have renewed it.",
    "cert_expired_nodate": "%(host)s's security certificate has expired, so the connection is refused. The fault is on %(host)s's side - try again once they have renewed it.",
    "clock": "The MiSTer's clock says %(now)s, so %(host)s's certificate cannot be checked. The clock is set from the network at boot - check the network and restart the MiSTer.",
    "cert": "%(host)s's security certificate could not be verified (%(detail)s), so the connection is refused.",
    "offline": "Could not reach %(host)s. Check that the MiSTer has network.",
    "timeout": "%(host)s did not answer in time. The site may be slow or down - try again later.",
    "http": "%(host)s answered with an error (HTTP %(code)s). The fault is on %(host)s's side, not the MiSTer's - try again later.",
    "other": "The download from %(host)s failed: %(detail)s",
}


def _gen_failure(stdout, stderr):
    """The sentence to show for a failed generator run.

        In order: the generator's REASON line, translated; its "ERROR:" line
        from die(); the last line on stderr (a crash); a plain "failed".

        ⚠️ This used to look for lines starting with "FEL". The generators were
        translated to English and print "ERROR:", so every failure - an expired
        certificate included - came out as a bare "generation failed".
    """
    for line in reversed((stdout or "").splitlines()):
        if not line.startswith("REASON "):
            continue
        try:
            facts = json.loads(line[len("REASON "):])
            template = GEN_REASONS[facts["kind"]]
            english = template % facts
        except (ValueError, KeyError, TypeError):
            break
        try:
            return language.word(template) % facts
        except (ValueError, KeyError, TypeError):
            # A translation with a broken placeholder must not hide the reason.
            return english
    raw = (stdout or "").splitlines()
    for i, line in enumerate(raw):
        if line.startswith("ERROR:"):
            # die() continues on indented lines ("expected ... got ...").
            parts = [line[len("ERROR:"):].strip()]
            for more in raw[i + 1:]:
                if not more.startswith(" ") or not more.strip():
                    break
                parts.append(more.strip())
            return " ".join(parts)
    errs = [l.strip() for l in (stderr or "").splitlines() if l.strip()]
    return errs[-1] if errs else language.word("Generation failed.")


def run_generator(kind):
    """Starts a seed generator in the background. One at a time only."""
    label, script = GENERATORS[kind]

    def work():
        try:
            # RANDOMIZER_REASON asks for the machine-readable REASON line. From
            # the Scripts menu it is unset and the terminal stays readable.
            proc = subprocess.run(["python3", script], capture_output=True,
                                  text=True, timeout=900,
                                  env=dict(os.environ, RANDOMIZER_REASON="1"))
            ok = proc.returncode == 0
            if ok:
                lines = [l.strip() for l in (proc.stdout or "").splitlines() if l.strip()]
                msg = next((l for l in reversed(lines) if l.startswith("Filed under")),
                           lines[-1] if lines else language.word("Done."))
            else:
                msg = _gen_failure(proc.stdout, proc.stderr)
        except subprocess.TimeoutExpired:
            ok, msg = False, language.word("The generator took too long.")
        except OSError as e:
            ok, msg = False, str(e)
        scan()                      # so the new seed shows up immediately
        with _lock:
            _gen.update(running=None, done=True, ok=ok, message=msg)
            _gen_last[kind] = {"ok": ok, "message": msg, "when": time.time()}

    with _lock:
        if _gen["running"]:
            return False, language.word("A generation is already running.")
        _gen.update(running=kind, done=False, ok=False, message="")
    threading.Thread(target=work, daemon=True).start()
    return True, label




# --- ALTTPR tracker -------------------------------------------------------
# Reads SRAM out of a save file and reports WHERE the player has been - never
# what was lying there, so the spoiler stays intact.
#
#   0x000-0x24F  room flags, 2 bytes per room -> room = offset // 2
#   0x280-0x2FF  overworld flags, 1 byte per screen; 0x00-0x3F light world
#                as an 8x8 grid, 0x40-0x7F dark world
#   0x2000       ASCII "VT <seedid>" - ALTTPR stamps the seed here, which lets
#                us pair save file and spoiler file automatically
#   0x4000+      an identical backup copy, useful for spotting a broken write
#
# The meaning of the bits is measured by diffing two save files, not guessed:
# overworld bit 0x40 = item picked up. The exact meaning of the room bits
# (chest/door/room part) is not fully mapped - which is why "visited" is
# reported per room, not a chest count.
SRAM_OW, SRAM_OW_END = 0x280, 0x300
# The last byte we need for chest flags. The NPC flags sit at 0x410-0x411 and
# the shops at 0x3c9, well past the overworld block.
SRAM_FLAGS_END = 0x420
SRAM_ROOM_END = 0x250
SRAM_SEED = 0x2000


def _seed_tag(b):
    tag = b[SRAM_SEED:SRAM_SEED + 0x16].decode("ascii", "replace")
    if not tag.startswith("VT "):
        return ""
    out = ""
    for ch in tag[3:]:
        if not ch.isalnum():
            break
        out += ch
    return out


# --- live reading of SNES memory via SNI -----------------------------------
# The MiSTer writes the save file to the SD card ONLY WHEN THE OSD IS OPENED.
# The file is therefore often old, and the tracker has always lagged behind
# whatever you just did.
#
# Run the SNES core with UART MODE = SNI and snid listens on 127.0.0.1:23074
# read SRAM straight out of the running machine. We speak the QUsb2snes
# protocol over WebSocket - handshake and framing fit in ~60 lines, and the
# alternative (SNI's gRPC on 8191) would have needed packages we do not have.
#
# ⚠️ The UART is SLOW: measured at ~11 KB/s. 80 bytes take 9 ms, but 8 KB
#    take 0.7 s. Only what is genuinely needed is therefore read, and the
#    seed stamp (22 bytes) is checked FIRST - if it does not match the save
#    file we are working on, the big block never has to be fetched at all.
#
# ⚠️ Requires the user to have picked UART MODE -> SNI in the OSD once. The
#    choice is stored per core in /media/fat/config/uartmode.SNES and is
#    restored automatically afterwards. Not reaching snid is not an error -
#    the save file is then used exactly as before.
SNI_ADDR = ("127.0.0.1", 23074)
SNI_TTL = 2.0            # sekunder ett livesvar aterbrukas
SNI_BACKOFF = 20.0       # sekunder innan nytt forsok efter ett misslyckande
SNI_SRAM = 0xE00000      # QUsb2snes adressrymd: ROM 0x0, SRAM 0xE00000

_sni_lock = threading.Lock()
_sni_cache = {}          # nyckel -> (tidpunkt, varde)
_sni_dead = [0.0]        # nar vi senast gav upp


def _ws_send(sock, text, op=0x81):
    """Sends a frame. Client frames MUST be masked according to RFC 6455.

        op is 0x81 for text and 0x88 for close.
    """
    p = text.encode() if isinstance(text, str) else text
    n = len(p)
    head = bytearray([op])                         # FIN + opkod
    if n < 126:
        head.append(0x80 | n)
    elif n < 65536:
        head.append(0x80 | 126)
        head += struct.pack(">H", n)
    else:
        head.append(0x80 | 127)
        head += struct.pack(">Q", n)
    m = os.urandom(4)
    head += m
    sock.sendall(bytes(head) + bytes(p[i] ^ m[i % 4] for i in range(n)))


def _ws_recv(sock):
    """Receives a frame and returns the payload."""
    def need(k):
        buf = b""
        while len(buf) < k:
            bit = sock.recv(k - len(buf))
            if not bit:
                raise IOError("snid stangde forbindelsen")
            buf += bit
        return buf

    h = need(2)
    n = h[1] & 0x7F
    if n == 126:
        n = struct.unpack(">H", need(2))[0]
    elif n == 127:
        n = struct.unpack(">Q", need(8))[0]
    if h[1] & 0x80:          # servern ska inte maska, men var beredd
        m = need(4)
        d = need(n)
        return bytes(d[i] ^ m[i % 4] for i in range(n))
    return need(n) if n else b""


def _sni_read(blocks):
    """[(address, count), ...] -> [bytes, ...], or None if SNI is absent.

        Opens a new connection per call. That sounds wasteful, but the health
        of a long-lived socket has to be checked anyway, and snid changes state
        as soon as you switch core.
    """
    sock = None
    try:
        sock = socket.create_connection(SNI_ADDR, timeout=4)
        sock.settimeout(6)
        key = base64.b64encode(os.urandom(16)).decode()
        sock.sendall((
            "GET / HTTP/1.1\r\n"
            "Host: %s:%d\r\n"
            "Upgrade: websocket\r\n"
            "Connection: Upgrade\r\n"
            "Sec-WebSocket-Key: %s\r\n"
            "Sec-WebSocket-Version: 13\r\n\r\n"
            % (SNI_ADDR[0], SNI_ADDR[1], key)).encode())
        buf = b""
        while b"\r\n\r\n" not in buf:
            bit = sock.recv(1024)
            if not bit:
                raise IOError("ingen handskakning")
            buf += bit
        if b" 101" not in buf.split(b"\r\n")[0]:
            raise IOError("snid nekade uppgraderingen")

        _ws_send(sock, json.dumps({"Opcode": "DeviceList", "Space": "SNES"}))
        devs = json.loads(_ws_recv(sock).decode()).get("Results") or []
        if not devs:
            return None
        _ws_send(sock, json.dumps({"Opcode": "Attach", "Space": "SNES",
                                   "Operands": [devs[0]]}))
        out = []
        for adr, n in blocks:
            _ws_send(sock, json.dumps({
                "Opcode": "GetAddress", "Space": "SNES",
                "Operands": ["%X" % adr, "%X" % n]}))
            data = b""
            while len(data) < n:
                data += _ws_recv(sock)
            out.append(data[:n])
        return out
    except (OSError, IOError, ValueError, KeyError, IndexError):
        return None
    finally:
        if sock is not None:
            # Polite shutdown before we close. Without it snid logs one ERROR per
            # connection ("Connection reset without closing handshake"). The reads
            # went through anyway, but the log filled up with noise that confuses
            # the next person debugging something in there.
            try:
                _ws_send(sock, struct.pack(">H", 1000), 0x88)   # 1000 = normal
            except OSError:
                pass
            try:
                sock.close()
            except OSError:
                pass


def _sni_cached(nyckel, blocks, ttl=SNI_TTL):
    """Cached SNI call with backoff. None when SNI is unavailable."""
    nu = time.time()
    with _sni_lock:
        traff = _sni_cache.get(nyckel)
        if traff and nu - traff[0] < ttl:
            return traff[1]
        if nu - _sni_dead[0] < SNI_BACKOFF:
            return None
    res = _sni_read(blocks)
    with _sni_lock:
        if res is None:
            # Backoff, or every page load costs one failed connection per save
            # file whenever the SNES core is not running.
            _sni_dead[0] = time.time()
            return None
        _sni_cache[nyckel] = (time.time(), res)
    return res


def live_seed():
    """The seed id of the ALTTPR seed running right NOW, or "".

        Only 22 bytes over the UART - cheap enough to ask often.
    """
    res = _sni_cached("tag", [(SNI_SRAM + SRAM_SEED, 0x16)])
    if not res:
        return ""
    tagg = bytearray(SRAM_SEED + 0x16)
    tagg[SRAM_SEED:SRAM_SEED + 0x16] = res[0]
    return _seed_tag(bytes(tagg))


def live_sram():
    """The ALTTP state from the running machine, in the save file's shape.

        WRAM first - it is the only source updated continuously. If the Zelda
        half is not running (max hearts = 0) we fall back on SRAM, which at
        least mirrors the last in-game save.
    """
    res = _sni_cached("sram", [(ALTTP_WRAM, 0x518),
                               (SNI_SRAM, 0x518),
                               (SNI_SRAM + SRAM_SEED, 0x16)])
    if not res:
        return None
    wram, sram, tagg = res
    kalla = wram if _alttp_kor(wram[ALTTP_HEARTS]) else sram
    b = bytearray(0x4518)
    b[0:0x518] = kalla
    b[SRAM_SEED:SRAM_SEED + 0x16] = tagg
    b[0x4000:0x4518] = kalla         # sa att "intact" blir sant, se ovan
    return bytes(b)


SNI_ROM_TAG = 0xFFC0     # SNES-rubriken i ROM:en
SNI_TAG_LEN = 0x20

# --- WRAM: the only source that is TRULY live ------------------------------
# Three levels, measured 2026-08-13 while the player was playing:
#
#   WRAM   updated continuously            <- truly live
#   SRAM   updated when the player saves IN THE GAME
#   .sav   updated when the OSD is opened
#
# The proof: the player picked up a missile tank. WRAM said max missiles 75,
# SRAM and the file said 70. Reading SRAM and calling it "live" is therefore
# wrong - it gives you the last in-game save.
#
# ⚠️ WRAM mirrors ONLY the half that is running. During SMZ3's Metroid half
# the entire Zelda inventory at $7EF340 is zeroed; read WRAM blindly there
# and the Zelda side looks empty - WORSE than SRAM. Detect the half first.
WRAM = 0xF50000
ALTTP_WRAM = WRAM + 0xF000     # $7EF000 speglar sparstrukturen 0x000-0x4FF
ALTTP_HEARTS = 0x36C           # max hjartan; alltid >0 nar ALTTP kor
SM_WRAM_SAVE = WRAM + 0x09A2   # speglar sparplatsen fran ammo-0x20
SM_WRAM_SAVE_N = 0x30
SM_WRAM_LOCS = WRAM + 0xD870   # speglar platsflaggorna (bits-blocket)
SM_WRAM_LOCS_N = 0x14
SM_WRAM_BOSS = WRAM + 0xD828   # bossflaggorna, se SM_BOSS_FLAGGA
SM_WRAM_BOSS_N = 0x08
SM_MAXENERGI = WRAM + 0x09C4   # alltid >=99 nar Super Metroid kor


def _alttp_kor(hjartan):
    """Is the ALTTP half running right now? Decided by max hearts.

        ⚠️ PLAUSIBILITY, not "different from zero". The dormant half's WRAM area
        contains garbage, not zeros. ALTTP starts at 3 hearts and can hold at
        most 20, and each container is 8 - so 0x18..0xA0 evenly divisible by 8.
        Garbage hits that range only by chance.
    """
    return 0x18 <= hjartan <= 0xA0 and hjartan % 8 == 0


def _sm_kor(maxenergi):
    """Is the Super Metroid half running right now? Decided by max energy.

        The same plausibility test sm_slot() uses to pick a save slot:
        99 at the start, at most 1499, always ending in 99.

        ⚠️ Measured 2026-08-13 with the Zelda half running: the field read
        61440. A non-zero test would therefore have said yes.
    """
    return 99 <= maxenergi <= 1499 and maxenergi % 100 == 99

# SMZ3's SRAM, only the parts that are actually read. The whole save file is
# 32 KB and would have taken 3 s over the UART; this is 1928 bytes, so ~0.2 s.
#
# ⚠️ Every save-slot window must start 0x20 bytes BEFORE the ammo base.
# _smz3_items() reads the equipment bitfields at ammo-0x20 and ammo-0x1C, and
# a window that starts at the ammo base itself loses them silently - Morph,
# Varia, Gravity and others would have looked uncollected forever.
SMZ3_LIVE_BLOCKS = ((0x0000, 0x518),    # Zelda-halvan, samma offsets som ALTTP
                    (0x1120, 0xD0),     # sparplats 3: ammo 0x1140, bitar 0x11D0
                    (0x2010, 0xD0),     # sparplats 1: ammo 0x2030, bitar 0x20C0
                    (0x3900, 0xD0))     # sparplats 2: ammo 0x3920, bitar 0x39B0


def live_rom_tag():
    """The ROM header from the running machine, or b"".

        ⚠️ SMZ3 stamps NO seed id into SRAM the way ALTTPR does at 0x2000 -
        there is binary garbage there. Every seed does get its own SNES header
        ("ZSM11.3.2CN159255D4"), and SNI's ROM space sits at the same offsets as
        the file. The header can therefore be compared against the file on disk.
    """
    res = _sni_cached("romtag", [(SNI_ROM_TAG, SNI_TAG_LEN)], ttl=10.0)
    return res[0] if res else b""


def rom_tag(path):
    """Samma rubrik, men ur en fil pa kortet."""
    try:
        with open(path, "rb") as f:
            f.seek(SNI_ROM_TAG)
            return f.read(SNI_TAG_LEN)
    except OSError:
        return b""


def live_smz3_raw():
    """SMZ3's SRAM from the running machine, in the same shape the file is read.

        Unread areas are left as zeros. That is safe: sm_slot() requires the max
        energy to be 99..1499 and divisible by 100 with remainder 99, so a
        zeroed area can never be chosen by mistake.
    """
    blocks = [(SNI_SRAM + a, n) for a, n in SMZ3_LIVE_BLOCKS]
    blocks += [(ALTTP_WRAM, 0x518),                    # Zelda live
               (SM_WRAM_SAVE, SM_WRAM_SAVE_N),         # Metroid live: utrustning
               (SM_WRAM_LOCS, SM_WRAM_LOCS_N),         # Metroid live: platser
               (SM_WRAM_BOSS, SM_WRAM_BOSS_N)]         # Metroid live: bossar
    res = _sni_cached("smz3", blocks)
    if not res:
        return None
    b = bytearray(0x8000)
    for (a, n), d in zip(SMZ3_LIVE_BLOCKS, res):
        b[a:a + n] = d
    zel_w, sm_save, sm_locs, sm_boss = res[len(SMZ3_LIVE_BLOCKS):]

    # Zelda half: WRAM wins while it is running. With the Metroid half running
    # the $7EF340 block is zeroed, and SRAM then has to be kept.
    #
    # ⚠️ The check has to be PLAUSIBILITY, not "different from zero". While one
    # half runs, the other half's WRAM area contains GARBAGE, not zeros -
    # measured 2026-08-13: with Zelda running, SM's max energy read 61440.
    # A non-zero test would have laid that garbage over the saved data.
    if _alttp_kor(zel_w[ALTTP_HEARTS]):
        b[0:0x518] = zel_w

    # Metroid half: the same thing, except the save slot has to be found first -
    # the WRAM mirror does not know which of the three slots it belongs to.
    # ⚠️ Max energy sits at ammo+2, and the mirror starts at ammo-0x20 - so
    # index 0x22, not 2. Index 2 is beam weapons and would have turned the
    # check into a pure random value.
    slot = sm_slot(list(b))
    if slot and _sm_kor(sm_save[0x22] | (sm_save[0x23] << 8)):
        ammo, bits = slot
        b[ammo - 0x20:ammo - 0x20 + SM_WRAM_SAVE_N] = sm_save
        b[bits:bits + SM_WRAM_LOCS_N] = sm_locs
        # ⚠️ The boss flags too, or a boss felled since the last in-game save
        # keeps its colour until the player saves - which is exactly the lag
        # the live path exists to remove.
        bo = bits + SM_BOSS_OFF
        b[bo:bo + SM_WRAM_BOSS_N] = sm_boss
    return list(b)


def read_save(path):
    """Decodes a save file.

        If the same seed is running right now with SNI enabled, LIVE memory
        wins: the file on the card is then older than what the player has
        actually done. If SNI does not answer, or a different seed is running,
        the file is used as before.
    """
    try:
        with open(path, "rb") as f:
            b = f.read()
    except OSError:
        return None
    if len(b) < 0x4518:
        return None
    egen = _seed_tag(b)
    if egen and egen == live_seed():
        levande = live_sram()
        if levande:
            d = _decode_save(levande, path)
            if d:
                d["live"] = True
                d["synced"] = time.time()
                return d
    return _decode_save(b, path)


def _decode_save(b, path):
    """Decodes the SRAM contents. Returns None if it is not ALTTP."""
    if len(b) < 0x4518:
        return None
    lw = [False] * 64
    dw = [False] * 64
    items = 0
    for i in range(SRAM_OW_END - SRAM_OW):
        v = b[SRAM_OW + i]
        if not v:
            continue
        (lw if i < 64 else dw)[i % 64] = True
        if v & 0x40:
            items += 1
    visited = [r for r in range(SRAM_ROOM_END // 2)
               if b[r * 2] or b[r * 2 + 1]]
    return {
        "seed": _seed_tag(b),
        "intact": b[0x0000:0x0518] == b[0x4000:0x4518],
        "lw": lw, "dw": dw,
        "screens": sum(lw) + sum(dw),
        "ow_items": items,
        "rooms": len(visited),
        "visited": visited,
        "ow_raw": list(b[SRAM_OW:SRAM_OW_END]),
        # The room and overworld block, plus the NPC and misc flags.
        # The chest flags point into all three: 0x05e for caves, 0x226 for
        # overworld items, 0x3c9 for shops and 0x410-0x411 for NPCs
        # (Mushroom, Library, Sick Kid ...). If the window only reached
        # SRAM_OW_END the last ones were read silently as zero - chest_state()
        # skips offsets outside raw.
        "raw": list(b[0:SRAM_FLAGS_END]),
        # The inventory block: both for ticking unique items off exactly and
        # for evaluating the reachability logic.
        "inv": {o: b[o] for o in
                set(UNIQUE_ITEMS.values()) | {i[2] for i in LOGIC_ITEMS}
                | set(BOTTLE_SLOTS)},
        "klar": zelda_klar(b),
        "hearts": b[0x36C] // 8,
        "rupees": b[0x360] | (b[0x361] << 8),
        "synced": os.path.getmtime(path),
        # True when the contents were read from the running machine rather than
        # from the file. read_save() resets it; only the file path arrives here.
        "live": False,
    }


# --- annotation: the player marks where on the map each location sits ------
# Only location NAMES leave the server, never what is lying there - the
# spoiler stays intact. The result is the table location name -> map
# coordinate, which lets the tracker show real dots instead of an abstract grid.
ANNO_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "annotations.json")
# Regions that actually appear on the overworld map come first, so the most
# useful data is collected even if the player stops halfway.
ANNO_ORDER = ["Light World", "Dark World", "Death Mountain", "Special"]
ANNO_SKIP = {"playthrough", "meta", "Bosses", "Shops", "Equipped"}
_anno_lock = threading.Lock()


def _spoiler_for(seed):
    """Finds the spoiler txt belonging to a seed id."""
    for grp in ("ALTTPR", "SMZ3"):
        root = os.path.join(GAMES, "SNES", grp)
        for dp, _dn, fns in os.walk(root):
            for fn in fns:
                if fn.endswith(".txt") and seed and seed in fn:
                    return os.path.join(dp, fn)
    return None


def _load_anno():
    try:
        with open(ANNO_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def locations():
    """Location names from the newest seed's spoiler, plus markers already saved."""
    seeds = tracker()
    seed = seeds[0]["seed"] if seeds else ""
    path = _spoiler_for(seed)
    out = []
    if path:
        try:
            with open(path) as f:
                data = json.load(f)
        except (OSError, ValueError):
            data = {}
        # The dungeon entrances first: only 13 taps, and they let the map show
        # "Y/X" where the dungeon actually is.
        for name in DUNGEONS:
            if isinstance(data.get(name), dict):
                out.append({"region": DUNGEON_REGION, "name": name})
        regions = [r for r in ANNO_ORDER if r in data]
        regions += [r for r in data
                    if r not in ANNO_SKIP and r not in regions
                    and isinstance(data[r], dict)]
        for reg in regions:
            for key in data[reg]:
                # The keys look like "Sahasrahla's Hut - Left:1"
                out.append({"region": reg, "name": key.rsplit(":", 1)[0]})
    # The Metroid locations come from Archipelago's table, not from the spoiler -
    # they are the same in every seed. "world" is the map they belong to.
    # Every Metroid location is marked on the WORLD MAP. The area maps have been
    # removed - one map is enough, and it is the one worth looking at.
    for namn, (_lid, area) in sorted(SMLOCS.items(),
                                     key=lambda kv: (kv[1][1], kv[0])):
        out.append({"region": "Metroid", "name": namn,
                    "area": area, "world": "metroid"})
    # The doors - between the games, and Light -> Dark World. "world"
    # preselects the right map in the annotation tool, exactly as the Metroid
    # locations do.
    for namn, (pa, _till) in sorted({**SMZ3_PORTALER,
                                     **ZELDA_PORTALER}.items()):
        out.append({"region": PORTAL_REGION, "name": namn,
                    "world": "metroid" if pa == "sm" else pa})
    saved = _load_anno()
    return {"seed": seed, "locations": out,
            "saved": [{"region": k.split("|", 1)[0],
                       "name": k.split("|", 1)[1], "pos": v}
                      for k, v in saved.items()],
            "items": [{"id": i[0], "name": i[1]} for i in LOGIC_ITEMS],
            "logic": _load_logic()}


def annotate(region, name, pos):
    key = "%s|%s" % (region, name)
    with _anno_lock:
        data = _load_anno()
        if pos is None:
            data.pop(key, None)
        else:
            data[key] = pos
        tmp = ANNO_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=1, sort_keys=True)
        os.replace(tmp, ANNO_FILE)
        return len(data)


# Dungeons in game order. The chest count comes from the seed's spoiler and is
# therefore always right for that seed - Ganons Tower, for one, varies.
DUNGEONS = ["Hyrule Castle", "Castle Tower", "Eastern Palace", "Desert Palace",
            "Tower Of Hera", "Dark Palace", "Swamp Palace", "Skull Woods",
            "Thieves Town", "Ice Palace", "Misery Mire", "Turtle Rock",
            "Ganons Tower"]
# Room ranges per dungeon. Filled in empirically: the rooms that turn up
# between two syncs belong to the dungeon played in between. If a dungeon is
# missing here the interface shows "?/X" rather than inventing a number.
DUNGEON_ROOMS = {}


# The dungeon entrances are marked as a "region" of their own in the
# annotation tool. The geography is the same in every seed - only the
# contents are shuffled - so marking them once covers every future run.
DUNGEON_REGION = "Dungeons"

# Boss defeated + which reward the dungeon gave. Unlike the map markers this
# is SEED-SPECIFIC - the rewards are shuffled.
# The player fills it in after clearing a dungeon; reading it out of the
# spoiler would be spoiling.
PROG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "progress.json")
REWARDS = ["Pendant of Courage", "Pendant of Power", "Pendant of Wisdom",
           "Crystal 1", "Crystal 2", "Crystal 3", "Crystal 4",
           "Crystal 5", "Crystal 6", "Crystal 7"]
_prog_lock = threading.Lock()


def _load_prog():
    try:
        with open(PROG_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def set_progress(seed, dungeon, boss, reward, found=None):
    key = "%s|%s" % (seed, dungeon)
    with _prog_lock:
        data = _load_prog()
        cur = data.get(key, {})
        if found is None:
            found = cur.get("found")
        if not boss and not reward and not found:
            data.pop(key, None)
        else:
            data[key] = {"boss": bool(boss), "reward": reward or "",
                         "found": found or 0}
        tmp = PROG_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=1, sort_keys=True)
        os.replace(tmp, PROG_FILE)
        return len(data)


def dungeons(seed, visited, raw=None, inv=None, fresh=True):
    """Chests per dungeon from the spoiler, plus how many rooms were visited there."""
    path = _spoiler_for(seed)
    counts = {}
    if path:
        try:
            with open(path) as f:
                data = json.load(f)
        except (OSError, ValueError):
            data = {}
        for name in DUNGEONS:
            if isinstance(data.get(name), dict):
                counts[name] = len(data[name])
    seen = set(visited)
    _prz = _prizes_for_seed(seed, raw or [])
    anno = _load_anno()
    prog = _load_prog()
    medals = _load_medals()
    out = []
    for name in DUNGEONS:
        if name not in counts:
            continue
        rooms = DUNGEON_ROOMS.get(name)
        p = prog.get("%s|%s" % (seed, name), {})
        # The chests are now read exactly from SRAM via Archipelago's flag table.
        # The spoiler gives which locations the seed has, minus Boss and Prize which
        # are not chests - the old counter included them and therefore showed
        # "0/7" for a dungeon with five chests.
        dc = dungeon_chests(seed, name, raw, inv if fresh else None, _prz)
        exact = dc["total"] > 0
        out.append({"name": name,
                    "chests": dc["total"] if exact else counts[name],
                    "found": (dc["open"] if exact else
                              (p["found"] if "found" in p
                               else (len(seen & set(rooms)) if rooms else None))),
                    "pos": anno.get("%s|%s" % (DUNGEON_REGION, name)),
                    "boss": p.get("boss", False),
                    # SRAM knows whether the boss is actually beaten; the player's tick
                    # means "known reward" in practice.
                    "boss_sram": boss_beaten(name, raw or []),
                    "state": dc["state"],
                    # The player's own note wins, otherwise the spoiler.
                    "reward": p.get("reward") or prize_of(seed, name),
                    # None = ingen medaljongdungeon; "" = okand
                    "medal_key": MEDAL_DUNGEON.get(name),
                    "medallion": medals.get(
                        "%s|%s" % (seed, MEDAL_DUNGEON.get(name, "")), "")})
    return out


# Unique items: they occur exactly once per seed, so "the player has the item"
# means the same as "the location is ticked off" - exact, not approximated.
# The key is the spoiler's name, the value is the SRAM offset that is non-zero
# when you have it. Verified against a real inventory 2026-08-08: bow (0x340),
# hookshot (0x342), quake (0x349) and hammer (0x34B) confirmed on screen, and
# items that are missing read zero. The rest follows the same documented block.
#
# Progressive items (sword/shield/mail) and junk (rupees/arrows) are
# deliberately NOT here - they cannot be derived, so screen guessing stands.
UNIQUE_ITEMS = {
    "Bow": 0x340, "ProgressiveBow": 0x340,
    "Hookshot": 0x342,
    "Mushroom": 0x344, "Powder": 0x344,
    "FireRod": 0x345, "IceRod": 0x346,
    "Bombos": 0x347, "Ether": 0x348, "Quake": 0x349,
    "Lamp": 0x34A, "Hammer": 0x34B,
    "OcarinaInactive": 0x34C, "OcarinaActive": 0x34C, "Flute": 0x34C,
    "BugCatchingNet": 0x34D, "BookOfMudora": 0x34E,
    "CaneOfSomaria": 0x350, "CaneOfByrna": 0x351,
    "Cape": 0x352, "MagicMirror": 0x353,
    "PegasusBoots": 0x355, "Flippers": 0x356, "MoonPearl": 0x357,
}


# Manually ticked locations. SEED-specific - whether a chest is open is not
# shuffled, but it obviously only applies to that run. Used for the locations
# we cannot derive exactly (junk and progressive items).
CHECK_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "checks.json")
_check_lock = threading.Lock()


def _load_checks():
    try:
        with open(CHECK_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def set_check(seed, region, name, is_open):
    key = "%s|%s|%s" % (seed, region, name)
    with _check_lock:
        data = _load_checks()
        # Tri-state: True = ticked by hand, False = explicitly NOT
        # ticked (beats the derivation), key missing = no opinion.
        data[key] = bool(is_open)
        tmp = CHECK_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=1, sort_keys=True)
        os.replace(tmp, CHECK_FILE)
        return len(data)


# Vocabulary for the reachability logic. Only items we can actually read from
# SRAM are meaningful as requirements - or the condition cannot be evaluated.
# (id, display name, offset, minimum value)
# ⚠️ The bottles sit in FOUR slots, one byte each (0 = no bottle, otherwise
# the contents). The count is written nowhere - 0x34F is only which bottle is
# SELECTED, not how many you have. Archipelago's rule for Sick Kid is
# `state.has_group("Bottles")`, that is "any bottle at all", so a single
# offset in LOGIC_ITEMS is not enough: a bottle in a later slot would have
# been missed. Handled separately in _ap_items and _smz3_items.
#
# Found 2026-08-13: the player had two bottles (0x35C and 0x35D) but Sick Kid
# showed red, because the table did not mention bottles at all.
BOTTLE_SLOTS = (0x35C, 0x35D, 0x35E, 0x35F)

LOGIC_ITEMS = [
    ("bottle", "Bottle", 0x35C, 1),
    ("boots", "Pegasus Boots", 0x355, 1),
    ("gloves", "Power Glove", 0x354, 1),
    ("mitt", "Titan's Mitts", 0x354, 2),
    ("flippers", "Flippers", 0x356, 1),
    ("pearl", "Moon Pearl", 0x357, 1),
    ("mirror", "Magic Mirror", 0x353, 1),
    ("hammer", "Hammer", 0x34B, 1),
    ("hookshot", "Hookshot", 0x342, 1),
    ("lamp", "Lamp", 0x34A, 1),
    ("firerod", "Fire Rod", 0x345, 1),
    ("icerod", "Ice Rod", 0x346, 1),
    ("somaria", "Cane of Somaria", 0x350, 1),
    ("byrna", "Cane of Byrna", 0x351, 1),
    ("cape", "Cape", 0x352, 1),
    ("book", "Book of Mudora", 0x34E, 1),
    ("net", "Bug Net", 0x34D, 1),
    # 0x34C is shared: 1 = shovel, 2 = flute, 3 = activated flute. The shovel also
    # has a bit of its own in 0x38C, so both can be held at the same time.
    ("flute", "Flute", 0x34C, 2),
    ("shovel", "Shovel", 0x38C, 1),
    ("bow", "Bow", 0x340, 1),
    ("boomerang", "Boomerang", 0x341, 1),
    ("bombs", "Bombs", 0x343, 1),
    # 0x344 is shared: 1 = mushroom, 2 = powder. ">= 1" claimed the player had
    # powder the moment the mushroom was picked up, turning Magic Bat green.
    ("powder", "Magic Powder", 0x344, 2),
    ("mushroom", "Mushroom", 0x344, 1),
    ("bombos", "Bombos", 0x347, 1),
    ("ether", "Ether", 0x348, 1),
    ("quake", "Quake", 0x349, 1),
    ("sword", "Sword", 0x359, 1),
    ("mastersword", "Master Sword", 0x359, 2),
]
LOGIC_BY_ID = {i[0]: i for i in LOGIC_ITEMS}

# Requirements per location. SEED-INDEPENDENT, exactly like the map positions:
# what it takes to GET to a location is a property of the world, only
# innehallet slumpas om. Format: {"Region|Plats": {"all": [id], "any": [id]}}
# Satisfied when everything in "all" is held AND at least one in "any" (an empty list = no requirement).
LOGIC_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "logic.json")
_logic_lock = threading.Lock()


def _load_logic():
    try:
        with open(LOGIC_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def set_logic(region, name, req_all, req_any):
    key = "%s|%s" % (region, name)
    with _logic_lock:
        data = _load_logic()
        if not req_all and not req_any:
            data.pop(key, None)
        else:
            data[key] = {"all": req_all, "any": req_any}
        tmp = LOGIC_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=1, sort_keys=True)
        os.replace(tmp, LOGIC_FILE)
        return len(data)
# Archipelago's ALTTP logic, via reachd.py on the logic server. It can answer
# what a hand-written logic.json never will: all 107 locations, with
# riktiga regler validerade av 169 grona tester.
#
# It lives there and not here because Archipelago needs Python 3.11+ and the
# MiSTer has 3.9.6. That server is on around the clock, so the phone works
# even when the desktop is switched off.
# ⚠️ No real address as the default. It is set by randomizer.conf, which the
# installer writes - a hardcoded address from a home network would both be
# shipped out with the package and quietly pointed at the wrong machine for
REACHD_URL = os.environ.get("REACHD_URL", "http://127.0.0.1:8183/reach")
_ap_cache = {}
_ap_down_until = [0.0]


# The interface's reward vocabulary -> Archipelago's. The crystals are named
# the same; the pendants are not.
# Bit position -> Archipelago's dungeon name. Verified 2026-08-09: the save
# held exactly the ten dungeons that had been cleared, and lacked Misery
# Mire, Turtle Rock and Ganons Tower. Castle Tower and Sewers have no big key in AP.
BIG_KEY_BITS = [
    (0x4000, "Hyrule Castle"), (0x2000, "Eastern Palace"),
    (0x1000, "Desert Palace"), (0x0400, "Swamp Palace"),
    (0x0200, "Palace of Darkness"), (0x0100, "Misery Mire"),
    (0x0080, "Skull Woods"), (0x0040, "Ice Palace"),
    (0x0020, "Tower of Hera"), (0x0010, "Thieves Town"),
    (0x0008, "Turtle Rock"), (0x0004, "Ganons Tower"),
]

# Our dungeon names -> Archipelago's, for "Big Key (X)".
BIGKEY_DUNGEON = {
    "Tower Of Hera": "Tower of Hera",
    "Dark Palace": "Palace of Darkness",
}

PRIZE_TO_AP = {
    "Pendant of Courage": "Green Pendant",
    "Pendant of Power": "Red Pendant",
    "Pendant of Wisdom": "Blue Pendant",
}

# The other direction: AP name -> what is shown in the interface. The logic
# answers with Archipelago's names, and "Titans Mitts" is not how we spell it.
AP_TO_DISPLAY = {v: k for k, v in PRIZE_TO_AP.items()}
AP_TO_DISPLAY.update({
    "Pegasus Boots": "Pegasus Boots", "Flippers": "Flippers",
    "Moon Pearl": "Moon Pearl", "Magic Mirror": "Magic Mirror",
    "Hammer": "Hammer", "Hookshot": "Hookshot", "Lamp": "Lamp",
    "Fire Rod": "Fire Rod", "Ice Rod": "Ice Rod",
    "Cane of Somaria": "Cane of Somaria", "Cane of Byrna": "Cane of Byrna",
    "Cape": "Cape", "Book of Mudora": "Book of Mudora",
    "Bug Catching Net": "Bug Net", "Flute": "Flute", "Bow": "Bow",
    "Blue Boomerang": "Boomerang", "Magic Powder": "Magic Powder",
    "Bombos": "Bombos", "Ether": "Ether", "Quake": "Quake",
    "Power Glove": "Power Glove", "Titans Mitts": "Titan's Mitts",
    "Fighter Sword": "Sword", "Master Sword": "Master Sword",
})
AP_TO_DISPLAY.update({"Crystal %d" % i: "Crystal %d" % i for i in range(1, 8)})


# The exact SRAM flag per location, taken from Archipelago's SNI client. Used
# to list which chests in a dungeon are still unopened.
SRAMFLAG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             "sramflags.json")


def _load_sramflags():
    try:
        with open(SRAMFLAG_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


SRAMFLAGS = _load_sramflags()

# Map name -> AP's flag name for the six that are spelled differently. The
# other 101 of the 107 locations match straight off.
MAP_NAME_ALIAS = {
    "Bumper Cave": "Bumper Cave Ledge",
    "Graveyard Ledge": "Graveyard Cave",
    "Hammer Pegs": "Peg Cave",
    "Pegasus Rocks": "Bonk Rock Cave",
    "Hype Cave - NPC": "Hype Cave - Generous Guy",
    "Mini Moldorm Cave - NPC": "Mini Moldorm Cave - Generous Guy",
}


def chest_open(name, raw):
    """Is THIS location's chest opened? None if we have no flag.

        Per location, not per group. The group variant only gives a COUNT, and
        _group distributed it top-down among the members - which meant the wrong
        member could be marked as cleared. It matters for the logic: the group
        "Sahasrahla" is three chests in the hut plus Sahasrahla himself, and only
        the last one requires a pendant.
    """
    f = SRAMFLAGS.get(MAP_NAME_ALIAS.get(name, name))
    if not f or not raw:
        return None
    off, mask = f[0], f[1]
    return bool(off < len(raw) and raw[off] & mask)


# The spoiler and Archipelago spell two locations differently.
CHEST_NAME_ALIAS = {
    "Ganon's Tower - Moldorm Chest": "Ganons Tower - Pre-Moldorm Chest",
    "Hyrule Castle - Zelda's Cell": "Hyrule Castle - Zelda's Chest",
}


def _ap_chest_name(name):
    """Spoilerns platsnamn -> Archipelagos, eller None."""
    for cand in (CHEST_NAME_ALIAS.get(name, name),
                 name.replace("Ganon's Tower", "Ganons Tower")):
        if cand in SRAMFLAGS:
            return cand
    return None


def ap_reach_locs(names, inv, prizes=(), seed=""):
    """{AP name: True/False}. Empty dict if the service does not answer."""
    if not names:
        return {}
    try:
        body = json.dumps({"items": _ap_items(inv), "extra": list(prizes),
                           "locations": sorted(names),
                           "medals": _medals_for_seed(seed)}).encode()
        req = urllib.request.Request(
            REACHD_URL.replace("/reach", "/reachlocs"), data=body,
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=8) as r:
            return json.loads(r.read().decode()).get("reach") or {}
    except Exception:                                          # noqa: BLE001
        return {}


def _flag_for_chest(name):
    """Spoilerns platsnamn -> (offset, mask), eller None."""
    for cand in (CHEST_NAME_ALIAS.get(name, name),
                 name.replace("Ganon's Tower", "Ganons Tower")):
        f = SRAMFLAGS.get(cand)
        if f:
            return f[0], f[1]
    return None


def dungeon_chests(seed, dungeon, raw=None, inv=None, prizes=None):
    """The chests in a dungeon and which of them are opened.

        The names come from the SEED'S spoiler - it knows exactly which
        locations exist in that particular seed, unlike Archipelago's general
        list, which also counts key drops and pot keys that are not always in.

        Only NAMES leave the server, never what is in the chest.
    """
    if raw is None:
        raw = []
        for fn in sorted(os.listdir(os.path.join(SAVES, "SNES"))):
            if fn.lower().endswith(".sav") and fn.lower().startswith("alttpr"):
                d = read_save(os.path.join(SAVES, "SNES", fn))
                if d and d.get("seed") == seed:
                    raw = d.get("raw") or []
                    break
    out = []
    apnames = {}
    # ⚠️ Locations that have a map position of their OWN are drawn as map points
    # by points(), and must therefore not be counted as dungeon chests as well -
    # raknas de tva ganger. Galler Hyrule Castles utomhusdelar: Sanctuary,
    # Link's Uncle and Secret Passage. Without this ALTTP's total came to 209
    # instead of 206, and the same dungeon weighed 10 against SMZ3's 7.
    anno = _load_anno()
    for (reg, name) in _item_map(seed):
        if reg != dungeon:
            continue
        # The prize (pendant/crystal) is the dungeon's reward, not a location -
        # it is already shown as a reward on the map.
        if name.endswith(" - Prize"):
            continue
        # ⚠️ The boss DROPS a real item, so it is a location and has to be counted.
        # It has no chest flag in SRAM - it is read from the BOSS FLAG, the same one
        # the crystal counter uses. Without that it would only have landed in the
        # denominator and could never be ticked off, which is exactly why it was
        # removed from here once before.
        if name.endswith(" - Boss"):
            out.append({"name": name.split(" - ", 1)[1],
                        "open": boss_beaten(dungeon, raw)})
            continue
        if isinstance(anno.get("%s|%s" % (reg, name)), dict):
            continue
        f = _flag_for_chest(name)
        kort = name.split(" - ", 1)[1] if " - " in name else name
        ap = _ap_chest_name(name)
        if ap:
            apnames[kort] = ap
        if not f:
            out.append({"name": kort, "open": None})
            continue
        off, mask = f
        out.append({"name": kort,
                    "open": bool(off < len(raw) and raw[off] & mask)})
    out.sort(key=lambda x: x["name"])

    # Reachability only for the chests that REMAIN - a cleared chest says nothing
    # about what can be done next.
    kvar = [c for c in out if not c["open"]]
    reach = {}
    if kvar and inv is not None:
        reach = ap_reach_locs([apnames[c["name"]] for c in kvar
                               if c["name"] in apnames], inv, prizes or [],
                              seed)
    for c in out:
        c["reach"] = reach.get(apnames.get(c["name"], ""), None)

    # Colour states, the same language as the map dots:
    # done = all empty | can = everything left is reachable
    # part = some is | no = none is
    if not kvar:
        state = "done"
    else:
        kanda = [c["reach"] for c in kvar if c["reach"] is not None]
        if not kanda:
            state = None
        elif all(kanda):
            state = "can"
        elif any(kanda):
            state = "part"
        else:
            state = "no"
        # Distinguishes "only the big key is missing" from "parts of the dungeon are
        # stangda". Prova samma fraga med nyckeln i handen: oppnar den ALLT
        # left was the only thing blocking it.
        if state in ("part", "no") and inv is not None:
            bk = "Big Key (%s)" % BIGKEY_DUNGEON.get(dungeon, dungeon)
            if bk not in (prizes or []):
                med = ap_reach_locs(
                    [apnames[c["name"]] for c in kvar if c["name"] in apnames],
                    inv, list(prizes or []) + [bk], seed)
                if med and all(med.get(apnames.get(c["name"], ""), False)
                               for c in kvar if c["name"] in apnames):
                    state = "bigkey"
    return {"dungeon": dungeon, "chests": out, "state": state,
            "open": sum(1 for c in out if c["open"]),
            "total": len(out)}


# The boss room's flag in SRAM. Archipelago lists it as "<dungeon> - Boss";
# the bit is set when the boss's drop is picked up, that is when the dungeon
# is cleared. Castle Tower, Hyrule Castle and Ganons Tower have none - they
# beloning.
BOSS_AP_NAME = {
    "Desert Palace": "Desert Palace - Boss",
    "Eastern Palace": "Eastern Palace - Boss",
    "Tower Of Hera": "Tower of Hera - Boss",
    "Dark Palace": "Palace of Darkness - Boss",
    "Swamp Palace": "Swamp Palace - Boss",
    "Skull Woods": "Skull Woods - Boss",
    "Thieves Town": "Thieves' Town - Boss",
    "Ice Palace": "Ice Palace - Boss",
    "Misery Mire": "Misery Mire - Boss",
    "Turtle Rock": "Turtle Rock - Boss",
}


def boss_beaten(dungeon, raw):
    """True/False from SRAM, None if the dungeon has no boss flag."""
    ap = BOSS_AP_NAME.get(dungeon)
    f = SRAMFLAGS.get(ap or "")
    if not f:
        return None
    off, mask = f[0], f[1]
    return bool(off < len(raw) and raw[off] & mask)


def prize_of(seed, dungeon):
    """Which reward the dungeon gives, from the spoiler.

        Not a spoiler in practice: the prize is visible on the map in the game
        as soon as you bring it up, and it was explicitly asked for. The name is
        written as one word in the file - "Crystal4", "PendantOfPower".
    """
    for (reg, name), item in _item_map(seed).items():
        if reg != dungeon or not name.endswith(" - Prize"):
            continue
        m = re.match(r"Crystal(\d)$", item)
        if m:
            return "Crystal %s" % m.group(1)
        m = re.match(r"PendantOf(\w+)$", item)
        if m:
            return "Pendant of %s" % m.group(1)
        return item
    return ""


def _prizes_for_seed(seed, raw=None):
    """Crystals and pendants the player is actually carrying, from SRAM.

        Verified 2026-08-09: after five bosses were beaten, 0x374 read 0x03 (two
        bits) and 0x37A read 0x0D (three bits) - five in total, exactly the
        number beaten. That confirms both the offsets and that bit n = reward n+1.

        The game's own register beats the note: the notes said "Crystal 5" and
        "Crystal 7", but the bits say 1, 3 and 4. The note is a guess made from
        the prize icon on the map, not something verified.
    """
    if raw is None:
        raw = []
        try:
            for fn in sorted(os.listdir(os.path.join(SAVES, "SNES"))):
                if not (fn.lower().endswith(".sav")
                        and fn.lower().startswith("alttpr")):
                    continue
                d = read_save(os.path.join(SAVES, "SNES", fn))
                if d and d.get("seed") == seed:
                    raw = d.get("raw") or []
                    break
        except OSError:
            pass
    if len(raw) <= 0x37A:
        return []
    # ⚠️ The bits are NOT in reward order. Taken from Archipelago's own
    # worlds/alttp/Items.py (first byte of each reward's ItemData), identical to
    # TotalSMZ3's PendantValues/CrystalValues. Until 2026-09-11 this read
    # "bit n = reward n+1", which put the Red pendant down as Green - so
    # Sahasrahla opened on the wrong pendant - and Crystal 6 as Crystal 1, which
    # matters for the Pyramid Fairy (Crystal 5 + 6). The 0x37A=0x0D noted in the
    # docstring is really Crystals 5, 6 and 7, and the note saying "5 and 7" was
    # right after all.
    out = []
    pend = raw[0x374]
    for mask, namn in ((0x04, "Green Pendant"), (0x02, "Blue Pendant"),
                       (0x01, "Red Pendant")):
        if pend & mask:
            out.append(namn)
    cry = raw[0x37A]
    for mask, nr in ((0x02, 1), (0x10, 2), (0x40, 3), (0x20, 4),
                     (0x04, 5), (0x01, 6), (0x08, 7)):
        if cry & mask:
            out.append("Crystal %d" % nr)
    # Agahnim 1 is an EVENT in the logic, not an item: the tree at Lumberjack
    # Tree only splits once he is beaten, and the pyramid opens. 0x3C5 is the
    # game's progress meter, 3 = Agahnim defeated.
    if len(raw) > 0x3C5 and raw[0x3C5] >= 3:
        out.append("Beat Agahnim 1")
    # Stora nycklar: 16-bitars faltet pa 0x366. De forbrukas aldrig, sa de
    # can be read exactly - unlike small keys, which disappear when a door is
    # opened. Without this the logic assumed every big key was held, and a Big
    # Chest looked openable without its key.
    if len(raw) > 0x367:
        bk = raw[0x366] | (raw[0x367] << 8)
        for bit, namn in BIG_KEY_BITS:
            if bk & bit:
                out.append("Big Key (%s)" % namn)
    return out


def _medals_from_spoiler(seed):
    """{"mm": "Quake", "tr": "Quake"} from the seed's spoiler, or empty.

        Not a spoiler in practice: the medallion is shown on the door in the
        game. And the file is the truth - a hand-written note said Bombos on
        Turtle Rock, but the spoiler says Quake. The same happened with the
        crystals.
    """
    path = _spoiler_for(seed)
    if not path:
        return {}
    try:
        with open(path) as f:
            data = json.load(f)
    except (OSError, ValueError):
        return {}
    out = {}
    for sect in ("meta", "Special"):
        v = data.get(sect)
        if not isinstance(v, dict):
            continue
        for key, val in v.items():
            namn = key.rsplit(":", 1)[0].strip()
            item = str(val).rsplit(":", 1)[0].strip().capitalize()
            if item not in [m.capitalize() for m in MEDALS]:
                continue
            if namn == "Misery Mire Medallion":
                out["mm"] = item
            elif namn == "Turtle Rock Medallion":
                out["tr"] = item
    return out


def _medals_for_seed(seed):
    """[Misery Mire, Turtle Rock] as AP names.

        The medallions are shuffled per seed. AP hardcodes Ether/Quake, so
        without this Misery Mire can look locked on the wrong grounds. An
        unknown value -> AP's default, which is a guess but the only one we have
        before the player has seen the door.
    """
    # The spoiler only. Hand-written notes are NOT used as logic input - they are
    # made while playing, often during a test, and have turned out wrong
    # tre ganger: boss-bocken betydde "kand beloning", kristallerna sa 5/7
    # when SRAM said 1/3/4, and the medallion said Bombos when the spoiler said Quake.
    # The files stay for the interface, but the logic only reads the truth.
    sp = _medals_from_spoiler(seed)
    return [sp.get("mm") or "Ether", sp.get("tr") or "Quake"]


def _save_for_seed(seed):
    """The decoded save belonging to an ALTTPR seed, or None."""
    try:
        for fn in os.listdir(os.path.join(SAVES, "SNES")):
            if not (fn.lower().endswith(".sav")
                    and fn.lower().startswith("alttpr")):
                continue
            d = read_save(os.path.join(SAVES, "SNES", fn))
            if d and d.get("seed") == seed:
                return d
    except OSError:
        pass
    return None


def _inv_for_seed(seed):
    """The inventory from the seed's save file, or empty if it is unstarted."""
    d = _save_for_seed(seed)
    return (d.get("inv") or {}) if d else {}


def missing_for(seed, name, medlemmar=None):
    """What is missing to reach a location? Display names, ready to show.

        We never send the location's CONTENTS - only which items are needed to
        get there. The requirement is a property of the world, not of the seed,
        so it reveals nothing.
    """
    # Nara grupper slas ihop till "King Zora / Zora's Ledge". Logiken kanner
    # only the individual names, so try the parts separately.
    kandidater = [name] + [d.strip() for d in name.split(" / ")]
    items = _ap_items(_inv_for_seed(seed))
    try:
        extra = _prizes_for_seed(seed)
        for kand in kandidater:
            body = json.dumps({"items": items, "location": kand,
                               "extra": extra,
                               "medals": _medals_for_seed(seed)}).encode()
            req = urllib.request.Request(
                REACHD_URL.replace("/reach", "/missing"), data=body,
                headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=30) as r:
                d = json.loads(r.read().decode())
            if not d.get("okand"):
                break
    except Exception as e:                                     # noqa: BLE001
        return {"name": name, "fel": language.word("the logic service is not answering (%s)") % e}

    def display(names):
        # The table gives the display name; language.word() takes it on to the
        # chosen language. For English that means going back to
        # Archipelago's own names, which is exactly what an English-speaking
        # player wants to see.
        return [language.word(AP_TO_DISPLAY.get(n, n)) for n in names]

    out = {"name": name, "nabar": bool(d.get("nabar"))}
    # What WAS here, for the locations already emptied. chest_open reads one
    # flag per location; where there is none it answers None, and hamtat_lista
    # then stays silent rather than trusting the per-screen approximation.
    spar = _save_for_seed(seed)
    raw_s = (spar or {}).get("raw") or []
    if raw_s:
        hamtat = hamtat_lista(seed, medlemmar or [name],
                              lambda n: chest_open(n, raw_s))
        if hamtat:
            out["hamtat"] = hamtat
    # Already read out of the spoiler? Then say so here too, instead of making
    # the player go back to the spoiler box to see it again.
    visad = spoiler_visad(seed, name)
    if visad:
        out["spoiler"] = _display(visad["item"])
        out["spoiler_plats"] = visad["plats"]
    if d.get("okand"):
        out["fel"] = language.word("this location is not in the logic")
    elif d.get("omojlig"):
        # Pendants, bottle and mushroom are not read from SRAM, so the logic
        # cannot decide them. Better to say so than to guess.
        out["omojlig"] = True
    elif d.get("single"):
        out["nagot_av"] = sv(d["single"])
    elif d.get("combo"):
        out["behover"] = sv(d["combo"])
    return out


def _ap_items(inv):
    """The SRAM inventory -> {logic id: value} the way reachd understands it."""
    out = {}
    for iid, _name, off, need in LOGIC_ITEMS:
        val = inv.get(off, 0)
        if val >= need:
            out[iid] = val
    # The mushroom is CONSUMED once the powder exists - 0x344 goes from 1 to 2,
    # so ">= 1" matches both. Exactly 1 is required here.
    if inv.get(0x344, 0) == 1:
        out["mushroom"] = 1
    else:
        out.pop("mushroom", None)
    # The shovel sits in 0x34C until the flute overwrites the slot; after that
    # it only shows as bit 0x04 in 0x38C. Measured 2026-08-09: the save had both
    # an activated flute (0x34C=3) and the shovel, and the bit was set.
    if inv.get(0x38C, 0) & 0x04 or inv.get(0x34C, 0) == 1:
        out["shovel"] = 1
    else:
        out.pop("shovel", None)
    # The bottle can sit in any of the four slots, so the entry in LOGIC_ITEMS
    # (which only looks at 0x35C) is not enough. The value is the COUNT, which
    # matters for the few rules that need more than one.
    n = sum(1 for o in BOTTLE_SLOTS if inv.get(o, 0))
    if n:
        out["bottle"] = n
    else:
        out.pop("bottle", None)
    return out


def ap_locked(inv, prizes=(), seed=""):
    """A set of locked location names, or None if the service does not answer.

        None means "no opinion" - we then fall back on the hand-written logic
        rather than colouring everything red while the server is down.
    """
    items = _ap_items(inv)
    key = (tuple(sorted(items.items())), tuple(sorted(prizes)),
           tuple(_medals_for_seed(seed)))
    if key in _ap_cache:
        return _ap_cache[key]
    if time.time() < _ap_down_until[0]:
        return None
    try:
        body = json.dumps({"items": items, "extra": list(prizes),
                           "medals": _medals_for_seed(seed)}).encode()
        req = urllib.request.Request(
            REACHD_URL, data=body,
            headers={"Content-Type": "application/json"})
        # 8 s, not 2: a cache miss requires reachd to rebuild the state.
        # Too short a timeout gave 60 s of backoff and a map with no opinion at all.
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read().decode())
        locked = set(data.get("locked") or [])
    except Exception:                                          # noqa: BLE001
        # Back off for 60 s. Without it every page load would pay the
        # timeout price while the server is down.
        _ap_down_until[0] = time.time() + 20
        return None
    if len(_ap_cache) < 200:
        _ap_cache[key] = locked
    return locked


# Region requirements: what it takes to GET to a world at all. Without them
# every dark world location has to repeat "requires Moon Pearl", which is
# both tedious to enter and easy to forget somewhere.
#
# ⚠️ Medvetet grovt. Den riktiga logiken (hutchch/ALTTPR-Tracker) modellerar
# subregions - dwNW, dwSouth, eastDM, climbDM - plus four states and whether
# Agahnim is beaten. Porting that is a project of its own; this catches the
# common case with one line per world. A location in a subregion with harder
# requirements goes green too early, never red too early - the direction of
# the error is deliberate, so the tracker never warns you off something reachable.
# Keyed on WORLD ("lw"/"dw") and on the spoiler's REGION NAME ("Death Mountain").
# Both apply - a dark world dungeon inherits both the dw requirement and its own.
# Empty list = no requirement. Add lines here rather than entering the same
# requirement on every location in the area.
REGION_REQS = {
    "dw": {"all": ["pearl"], "any": []},
    # The climb needs a way up - not the lamp, which is for the dark caves up
    # there.
    "Death Mountain": {"all": [], "any": ["gloves", "flute"]},
}

# Your own region requirements. Layered on top of the defaults above, so a
# rule you write wins. A separate file so it survives code updates - the
# defaults are a starting point, not the truth.
REGION_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "regions.json")
_region_lock = threading.Lock()


def _load_regions():
    reqs = dict(REGION_REQS)
    try:
        with open(REGION_FILE) as f:
            reqs.update(json.load(f))
    except (OSError, ValueError):
        pass
    return reqs


def set_region(name, req_all, req_any):
    with _region_lock:
        try:
            with open(REGION_FILE) as f:
                data = json.load(f)
        except (OSError, ValueError):
            data = {}
        if not req_all and not req_any:
            data.pop(name, None)
        else:
            data[name] = {"all": req_all, "any": req_any}
        tmp = REGION_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=1, sort_keys=True)
        os.replace(tmp, REGION_FILE)
        return len(data)


# The medallion for Turtle Rock and Misery Mire is shuffled per seed, so it
# cannot live in the shared regions.json. The player sets it after seeing the
# door - we do NOT read it from the spoiler, since that would reveal it before
# it has been found. The same arrangement as hutchch/ALTTPR-Tracker (MIT).
# Unknown state: with all three it is guaranteed satisfied; with some it is
# uncertain and we let it through (the chosen direction of error - rather
# green too early than red too early); with none it is blocked.
MEDAL_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "medallions.json")
MEDAL_DUNGEON = {"Turtle Rock": "tr", "Misery Mire": "mm"}
MEDALS = ("bombos", "ether", "quake")
_medal_lock = threading.Lock()


def _load_medals():
    try:
        with open(MEDAL_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def set_medallion(seed, dungeon, value):
    key = "%s|%s" % (seed, dungeon)
    with _medal_lock:
        data = _load_medals()
        if value:
            data[key] = value
        else:
            data.pop(key, None)
        tmp = MEDAL_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=1, sort_keys=True)
        os.replace(tmp, MEDAL_FILE)
        return len(data)
def MEDALL_KEY(region):
    return MEDAL_DUNGEON.get(region)


# Extensions belonging to a seed. ⚠️ The skin files are listed with their FULL
# extension, not ".json"/".png" - filters that broad would sweep up other
# rakar ligga i samma mapp.
SEED_SUFFIX = (".skin.json", ".skin.png", ".samus.png", ".sfc", ".smc",
               ".txt", ".sav", ".ss")


def _hor_till_seed(fn, seed):
    """Does the file belong to this seed?

        ⚠️ Substring matching is NOT enough. "1401234" occurs inside "11401234",
        so one seed could drag another one's files along when deleted. The seed
        has to stand as its own part at the end of the name - both naming
        schemes put it there, ALTTPR after "_" and SMZ3 after "-".
    """
    low = fn.lower()
    for e in SEED_SUFFIX:
        if low.endswith(e):
            stam = fn[:len(fn) - len(e)]
            # ⚠️ Two kinds of counter can come AFTER the seed, and it is then
            # no longer the last part:
            #   "<stam> (1).sfc"  dubbletthamtning
            #   "<stam>_1.ss"     sparat lage
            # Without this they survive the deletion.
            stam = re.sub(r" \(\d+\)$", "", stam)
            if e == ".ss":
                stam = re.sub(r"_\d+$", "", stam)
            return (stam == seed or stam.endswith("-" + seed)
                    or stam.endswith("_" + seed))
    return False


def seed_files(seed):
    """Every file belonging to a seed: ROM, spoiler, save file and skin.

        ⚠️ Input to something destructive. Every path is checked against an
        allowed root before it is handed out - a seed string must never be able
        to point at anything outside games/SNES or saves/SNES.
    """
    if not seed or "/" in seed or ".." in seed:
        return []
    out = []
    # ⚠️ The list must cover EVERY place a seed leaves traces. If one was
    # savestates helt fram till 2026-08-12: en raderad seed lamnade kvar
    # their .ss files, and those are pure seed artefacts. "Alltp Randomizer"
    # is an older ALTTP layout that puts a copy of the ROM in a folder
    # dopt efter seeden.
    roots = [os.path.join(GAMES, "SNES", g)
             for g in ("ALTTPR", "SMZ3", "Alltp Randomizer")]
    roots.append(os.path.join(SAVES, "SNES"))
    roots.append(os.path.join(SAVESTATES, "SNES"))
    for root in roots:
        for dp, _dn, fns in os.walk(root):
            for fn in fns:
                if not _hor_till_seed(fn, seed):
                    continue
                full = os.path.realpath(os.path.join(dp, fn))
                if any(full.startswith(os.path.realpath(r) + os.sep)
                       for r in roots):
                    out.append(full)
    return sorted(set(out))


def delete_seed(seed):
    """Deletes the seed's files and clears away its saved state."""
    files = seed_files(seed)
    gone = []
    kataloger = set()
    for f in files:
        try:
            os.remove(f)
            gone.append(os.path.basename(f))
            kataloger.add(os.path.dirname(f))
        except OSError:
            pass
    # "Alltp Randomizer"-layouten lagger ROM:en i en mapp DOPT EFTER
    # the seed. Without this an empty folder is left behind after every deletion.
    # ⚠️ Three conditions, all necessary: the folder must be named exactly after
    # the seed, be empty, and sit under an allowed root. A folder is never deleted
    # just because it happens to be empty - only the seed's own.
    rot = os.path.realpath(os.path.join(GAMES, "SNES", "Alltp Randomizer"))
    for d in kataloger:
        full = os.path.realpath(d)
        if (os.path.basename(full) == seed
                and full.startswith(rot + os.sep)):
            try:
                if not os.listdir(full):
                    os.rmdir(full)
                    gone.append(os.path.basename(full) + os.sep)
            except OSError:
                pass
    # per-seed-lagen: bockningar, beloningar, medaljonger
    # ⚠️ Every per-seed state has to be listed here. The keys all start with
    # "<seed>|" precisely so this loop can find them.
    for path, lock in ((CHECK_FILE, _check_lock), (PROG_FILE, _prog_lock),
                       (MEDAL_FILE, _medal_lock), (SPOIL_FILE, _spoil_lock)):
        with lock:
            try:
                with open(path) as f:
                    data = json.load(f)
            except (OSError, ValueError):
                continue
            keep = {k: v for k, v in data.items()
                    if not k.startswith(seed + "|")}
            if len(keep) != len(data):
                tmp = path + ".tmp"
                with open(tmp, "w") as f:
                    json.dump(keep, f, indent=1, sort_keys=True)
                os.replace(tmp, path)
    return gone


def region_names():
    """The worlds plus the spoiler's regions - everything requirements can be set on."""
    out = ["lw", "dw"]
    seeds = tracker()
    path = _spoiler_for(seeds[0]["seed"]) if seeds else None
    if path:
        try:
            with open(path) as f:
                data = json.load(f)
        except (OSError, ValueError):
            data = {}
        out += [r for r in data
                if r not in ANNO_SKIP and isinstance(data[r], dict)]
    return out
def _item_map(seed):
    """{(region, location): item name} from the seed's spoiler."""
    path = _spoiler_for(seed)
    out = {}
    if not path:
        return out
    try:
        with open(path) as f:
            data = json.load(f)
    except (OSError, ValueError):
        return out
    if isinstance(data, list):
        # SMZ3: platt lista, ingen regionniva
        for chunk in data:
            if not isinstance(chunk, dict):
                continue
            for loc, item in chunk.items():
                if isinstance(item, str):
                    out[("", loc.rsplit(":", 1)[0])] = item.rsplit(":", 1)[0]
        return out
    for region, items in data.items():
        if region in ANNO_SKIP or not isinstance(items, dict):
            continue
        for loc, item in items.items():
            if isinstance(item, str):
                out[(region, loc.rsplit(":", 1)[0])] = item.rsplit(":", 1)[0]
    return out


# ---------------------------------------------------------------------------
# SMZ3: the whole placement is read out of the ROM
#
# SMZ3's .txt is only a PLAYTHROUGH - about 74 of 316 locations, that is only
# what drives progression. "Missile (outside Wrecked Ship middle)" could
# therefore not be searched for. But the randomizer writes every item into the
# ROM, and TotalSMZ3 states exactly where: every Location has an Address.
#
# ⚠️ This is a READER OF ITS OWN. _item_map() is untouched - that one feeds
# the tracker, the dungeon count and the reward lookup, and they carry on
# reading the playthrough file exactly as before. Only /api/spoiler uses this.
#
# Three addressing rules, all from TotalSMZ3's Snes() - and all three are
# needed; the last two classes gave zero hits with only the main rule:
#   bank $30  -> viks in i ExHiROM:s lagbank $40
#   < $800000 -> ExHi-offset 0x400000 laggs pa
#   annars    -> speglingen kollapsas
#
# Zelda locations store the item's ItemType value as ONE byte straight at the
# address. Super Metroid instead stores a 2-byte PLM id, offset by the
# location's type (Chozo +0x54, Hidden +0xA8). If the id is >= 0xEFE0 a ZELDA
# item sits in the Metroid location, and its
# ItemType pa adress+5 i stallet.
#
# Verified against seed 361911764: 316 of 316 locations decoded, and all 58
# locations that also appeared in the playthrough file gave the same item.
SMZ3_TAB_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                             "smz3_locations.json")

SMZ3_PLM = {0xEED7: "ETank", 0xEEDB: "Missile", 0xEEDF: "Super",
            0xEEE3: "PowerBomb", 0xEEE7: "Bombs", 0xEEEB: "Charge",
            0xEEEF: "Ice", 0xEEF3: "HiJump", 0xEEF7: "SpeedBooster",
            0xEEFB: "Wave", 0xEEFF: "Spazer", 0xEF03: "SpringBall",
            0xEF07: "Varia", 0xEF0B: "Gravity", 0xEF0F: "XRay",
            0xEF13: "Plasma", 0xEF17: "Grapple", 0xEF1B: "SpaceJump",
            0xEF1F: "ScrewAttack", 0xEF23: "Morph", 0xEF27: "ReserveTank"}

_smz3_tab = None
_smz3_plac_cache = {}


def _smz3_tabell():
    """The location table (address, type, region) + item names. Loaded once."""
    global _smz3_tab
    if _smz3_tab is None:
        try:
            with open(SMZ3_TAB_FILE) as f:
                d = json.load(f)
            _smz3_tab = (d["loc"], {int(k): v for k, v in d["namn"].items()})
        except (OSError, ValueError, KeyError):
            _smz3_tab = ([], {})
    return _smz3_tab


def _smz3_snes(a):
    """TotalSMZ3:s Snes(): SNES-adress -> offset i kombo-ROM:en."""
    if (a & 0xFF8000) == 0x308000:
        a = 0x400000 | (a & 0x7FFF)
    else:
        a = (0x400000 if a < 0x800000 else 0) | (a & 0x3FFFFF)
    return a if a <= 0x600000 else None


def _smz3_rom(seed):
    """Seedens .sfc, eller None."""
    for f in seed_files(seed):
        if f.lower().endswith((".sfc", ".smc")) and os.sep + "SMZ3" in f:
            return f
    return None


def _smz3_placering(seed):
    """{(region, location): item} for the WHOLE seed, read from the ROM.

        Empty dict if the ROM is missing - the caller then has to fall back on
        the playthrough file.
    """
    rom = _smz3_rom(seed)
    if not rom:
        return {}
    try:
        nyckel = (rom, os.path.getmtime(rom), os.path.getsize(rom))
    except OSError:
        return {}
    if nyckel in _smz3_plac_cache:
        return _smz3_plac_cache[nyckel]

    loc, namn = _smz3_tabell()
    out = {}
    try:
        with open(rom, "rb") as f:
            slut = os.path.getsize(rom)
            for L in loc:
                o = _smz3_snes(L["a"])
                if o is None or o + 6 > slut:
                    continue
                f.seek(o)
                b = f.read(6)
                if L["a"] >= 0x700000:                        # Super Metroid
                    plm = b[0] | (b[1] << 8)
                    if plm >= 0xEFE0:                         # zelda-foremal
                        item = namn.get(b[5])
                    else:
                        off = 0x54 if L["t"] == "C" else 0xA8 if L["t"] == "H" else 0
                        intern = SMZ3_PLM.get(plm - off)
                        item = intern and _smz3_visning(intern, namn)
                else:                                         # Zelda
                    item = namn.get(b[0])
                if item:
                    out[(L["r"], L["n"])] = item
    except OSError:
        return {}
    _smz3_plac_cache.clear()          # bara nyaste seeden behover ligga kvar
    _smz3_plac_cache[nyckel] = out
    return out


def _smz3_visning(intern, namn):
    """The PLM table gives internal names; the name table is keyed on ItemType."""
    for v, n in namn.items():
        if n.replace(" ", "").lower() == intern.lower():
            return n
    return {"ETank": "Energy Tank", "Super": "Super Missile",
            "PowerBomb": "Power Bomb", "SpeedBooster": "Speed Booster",
            "SpaceJump": "Space Jump", "HiJump": "Hi-Jump Boots",
            "ScrewAttack": "Screw Attack", "SpringBall": "Spring Ball",
            "ReserveTank": "Reserve Tank", "XRay": "X-Ray Scope",
            "Charge": "Charge Beam", "Ice": "Ice Beam", "Wave": "Wave Beam",
            "Plasma": "Plasma Beam", "Varia": "Varia Suit",
            "Gravity": "Gravity Suit", "Morph": "Morphing Ball",
            "Bombs": "Morph Bombs", "Grapple": "Grappling Beam",
            }.get(intern, intern)


# ---------------------------------------------------------------------------
# Spoilerloggen
#
# Looking something up should cost you. Hence two steps: you search out a NAME
# (item or location) without seeing the answer, confirm, and only then is it
# revealed - and recorded.
#
# ⚠️ The key is "<seed>|<mode>|<name>" with the seed FIRST. That is the same
# shape progress/medallions use, so delete_seed() removes the entries
# med sin befintliga `k.startswith(seed + "|")` - en ny nyckelform hade
# tyst lamnat kvar spoilerloggen efter en raderad seed.
#
# The count is per UNIQUE thing, not per click: looking the same item up a
# second time is not a new spoiler. It also lets the list show a tick next to
# what you have already seen.
SPOIL_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "spoilers.json")
_spoil_lock = threading.Lock()
SPOIL_MAX = 5                      # over detta visas "5+"


def _load_spoil():
    try:
        with open(SPOIL_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _spoil_key(seed, mode, namn):
    return "%s|%s|%s" % (seed, mode, namn)


def spoil_add(seed, mode, namn):
    """Bokfor ett avslojande. Returnerar antalet unika for seeden."""
    with _spoil_lock:
        data = _load_spoil()
        data.setdefault(_spoil_key(seed, mode, namn), int(time.time()))
        tmp = SPOIL_FILE + ".tmp"
        with open(tmp, "w") as f:
            json.dump(data, f, indent=1, sort_keys=True)
        os.replace(tmp, SPOIL_FILE)
        return sum(1 for k in data if k.startswith(seed + "|"))


def spoil_count(seed):
    return sum(1 for k in _load_spoil() if k.startswith(seed + "|"))


def spoil_seen(seed):
    """{(mode, name)} already revealed - the list can tick them off."""
    ut = set()
    for k in _load_spoil():
        bitar = k.split("|", 2)
        if len(bitar) == 3 and bitar[0] == seed:
            ut.add((bitar[1], bitar[2]))
    return ut


def spoiler_karta(seed):
    """{(region, location): item} for a seed, plus whether it is incomplete.

        ALTTP has a full spoiler file. SMZ3's .txt is only a playthrough, but
        the whole placement can be read out of the ROM - see _smz3_placering().
    """
    karta = _item_map(seed)
    delvis = _ar_smz3(seed)
    if delvis:
        full = _smz3_placering(seed)
        if full:
            karta, delvis = full, False
    return karta, delvis


# The spoiler file uses its own names - "ProgressiveGlove", not "Titan's
# Mitt". Without this, "tit" gives zero hits.
SPOIL_SYN = {
    "tit": "progressiveglove", "titan": "progressiveglove",
    "mitt": "progressiveglove", "glove": "progressiveglove",
    "handsk": "progressiveglove",
    "sword": "progressivesword", "svard": "progressivesword",
    "shield": "progressiveshield", "skold": "progressiveshield",
    "mail": "progressivearmor", "armor": "progressivearmor",
    "rustning": "progressivearmor",
    "pearl": "moonpearl", "parla": "moonpearl",
    "mirror": "magicmirror", "spegel": "magicmirror",
    "boots": "pegasusboots", "stovl": "pegasusboots",
    "book": "bookofmudora", "bok": "bookofmudora",
    "net": "bugcatchingnet", "hav": "bugcatchingnet",
    "flute": "ocarina", "flojt": "ocarina",
    "somaria": "caneofsomaria", "byrna": "caneofbyrna",
    "lampa": "lamp", "hammare": "hammer", "bage": "bow",
    "simfot": "flippers", "eldstav": "firerod",
    "isstav": "icerod", "svamp": "mushroom",
}


def _spoil_termer(q):
    terms = [w for w in re.split(r"\s+", q.lower().replace("*", " ")) if w]
    return [SPOIL_SYN.get(w, w) for w in terms]


def spoiler_namn(seed, mode, q):
    """Names matching the search term - NEVER what is where.

        That is the whole point of the two-step flow: the list must not reveal
        anything, or you have spoiled yourself just by typing.
    """
    karta, delvis = spoiler_karta(seed)
    terms = _spoil_termer(q)
    sedda = spoil_seen(seed)
    namn = {}
    for (reg, plats), item in karta.items():
        if mode == "item":
            etikett, hoy = item, item.lower()
        else:
            etikett = ("%s — %s" % (reg, plats)) if reg else plats
            hoy = ("%s %s" % (reg, plats)).lower()
        if all(w in hoy for w in terms):
            namn.setdefault(etikett, 0)
            namn[etikett] += 1
    ut = [{"namn": n, "antal": k, "sedd": (mode, n) in sedda}
          for n, k in sorted(namn.items())]
    return {"namn": ut[:40], "total": len(ut), "delvis": delvis,
            "count": spoil_count(seed)}


# ---------------------------------------------------------------------------
# Game completed, and play time
#
# ⚠️ There is NO "Ganon defeated" stamp in the save file, and it cannot be
# fixed: ALTTP rolls the credits the moment Ganon dies and never saves again.
# Archipelago solves it by reading LIVE RAM (game mode 0x19/0x1a), which the
# MiSTer does not expose - the cores are separate from the Linux side.
#
# The closest to the truth the save file allows is three things at once:
# Agahnim 2 beaten (the boss flag at the top of GT), every crystal, and
#   Ganons rum besokt.
# That means standing in the final fight. Measured on a cleared seed against
# tre opaborjade: 0x0802 / 7 kristaller / 0x0004, mot noll rakt igenom.
# ⚠️ Play time is deliberately REMOVED. It could be read (3 bytes LE at
# 0x43E, bildrutor), men den fortsatter ticka om man startar seeden igen
# after Ganon died - the number would then no longer be "how long it took".
# Decision 2026-08-12: the tick mark only.
RUM_AGAHNIM2 = 0x0D            # Ganons torn, toppen
RUM_GANON = 0x00
BOSS_BIT = 0x0800

def _rum(b, rum):
    i = rum * 2
    return b[i] | (b[i + 1] << 8) if i + 1 < len(b) else 0


def zelda_klar(b):
    """Was the player standing in the final fight against Ganon? See the note
        above for why "defeated" cannot be answered exactly.
    """
    if len(b) < 0x380:
        return False
    kristaller = bin(b[0x37A]).count("1")
    return bool(_rum(b, RUM_AGAHNIM2) & BOSS_BIT) and kristaller >= 7 \
        and _rum(b, RUM_GANON) != 0


# ⚠️ NOT MAPPED. The Metroid half's boss flags sit in the save file's
# SM block, but they cannot be pinned down without a known-good sample: in an
# 361911764 skiljer sig exakt fyra byte mot en lite spelad seed
# (0x2071=08, 0x2078=04, 0x207B=01, 0x2082=01, counted from the slot's ammo
# base minus 0x20), and without knowing WHICH bosses had been felled there is
# no way to say which bit is which.
#
# Guessing would be the wrong call here: a misplaced bit gives a FALSE
# "cleared" tick, which is worse than no tick at all. So it answers no until
# a save file with Mother Brain felled exists to compare against.
#
# The consequence: an SMZ3 card only gets the tick once both Ganon and Mother
# Brain can be confirmed - so not yet.
def metroid_klar(raw):
    return False


def smz3_klar(raw):
    """SMZ3 requires BOTH halves - Ganon and Mother Brain."""
    return zelda_klar(bytes(raw)) and metroid_klar(raw)


def spoiler_logg(seed):
    """Everything already revealed for the seed, with the answers.

        Showing the answers again costs nothing - they are already paid for. The
        point is to avoid looking the same thing up twice and wondering whether
        you already peeked.
    """
    loggen = _load_spoil()
    poster = []
    for k, nar in loggen.items():
        bitar = k.split("|", 2)
        if len(bitar) != 3 or bitar[0] != seed:
            continue
        poster.append((nar, bitar[1], bitar[2]))
    if not poster:
        return {"poster": [], "count": 0}

    karta, _delvis = spoiler_karta(seed)
    ut = []
    for nar, mode, namn in sorted(poster):
        svar = []
        for (reg, plats), item in karta.items():
            etikett = ("%s — %s" % (reg, plats)) if reg else plats
            if (mode == "item" and item == namn) or (mode == "plats"
                                                     and etikett == namn):
                svar.append(etikett if mode == "item" else item)
        ut.append({"mode": mode, "namn": namn, "nar": nar,
                   "svar": sorted(svar)})
    return {"poster": ut, "count": len(ut)}


def spoiler_visad(seed, namn):
    """{"item", "plats"} for a location - but ONLY if it has ALREADY been read.

        ⚠️ The requirement boxes must never send a location's contents. That is
        the whole reason the spoiler is a two-step flow with a confirmation.
        This one answers only when the player has already paid for the answer:
        either they looked the LOCATION up, or they looked the ITEM up and were
        told it lies here. Nothing new is revealed, and nothing is recorded -
        the log is only read.

        An item lookup counts for every location holding that item, because the
        reveal showed all of them at once. Looking up "Missile" in a Metroid
        seed therefore lights up every missile.
    """
    loggen = _load_spoil()
    if not loggen or not seed or not namn:
        return None
    # Nara grupper slas ihop till "King Zora / Zora's Ledge" - samma uppdelning
    # som bada kravfragorna gor, plus placeringens egna stavningar.
    namn = _plats_kandidater(namn)
    try:
        karta, _delvis = spoiler_karta(seed)
    except (OSError, ValueError):
        return None
    for (reg, plats), item in karta.items():
        if plats not in namn:
            continue
        etikett = ("%s — %s" % (reg, plats)) if reg else plats
        if ("%s|plats|%s" % (seed, etikett)) in loggen \
                or ("%s|item|%s" % (seed, item)) in loggen:
            return {"item": item, "plats": etikett}
    return None


# Our map marker names -> the names the PLACEMENT uses.
#
# ⚠️ NOT the same table as SMZ3_LOC_ALIAS, and they must not be merged. The
# logic service normalises its answers to OUR spellings ("Bombs" -> "Bomb"),
# while the placement read out of the ROM keeps TotalSMZ3's own. Put these four
# in SMZ3_LOC_ALIAS and reachability breaks for exactly them, because reachd
# never says "Bombs".
#
# Measured across every marker in an SMZ3 seed and an ALTTPR one: these four
# are the only real misses. The rest that find no placement are dungeon
# entrances and bosses, which have none, and Metroid names in a Zelda-only
# seed. ⚠️ ALTTPR's spoiler file DOES say "Cave 45", so the original name has
# to stay in the candidate set - the alias is added, never substituted.
SMZ3_PLAC_ALIAS = {
    "Bomb": "Bombs",
    "Grapple Beam": "Grappling Beam",
    "Missile (Grapple Beam)": "Missile (Grappling Beam)",
    "Cave 45": "South of Grove",
}


def _plats_kandidater(namn):
    """Every spelling a marker name can have in a placement."""
    kand = {namn} | {d.strip() for d in namn.split(" / ")}
    return kand | {SMZ3_PLAC_ALIAS[k] for k in kand if k in SMZ3_PLAC_ALIAS}


def _placerat_item(seed, namn):
    """The item the seed put at `namn`, or None. Says nothing about whether it
        has been taken - the callers decide that, and they must."""
    kand = _plats_kandidater(namn)
    try:
        karta, _delvis = spoiler_karta(seed)
    except (OSError, ValueError):
        return None
    for (_reg, plats), item in karta.items():
        if plats in kand:
            return item
    return None


def hamtat_lista(seed, namn, tagen):
    """[{"plats", "item"}] for the locations among `namn` already EMPTIED.

        Showing what was in a location you have already emptied is not a
        spoiler - you picked it up and saw it. That is the same reasoning the
        spoiler log follows when it shows an answer again.

        🔴 But it stands or falls with the reading being EXACT, per LOCATION.
        ALTTP's overworld flags sit per SCREEN, so "cleared" there is an
        approximation - it can call a location emptied that is not, and handing
        out the contents of one nobody has opened is exactly the spoiler the
        two-step flow exists to prevent. `tagen` must therefore answer None for
        everything it cannot read precisely, and None is treated as "no".
    """
    ut = []
    for n in namn:
        if not n or tagen(n) is not True:
            continue
        item = _placerat_item(seed, n)
        if item:
            ut.append({"plats": n, "item": _display(item)})
    return ut


def spoiler_avsloja(seed, mode, namn):
    """Reveals AND records. One lookup = one spoiler, however many lines it gives."""
    karta, delvis = spoiler_karta(seed)
    hits = []
    for (reg, plats), item in karta.items():
        etikett = ("%s — %s" % (reg, plats)) if reg else plats
        if (mode == "item" and item == namn) or (mode == "plats"
                                                 and etikett == namn):
            hits.append({"region": reg, "name": plats, "item": item})
    if not hits:
        return {"ok": False, "message": "hittade inte det du valde",
                "count": spoil_count(seed)}
    hits.sort(key=lambda h: (h["region"], h["name"]))
    return {"ok": True, "hits": hits, "delvis": delvis,
            "count": spoil_add(seed, mode, namn)}


# ⚠️ FRESH_HOURS = 6 used to sit here: the logic only ran for save files newer
# than six hours. The effect was that ALL colours disappeared the day after
# you played - the map went entirely grey and looked as if the logic had
# broken. A cleared run went from colourful to grey overnight.
#
# The condition is now "the seed has been STARTED" instead. A run set aside
# for two days is still a run you can come back to; a seed without a save
# file, on the other hand, has nothing to compute. The cost is bounded by the
# answer being cached on _trk_sig() and only recomputed when a save changes.


def points(ow_raw, seed, inv, raw, fresh=True):
    """One dot per marked location: green if the item is picked up, otherwise grey.

        ⚠️ An approximation. We have the MAP POSITION for every location, but not
        the location -> SRAM flag mapping. The overworld does have one byte per
        screen, and the position reveals which screen a location sits on - bit
        0x40 means "item picked up" (measured by diffing two save files). If
        several locations share a screen they therefore go green at the same
        time. It becomes exact once the room/chest mapping exists.
    """
    items = _item_map(seed)
    manual = _load_checks()
    locked = (ap_locked(inv, _prizes_for_seed(seed, raw), seed)
              if fresh else None)
    out = []
    for key, pos in _load_anno().items():
        region, _, name = key.partition("|")
        if region == DUNGEON_REGION or not isinstance(pos, dict):
            continue
        if pos.get("world") not in ("lw", "dw"):
            continue        # Metroid-platser hor till SMZ3-kartorna
        try:
            x, y, world = float(pos["x"]), float(pos["y"]), pos["world"]
        except (KeyError, TypeError, ValueError):
            continue
        # 1. A unique item in the inventory -> the location is demonstrably taken.
        mkey = "%s|%s|%s" % (seed, region, name)
        off = UNIQUE_ITEMS.get(items.get((region, name), ""))
        if mkey in manual:
            # The player has spoken. Their word beats both derivation and
            # guessing - the derivation can be wrong, and must then be
            # correctable. exact=False keeps the dot clickable.
            taken, exact = bool(manual[mkey]), False
        elif off is not None:
            taken, exact = bool(inv.get(off)), True
        elif chest_open(name, raw) is not None:
            # Its own chest flag from SRAM - exact, and per location.
            taken, exact = chest_open(name, raw), True
        else:
            # 2. Otherwise: has anything been picked up on the screen the location is on?
            col = min(7, max(0, int(x * 8)))
            row = min(7, max(0, int(y * 8)))
            idx = row * 8 + col + (0 if world == "lw" else 64)
            taken = bool(ow_raw[idx] & 0x40) if idx < len(ow_raw) else False
            exact = False
        # Archipelago decides. Its rules are complete and validated by 169
        # tests; the hand-written ones were stopgaps from before we had real
        # logic and were wrong where they differed - "King's Tomb" required only
        # boots, but it also needs Titan's Mitts or the mirror.
        #
        # logic.json is only used when the service does not answer, so the map
        # is not left completely without an opinion. If that is empty too, rc
        # stays neutral - never falsely green.
        # Archipelago is the only source. If it does not answer, the dot is
        # left without an opinion - no colour at all rather than a guess. The old
        # hand-written fallback logic has been removed: logic.json and
        # regions.json were empty, and the medallion requirement produced the
        # odd red dot among colourless ones, which looked like a half-finished
        # svar i stallet for ett medvetet avstangt.
        rc = (name not in locked) if (fresh and locked is not None) else None
        out.append({"name": name, "region": region, "world": world,
                    "x": round(x, 5), "y": round(y, 5),
                    "open": taken, "exact": exact,
                    "manual": mkey in manual,
                    "reach": rc})
    return _group(out, raw)


# Exact chest flags per location. The data comes from hutchch/ALTTPR-Tracker
# (MIT) - their map table links flag index to location name, and
# SRAM_FLAGS ger en (offset, mask) per enskild kista.
# Validated 2026-08-08: for the 14 entries that carry a chest count in the
# antalet flaggor exakt, 14 av 14.
CHEST_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "chestflags.json")
# The spoiler's names against the table's. Only where it is the same location
# under olika namn - inget gissande.
CHEST_ALIAS = {
    "blinds hideout": "Blind's Hut (5)",
    "bumper cave": "Bumper Cave Ledge",
    "desert ledge": "Desert West Ledge",
    "flute spot": "Flute Boy Spot",
    "kakariko tavern": "Tavern",
    "maze race": "Race Minigame",
    "sahasrahla": "Sahasrahla NPC",
    "superbunny cave": "Super Bunny Cave (2)",
}


def _norm_loc(s):
    s = re.sub(r"\(\d+\)", "", s).lower()
    s = re.sub(r"[^a-z0-9 ]", "", s)
    return re.sub(r"\s+", " ", s).strip()


def _load_chest_table():
    try:
        with open(CHEST_FILE) as f:
            raw = json.load(f)
    except (OSError, ValueError):
        return {}
    by_norm = {_norm_loc(k): v for k, v in raw.items()}
    for mine, theirs in CHEST_ALIAS.items():
        if theirs in raw:
            by_norm[mine] = raw[theirs]
    return by_norm


CHEST_TABLE = _load_chest_table()


def chest_state(name, raw):
    """(number opened, number of chests) for a location - or None if unknown.

        Exact: one flag per chest, read straight from SRAM. Replaces both the
        screen guessing and the hand ticking wherever it exists.
    """
    ent = CHEST_TABLE.get(_norm_loc(name))
    if not ent or not raw:
        return None
    got = 0
    for off, mask in ent["flags"]:
        if off < len(raw) and raw[off] & mask:
            got += 1
    return got, len(ent["flags"])


def _reach_of(members):
    """A group is red when everything THAT REMAINS is unreachable.

        Locations already cleared must not count. "Sahasrahla" is three chests in
        the hut plus Sahasrahla himself, who requires a pendant - if the chests
        are cleared and only he is left, the group should be red, not green. The
        same goes for "King Zora / Zora's Ledge", where the ledge needs flippers.

        If everything is cleared it does not matter: the dot is drawn as done anyway.
    """
    kvar = [m for m in members if not m["open"]] or members
    known = [m["reach"] for m in kvar if m["reach"] is not None]
    if not known:
        return None
    return True if any(known) else False


def _group(flat, raw):
    """Merges locations that share a base name into one dot.

        "Kakariko Well - Top/Left/Middle/Right/Bottom" sit in the same spot on
        the map and could not be hit separately with a thumb. They become one dot
        showing "2/5" that opens a list where each chest is ticked off
        individually. The position is the average of the members', so the dot
        lands in the middle of the cluster even if the markers spread a few pixels.
    """
    groups = {}
    for p in flat:
        base = p["name"].split(" - ")[0].strip()
        key = (p["region"], base, p["world"])
        g = groups.setdefault(key, {"name": base, "region": p["region"],
                                    "world": p["world"], "members": []})
        g["members"].append({"name": p["name"], "open": p["open"],
                             "exact": p["exact"], "reach": p["reach"],
                             "manual": p.get("manual", False),
                             "x": p["x"], "y": p["y"]})
    out = []
    for g in groups.values():
        m = g["members"]
        g["x"] = round(sum(i["x"] for i in m) / len(m), 5)
        g["y"] = round(sum(i["y"] for i in m) / len(m), 5)
        g["total"] = len(m)
        g["open"] = sum(1 for i in m if i["open"])
        # A group is locked only if EVERY member is derived.
        g["exact"] = all(i["exact"] for i in m)
        # If the location is in the chest table, the exact reading beats both
        # screen guessing and hand ticking. Requiring equal counts is a
        # safety catch: if they differ, the names have been paired wrongly.
        cs = chest_state(g["name"], raw)
        # ⚠️ The chest table is normally the most reliable, but a hand tick
        # must come first - otherwise a wrong reading cannot be corrected,
        # and the lock has merely moved one level down.
        if cs and cs[1] == g["total"] and not any(i.get("manual") for i in m):
            g["open"] = cs[0]
            g["exact"] = True
            for j, mem in enumerate(m):
                mem["open"] = j < cs[0]
                mem["exact"] = True
        # After the correction: reach has to mirror which members actually
        # remain, or a group looks green because the cleared ones were reachable.
        g["reach"] = _reach_of(m)
        # Colour states, the same language as dungeons:
        # done = all empty | can = everything left is reachable
        # part = some is | no = none is
        kvar = [i for i in m if not i["open"]]
        if not kvar:
            g["state"] = "done"
        else:
            kanda = [i["reach"] for i in kvar if i["reach"] is not None]
            if not kanda:
                g["state"] = None
            elif all(kanda):
                g["state"] = "can"
            elif any(kanda):
                g["state"] = "part"
            else:
                g["state"] = "no"
        for i in m:
            i.pop("x", None)
            i.pop("y", None)
        out.append(g)
    out.sort(key=lambda p: (p["region"], p["name"]))
    return _merge_close(out)


# How close two markers may sit before they are merged. 0.015 = 1.5 % of the
# map width, so roughly a tenth of a screen - tight enough to catch only
# markers that practically lie on top of each other.
MERGE_DIST = 0.015


def _merge_close(groups):
    """Merges groups that ended up on top of each other on the map.

        "King Zora" and "Zora's Ledge" do not share a base name but sit 0.7 %
        apart - impossible to hit separately with a thumb. Rather than hand-pick
        special cases, all such clusters are merged automatically, so the problem
        does not come back for the next location marked close to another.
    """
    out = []
    for g in groups:
        for h in out:
            if h["world"] != g["world"]:
                continue
            if abs(h["x"] - g["x"]) > MERGE_DIST:
                continue
            if abs(h["y"] - g["y"]) > MERGE_DIST:
                continue
            n = len(h["members"]) + len(g["members"])
            h["x"] = round((h["x"] * len(h["members"])
                            + g["x"] * len(g["members"])) / n, 5)
            h["y"] = round((h["y"] * len(h["members"])
                            + g["y"] * len(g["members"])) / n, 5)
            h["members"] += g["members"]
            h["total"] = n
            h["open"] += g["open"]
            h["exact"] = h["exact"] and g["exact"]
            h["reach"] = _reach_of(h["members"])
            hk = [i for i in h["members"] if not i["open"]]
            hkanda = [i["reach"] for i in hk if i["reach"] is not None]
            h["state"] = ("done" if not hk else
                          None if not hkanda else
                          "can" if all(hkanda) else
                          "part" if any(hkanda) else "no")
            if not g["name"].startswith(h["name"]):
                h["name"] = "%s / %s" % (h["name"], g["name"])
            break
        else:
            out.append(g)
    return out


# tracker() makes ~15 calls to reachd per request - one per dungeon - and
# therefore takes 1-2 s. But the answer can only change when a save file is
# rewritten (which happens when the OSD opens) or when the player edits their
# notes. As long as neither has happened the old answer is exactly right.
_trk_cache = [None, None]


def _trk_sig():
    """Changes when anything that affects the answer changes."""
    sig = []
    # ⚠️ The ROM list MUST be included. Without it the signature missed everything
    # that happens when a seed is generated: a new ALTTPR seed has no save file,
    # so the save files or the three json files change - the cache considered
    # current and the new seed never appeared. Found 2026-08-12 by generating a
    # seed and seeing the card fail to show up even though scan() had indexed the
    # ROM. The list is already in memory, so it costs nothing.
    with _lock:
        sig.append(("roms", tuple(_index.get("ALTTPR", []))))
    try:
        d = os.path.join(SAVES, "SNES")
        for fn in sorted(os.listdir(d)):
            if fn.lower().endswith(".sav") and fn.lower().startswith("alttpr"):
                sig.append((fn, os.path.getmtime(os.path.join(d, fn))))
    except OSError:
        pass
    for f in (PROG_FILE, MEDAL_FILE, ANNO_FILE, SPOIL_FILE):
        try:
            sig.append((f, os.path.getmtime(f)))
        except OSError:
            pass
    # ⚠️ Live data appears in NO timestamp. Without this line the cache would
    # have considered the answer current however much the player played, and the
    # whole point of SNI would be lost - the map would only update when the save
    # file was written, which is precisely what we wanted to get away from.
    #
    # ⚠️ Do NOT use the timestamp of the last SNI fetch here. It is only updated
    # WHEN somebody fetches, and _trk_sig does not fetch itself - so the
    # signature would have locked on the first value and the cache served the
    # same answer forever. A time bucket is duller but actually correct:
    # while a seed is running the answer is recomputed at most every SNI_TTL second.
    lev = live_seed()
    if lev:
        sig.append(("live", lev, int(time.time() / SNI_TTL)))
    return tuple(sig)


# --- SMZ3 -----------------------------------------------------------------
# Save format mapped 2026-08-10: the Zelda half sits at ALTTP's usual
# offsets, the Metroid half in one of three save slots. Collected Metroid
# is a bitfield where the bit is the location's Id from Archipelago's table.
SMLOC_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "smlocs.json")
SM_AREAS = ["Crateria", "Brinstar", "Norfair", "LowerNorfair",
            "WreckedShip", "Maridia"]
SM_AREA_NAMN = {"LowerNorfair": "Lower Norfair", "WreckedShip": "Wrecked Ship"}
# Save slot -> (ammo base, item bitfield). Measured on two seeds; SM has three
# slots and the file mirrors which one was used.
SM_SLOTS = [(0x2030, 0x20C0), (0x3920, 0x39B0), (0x1140, 0x11D0)]

# TotalSMZ3 gives its four REWARD bosses a CanComplete() of their own, and
# every one of them is defined as "can you get the item the boss guards":
#
#   Kraid     Brinstar/Kraid.py       GetLocation("Varia Suit").Available
#   Phantoon  WreckedShip.py          CanEnter() and CanUnlockShip()
#   Draygon   Maridia/Inner.py        GetLocation("Space Jump").Available
#   Ridley    NorfairLower/East.py    GetLocation("Energy Tank, Ridley").Available
#
# So the boss's own location already answers the question, and the logic
# service needs no new endpoint - the answer is in the reply it sends anyway.
# Phantoon's rule is not a location, but "Missile (Wrecked Ship top)" carries
# exactly that rule and nothing else, so it says the same thing.
#
# ⚠️ The other six (Bomb Torizo, Spore Spawn, Crocomire, Botwoon, Golden
# Torizo, Mother Brain) have NO rule in TotalSMZ3 - they are neither locations
# nor rewards.
# Writing one here by hand is precisely what this project does not do (see the
# note on smz3_reach), so they keep their "no opinion" marker.
#
# ⚠️ None of this counts AMMUNITION. Missile, Super and PowerBomb are booleans
# in Progression - "do you own any at all". The only quantity in the whole of
# TotalSMZ3 is HasEnergyReserves(n), and that counts E-tanks for hell runs.
# The logic answers whether you can STAND IN FRONT OF the boss, never whether
# you can win the fight.
# Super Metroid's OWN boss flags, and the straight answer to "is it felled":
# ONE byte per area from $7ED828, mirrored into the save slot 0x48 bytes ahead
# of the item bits (0x20C0 -> 0x2078 in slot 1).
#
# ⚠️ ONE byte per area, not two. Vanilla documentation describes the array as
# 16-bit per area, and reading it that way gives pure nonsense here - it was
# what made this look, for a whole afternoon, like SMZ3 kept its bosses
# somewhere else entirely.
#
# Verified 2026-09-13 on four independent snapshots with nothing left over:
# live memory before and after Botwoon was felled (the 0x02 bit appearing in
# Maridia is the measurement itself), the save file from earlier the same day
# with Draygon still alive, and a second seed where Ridley had been felled.
SM_BOSS_OFF = -0x48           # fran platsbitarnas bas till $7ED828
# boss -> (omradesindex, bit). 0x01 omradets boss, 0x02 minibossen, 0x04 Torizo.
SM_BOSS_FLAGGA = {
    "Bomb Torizo": (0, 0x04),
    "Kraid": (1, 0x01), "Spore Spawn": (1, 0x02),
    "Ridley": (2, 0x01), "Crocomire": (2, 0x02), "Golden Torizo": (2, 0x04),
    "Phantoon": (3, 0x01),
    "Draygon": (4, 0x01), "Botwoon": (4, 0x02),
    "Mother Brain": (5, 0x01),
}

SMZ3_BOSS_LOGIK = {
    "Kraid": "Varia Suit",
    "Phantoon": "Missile (Wrecked Ship top)",
    "Draygon": "Space Jump",
    "Ridley": "Energy Tank, Ridley",
}
# The same four, by the region whose reward bit says the boss is beaten AND its
# token collected. Read from 0x374/0x37A, like the Zelda pendants.
SMZ3_BOSS_REGION = {
    "Kraid": "Brinstar Kraid", "Phantoon": "Wrecked Ship",
    "Draygon": "Maridia Inner", "Ridley": "Norfair Lower East",
}


def _load_smlocs():
    try:
        with open(SMLOC_FILE) as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


SMLOCS = _load_smlocs()


def sm_slot(raw):
    """Which save slot is in use, or None.

        Unused slots are filled with 0xFF. We pick the one where max energy is a
        plausible value - 99 at the start, at most 1499.
    """
    for ammo, bits in SM_SLOTS:
        if ammo + 2 >= len(raw):
            continue
        mx = raw[ammo + 2] | (raw[ammo + 3] << 8)
        if 99 <= mx <= 1499 and mx % 100 == 99:
            return ammo, bits
    return None


def smz3_state(raw, rom=None):
    """The Metroid part: collected locations per area, plus ammo and logic."""
    slot = sm_slot(raw)
    if not slot or not SMLOCS:
        return None
    ammo, bits = slot
    tagna = set()
    for namn, (lid, _area) in SMLOCS.items():
        if lid is None:
            continue          # boss: ingen bit i foremalsfaltet
        off = bits + (lid >> 3)
        if off < len(raw) and raw[off] & (1 << (lid & 7)):
            tagna.add(namn)
    # The logic only runs when we know which seed it is - the prizes are in the
    # seed's own file, and without them TotalSMZ3 answers about a different world.
    # Must be computed BEFORE the areas: they are coloured from it.
    ok = kanda = None
    prizes = {}
    # Hoisted out of the call: the boss markers need it too, to tell a beaten
    # boss from one that is merely reachable.
    klara = []
    # ⚠️ And which regions the reward can be read from AT ALL. A Metroid boss
    # holding a boss token instead of a pendant or crystal matches no signature
    # in _smz3_sm_belon, so nothing can be read there - and "not beaten" would
    # then be a lie rather than a measurement.
    lasbara = []
    if rom:
        prizes, medals, kand = _smz3_meta(rom)
        klara = _smz3_klara(raw, rom)
        lasbara = _smz3_lasta(rom)
        if kand:
            ok, kanda = smz3_reach(_smz3_items(raw, ammo), prizes, medals,
                                   klara, lasbara)

    omr = []
    for a in SM_AREAS:
        i = sorted(n for n, (l, ar) in SMLOCS.items()
                   if ar == a and l is not None)
        kvar = [n for n in i if n not in tagna]
        rest = [x for x in (_smz3_reach_of(n, ok, kanda) for n in kvar)
                if x is not None]
        omr.append({"id": a, "name": SM_AREA_NAMN.get(a, a),
                    "reward": prizes.get(SMZ3_AREA_PRIS.get(a, "")),
                    "total": len(i),
                    "open": sum(1 for n in i if n in tagna),
                    # The same four states as the Zelda dungeons: green when
                    # everything REMAINING is reachable, blue when some of it is,
                    # red when none is. Locations already cleared must not
                    # count - otherwise an area looks green because what you
                    # already collected was reachable.
                    "state": ("done" if not kvar else
                              None if not rest else
                              "can" if all(rest) else
                              "part" if any(rest) else "no"),
                    # The locations one by one - the area is shown as a list, not
                    # as a map, so no positions are needed.
                    "locs": [{"name": n, "open": n in tagna,
                              "reach": _smz3_reach_of(n, ok, kanda)}
                             for n in i]})

    def w(o):
        return raw[o] | (raw[o + 1] << 8) if o + 1 < len(raw) else 0

    return {
        "areas": omr,
        "points": _sm_punkter(tagna, ok, kanda, klara, lasbara, raw, bits),
        "portals": _smz3_portaler(),
        "zpoints": _smz3_zpunkter(raw, ok, kanda),
        "zdungeons": _smz3_dungeons(raw, ok, kanda, prizes),
        "logik": kanda is not None,
        "open": len(tagna),
        # Bosses are not counted - they have no bit to read.
        "total": sum(1 for l, _a in SMLOCS.values() if l is not None),
        "energi": w(ammo), "max_energi": w(ammo + 2),
        "missiler": w(ammo + 4), "supers": w(ammo + 8),
        "pb": w(ammo + 12),
    }



def _boss_fallen(namn, logik, region, raw, bits, tagna, klara, lasbara):
    """True / False / None - has this boss been felled?

        The game's own flag comes first: SM_BOSS_FLAGGA reads the bit Super
        Metroid itself sets when the boss dies, so this is a measurement and
        not an inference. It covers all ten bosses, it is exact in both
        directions, and from live memory it turns the moment the fight ends.

        The two older sources are kept underneath, for a save too short to
        hold the block:

        ⚠️ The item BEHIND the boss. Varia cannot be picked up without felling
        Kraid, and TotalSMZ3 defines the boss by exactly that location (see
        SMZ3_BOSS_LOGIK) - the randomizer's own pairing, not a rule written
        here. Only ONE direction holds: item taken => boss felled, while an
        item still lying there says nothing.

        ⚠️ Last the reward bit, which arrives latest of all - the token can lie
        in the room for hours after the fight - and not at all for a boss
        guarding a boss token instead of a pendant.
    """
    flagga = SM_BOSS_FLAGGA.get(namn)
    if flagga:
        off = bits + SM_BOSS_OFF + flagga[0]
        if 0 <= off < len(raw):
            return bool(raw[off] & flagga[1])
    if logik and logik in tagna:
        return True
    if region and region in lasbara:
        return region in klara
    return None


def _sm_punkter(tagna, ok=None, kanda=None, klara=(), lasbara=(),
                raw=(), bits=0):
    """The player's markers on the world map. Bosses have no Id and cannot be
        read from the item field - they get "boss": true.

        For the four reward bosses "open" therefore comes from the reward bit
        instead (beaten AND the token taken), and "reach" from the randomizer's
        own CanComplete, asked through the location that defines it. "logic"
        names that location so the requirement box has something to ask about.
        The other five bosses have no rule at all and keep reach None.

        ⚠️ "open" is None - not False - when the reward cannot be read for this
        seed. A boss guarding a boss token instead of a pendant leaves no
        readable bit, and a False there would claim a measurement we never made.
    """
    anno = _load_anno()
    ut = []
    for namn, (lid, area) in SMLOCS.items():
        pos = anno.get("Metroid|" + namn)
        if not isinstance(pos, dict):
            continue
        boss = lid is None
        # The location whose rule IS the boss's rule - None for the five that
        # the randomizer says nothing about.
        logik = SMZ3_BOSS_LOGIK.get(namn) if boss else namn
        # The region whose reward bit stands for this boss, but only when that
        # bit can be read in this seed at all.
        region = SMZ3_BOSS_REGION.get(namn) if boss else None
        try:
            ut.append({"name": namn, "area": area, "boss": boss,
                       "logic": logik if boss else None,
                       "x": round(float(pos["x"]), 5),
                       "y": round(float(pos["y"]), 5),
                       "open": _boss_fallen(namn, logik, region, raw, bits,
                                            tagna, klara, lasbara) if boss
                               else (namn in tagna),
                       "reach": (_smz3_reach_of(logik, ok, kanda)
                                 if logik else None)})
        except (KeyError, TypeError, ValueError):
            continue
    return ut

# --- SMZ3: atkomstlogik ---------------------------------------------------
# Its own endpoint at reachd, its own cache, its own backoff. Nothing here is
# shared with the ALTTP half - that map must not be affected from here.
SMZ3_REACH_URL = os.environ.get("SMZ3_REACH_URL",
                                "http://127.0.0.1:8183/smz3reach")

# ALTTP's LOGIC_ITEMS ids -> SMZ3's ItemType names. Progressive items and
# de delade bytena hanteras for sig nedan.
#
# ⚠️ "bombs" is NOT included. In SMZ3, Morph Ball Bombs are called `Bombs`,
# and Zelda's bombs are something else entirely - mapped straight across,
# every seed would look like it had morph bombs from the start.
SMZ3_ITEM_MAP = {
    "boots": "Boots", "flippers": "Flippers", "pearl": "MoonPearl",
    "mirror": "Mirror", "hammer": "Hammer", "hookshot": "Hookshot",
    "lamp": "Lamp", "firerod": "Firerod", "icerod": "Icerod",
    "somaria": "Somaria", "byrna": "Byrna", "cape": "Cape",
    "book": "Book", "net": "Bugnet", "flute": "Flute", "shovel": "Shovel",
    "bow": "Bow", "boomerang": "BlueBoomerang", "powder": "Powder",
    "mushroom": "Mushroom", "bombos": "Bombos", "ether": "Ether",
    "quake": "Quake", "bottle": "Bottle",
}

SMZ3_PRIZE_REGIONS = {
    "Prize - Eastern Palace": "Eastern Palace",
    "Prize - Desert Palace": "Desert Palace",
    "Prize - Tower of Hera": "Tower of Hera",
    "Prize - Dark Palace": "Palace of Darkness",
    "Prize - Swamp Palace": "Swamp Palace",
    "Prize - Skull Woods": "Skull Woods",
    "Prize - Thieves' Town": "Thieves' Town",
    "Prize - Ice Palace": "Ice Palace",
    "Prize - Misery Mire": "Misery Mire",
    "Prize - Turtle Rock": "Turtle Rock",
    "Prize - Brinstar": "Brinstar Kraid",
    "Prize - Wrecked Ship": "Wrecked Ship",
    "Prize - Maridia": "Maridia Inner",
    "Prize - Norfair Lower": "Norfair Lower East",
}

# Our map marker names -> SMZ3's location names. 93 of 107 already match
# exactly and the rest are dungeon markers; this is the only one that is
# named differently. "Cave 45" is the cave's screen number, SMZ3 describes the spot instead.
SMZ3_LOC_ALIAS = {"Cave 45": "South of Grove"}

# Our dungeon names -> SMZ3's location prefixes. The sewer chests are called
# "Sewers - *" without the castle name but belong to Hyrule Castle, just as in
# ALTTP-halvan.
SMZ3_DUNGEON_PREFIX = {
    "Hyrule Castle": ("Hyrule Castle - ", "Sewers - "),
    "Castle Tower": ("Castle Tower - ",),
    "Eastern Palace": ("Eastern Palace - ",),
    "Desert Palace": ("Desert Palace - ",),
    "Tower Of Hera": ("Tower of Hera - ",),
    "Dark Palace": ("Palace of Darkness - ",),
    "Swamp Palace": ("Swamp Palace - ",),
    "Skull Woods": ("Skull Woods - ",),
    "Thieves Town": ("Thieves' Town - ",),
    "Ice Palace": ("Ice Palace - ",),
    "Misery Mire": ("Misery Mire - ",),
    "Turtle Rock": ("Turtle Rock - ",),
    "Ganons Tower": ("Ganon's Tower - ",),
}

# SMZ3 doper bossplatsen efter bossen, Archipelago kallar den "- Boss".
# Without this translation we lose the boss flag in ten dungeons, and a
# cleared dungeon looks like it is missing a chest.
SMZ3_BOSS_ALIAS = {
    "Eastern Palace - Armos Knights": "Eastern Palace - Boss",
    "Desert Palace - Lanmolas": "Desert Palace - Boss",
    "Tower of Hera - Moldorm": "Tower of Hera - Boss",
    "Palace of Darkness - Helmasaur King": "Palace of Darkness - Boss",
    "Swamp Palace - Arrghus": "Swamp Palace - Boss",
    "Skull Woods - Mothula": "Skull Woods - Boss",
    "Thieves' Town - Blind": "Thieves' Town - Boss",
    "Ice Palace - Kholdstare": "Ice Palace - Boss",
    "Misery Mire - Vitreous": "Misery Mire - Boss",
    "Turtle Rock - Trinexx": "Turtle Rock - Boss",
}

# The Metroid equipment as a bitfield. The same bits Super Metroid has always
# anvant; SMZ3 ardde dem rakt av.
SM_FOREMAL = [
    (0x0001, "Varia"), (0x0002, "SpringBall"), (0x0004, "Morph"),
    (0x0008, "ScrewAttack"), (0x0020, "Gravity"), (0x0100, "HiJump"),
    (0x0200, "SpaceJump"), (0x1000, "Bombs"), (0x2000, "SpeedBooster"),
    (0x4000, "Grapple"), (0x8000, "XRay"),
]
SM_STRALAR = [
    (0x0001, "Wave"), (0x0002, "Ice"), (0x0004, "Spazer"),
    (0x0008, "Plasma"), (0x1000, "Charge"),
]

# The three medallions. Listed here so everything else can be rejected.
SMZ3_MEDALLIONS = {"Ether", "Bombos", "Quake"}

# The bits in 0x366 -> SMZ3's ItemType names. The same field as BIG_KEY_BITS
# above, but SMZ3 has names of its own. Hyrule Castle is not listed: it has
# no big key in SMZ3's item table.
SMZ3_BIGKEY = [
    (0x2000, "BigKeyEP"), (0x1000, "BigKeyDP"), (0x0400, "BigKeySP"),
    (0x0200, "BigKeyPD"), (0x0100, "BigKeyMM"), (0x0080, "BigKeySW"),
    (0x0040, "BigKeyIP"), (0x0020, "BigKeyTH"), (0x0010, "BigKeyTT"),
    (0x0008, "BigKeyTR"), (0x0004, "BigKeyGT"),
]

# Metroid areas that also give a prize. The names are SMZ3's region names,
# the same ones the prize block in the seed's .txt uses.
# SMZ3's FOUR two-way portals between the games:
#
#   Lake Hylia      <-> Crateria        (no requirement at all)
#   Death Mountain  <-> Norfair Upper   CanAccessNorfairUpperPortal
#                                       CanAccessDeathMountainPortal
#   Misery Mire     <-> Norfair Lower   CanAccessNorfairLowerPortal
#                                       CanAccessMiseryMirePortal
#   Dark World lake <-> Maridia         CanAccessMaridiaPortal
#                                       CanAccessDarkWorldPortal
#
# Three of the pairs are TotalSMZ3's own accessors in Item.py, read straight
# out of the source.
#
# ⚠️ The fourth has NO accessor, and that is not an omission: the lake and
# the landing site connect freely in both directions, so the logic never needs
# to ask whether you can use it. Searching the logic for portals therefore
# finds three and misses this one - do not "clean it away" as unsupported.
#
# Each SIDE is its own marker, named after where it LEADS - that is what a door
# means when you are standing in front of it. {name: (map it sits on, map it
# opens)}; the maps are the page's own view names.
# ⚠️ The name says BOTH ends, "where it is → where it goes". Naming a door
# after its destination alone reads fine on the map, where you can see where
# you are standing - and is useless in the annotation tool's list, where you
# cannot. "Dark World" on its own tells you nothing about which Zebes room to
# put it in.
SMZ3_PORTALER = {
    "Lake Hylia → Crateria":     ("lw", "sm"),
    "Death Mountain → Norfair":  ("lw", "sm"),
    "Misery Mire → Lower Norfair": ("dw", "sm"),
    "Dark World lake → Maridia": ("dw", "sm"),
    "Crateria → Lake Hylia":     ("sm", "lw"),
    "Norfair → Death Mountain":  ("sm", "lw"),
    "Lower Norfair → Misery Mire": ("sm", "dw"),
    "Maridia → Dark World lake": ("sm", "dw"),
}
# The warp tiles INSIDE the Zelda half, Light World -> Dark World. The same
# eight in ALTTPR and SMZ3 (both are standard, not inverted), and TotalSMZ3's
# own CanEnter rules agree with them one for one. Names and requirements are
# Archipelago's (worlds/alttp Rules.py / EntranceShuffle.py):
#
#   Kakariko Teleporter             -> West Dark World   Hammer+glove, or mitts
#   East Hyrule Teleporter          -> East Dark World   Hammer+glove
#   South Hyrule Teleporter         -> South Dark World  Hammer+glove
#   Lake Hylia Central Island Tel.  -> Ice Palace island mitts
#   Dark Desert Teleporter          -> Misery Mire       flute+mitts
#   Death Mountain Teleporter       -> Dark DM west      nothing
#   East Death Mountain Teleporter  -> Dark DM east      mitts
#   Turtle Rock Teleporter          -> Turtle Rock       mitts+hammer
#
# ⚠️ ONE-WAY, and only drawn on the Light World. In the standard game there is
# no warp tile back - the Mirror takes you home from anywhere - so a door on
# the Dark World would claim a way out that does not exist. Knut chose this
# 2026-09-19. The Dark World landing spots are therefore not markers at all.
ZELDA_PORTALER = {
    "Kakariko → Village of Outcasts":             ("lw", "dw"),
    "East Hyrule → East Dark World":              ("lw", "dw"),
    "South Hyrule → South Dark World":            ("lw", "dw"),
    "Lake Hylia island → Ice Palace":             ("lw", "dw"),
    "Desert → Misery Mire":                       ("lw", "dw"),
    "Death Mountain → Dark Death Mountain":       ("lw", "dw"),
    "East Death Mountain → Dark Death Mountain East": ("lw", "dw"),
    "Turtle Rock ledge → Turtle Rock":            ("lw", "dw"),
}
PORTAL_REGION = "Portal"


def _smz3_portaler():
    """Every door an SMZ3 seed has: between the games AND within Zelda."""
    return _portaler(SMZ3_PORTALER) + _portaler(ZELDA_PORTALER)


def _portaler(tabell):
    """The placed doors, [{"name","to","world","x","y"}].

        ⚠️ Only the ones actually marked on a map. The positions live in
        annotations.json like every other marker and are shared between seeds -
        a portal sits in the same place in every seed, so there is nothing
        per-seed to store. An unplaced door simply does not appear.
    """
    anno = _load_anno()
    ut = []
    for namn, (pa, till) in tabell.items():
        pos = anno.get("%s|%s" % (PORTAL_REGION, namn))
        if not isinstance(pos, dict):
            continue
        try:
            ut.append({"name": namn, "to": till, "world": pa,
                       "x": round(float(pos["x"]), 5),
                       "y": round(float(pos["y"]), 5)})
        except (KeyError, TypeError, ValueError):
            continue
    return ut


SMZ3_AREA_PRIS = {
    "Brinstar": "Brinstar Kraid", "WreckedShip": "Wrecked Ship",
    "Maridia": "Maridia Inner", "LowerNorfair": "Norfair Lower East",
}

_smz3_cache = {}
_smz3_down_until = [0]
_smz3_meta_cache = {}


# SMZ3 spells a couple of locations differently from the flag table (which
# follows Archipelago). The apostrophe in "Ganon's Tower" is the big one: all
# 27 chests there looked unreadable purely because of it - the flags were there all along.
#
# ⚠️ "Ganon's Tower - Moldorm Chest" is deliberately NOT here. SMZ3 has two
# chests at Moldorm, Archipelago only "Pre-Moldorm Chest". Pointing both at
# the same flag would claim something we do not know, and would
#    dessutom dubbelrakna i dungeonens raknare. Den forblir okand.
SMZ3_NAME_ALIAS = {
    "Hyrule Castle - Zelda's Cell": "Hyrule Castle - Zelda's Chest",
    # Both have exactly two locations and "Dark Maze" matches straight off, so
    # the foyer is Archipelago's room 03 by elimination.
    "Castle Tower - Foyer": "Castle Tower - Room 03",
}


# Zelda dungeons whose prize can be determined from SRAM. The names are
# SMZ3's own region names, which here coincide with Archipelago's flag names.
SMZ3_PRISDUNGEON = ["Eastern Palace", "Desert Palace", "Tower of Hera",
                    "Palace of Darkness", "Swamp Palace", "Skull Woods",
                    "Thieves' Town", "Ice Palace", "Misery Mire",
                    "Turtle Rock"]


def _ar_smz3(seed):
    """Is the seed an SMZ3 seed? Decides whether the spoiler is only a playthrough."""
    try:
        for _dp, _dn, fns in os.walk(os.path.join(GAMES, "SNES", "SMZ3")):
            for f in fns:
                if f.lower().endswith(".sfc") and _hor_till_seed(f, seed):
                    return True
    except OSError:
        pass
    return False


# The Metroid bosses' reward. Their boss flag cannot be read, but a pendant or
# crystal they give is stored in Zelda's own bytes - 0x374 pendants, 0x37A
# crystals - so it can be read exactly like a Zelda dungeon's. Which bit a boss
# sets is shuffled per seed and written into the ROM by TotalSMZ3's
# RewardPatches (Patch.py): the first six of RewardAddresses per region, and
# the first six bytes of PendantValues/CrystalValues as the signature.
# Boss tokens are deliberately absent: where they are saved is unknown.
#
# Verified 2026-09-11 against the prize lists of seeds 89150499 and 361911764:
# all eight regions decoded to the reward the .txt names. And 361911764 has all
# 7 crystal bits set although only 5 crystals were in Zelda dungeons - the two
# from Kraid and Draygon did land in 0x37A.
SMZ3_SM_BELONING = {
    "Brinstar Kraid": (0xF26002, 0xF26004, 0xF26005, 0xF26000, 0xF26006, 0xF26007),
    "Wrecked Ship": (0xF2600A, 0xF2600C, 0xF2600D, 0xF26008, 0xF2600E, 0xF2600F),
    "Maridia Inner": (0xF26012, 0xF26014, 0xF26015, 0xF26010, 0xF26016, 0xF26017),
    "Norfair Lower East": (0xF2601A, 0xF2601C, 0xF2601D, 0xF26018, 0xF2601E, 0xF2601F),
}
SMZ3_BELONING_SIGNATUR = {
    # pendants -> 0x374
    (0x04, 0x38, 0x62, 0x00, 0x69, 0x01): (0x374, 0x04),   # green
    (0x01, 0x32, 0x60, 0x00, 0x69, 0x03): (0x374, 0x01),
    (0x02, 0x34, 0x60, 0x00, 0x69, 0x02): (0x374, 0x02),
    # crystals 1-7 -> 0x37A
    (0x02, 0x34, 0x64, 0x40, 0x7F, 0x06): (0x37A, 0x02),
    (0x10, 0x34, 0x64, 0x40, 0x79, 0x06): (0x37A, 0x10),
    (0x40, 0x34, 0x64, 0x40, 0x6C, 0x06): (0x37A, 0x40),
    (0x20, 0x34, 0x64, 0x40, 0x6D, 0x06): (0x37A, 0x20),
    (0x04, 0x32, 0x64, 0x40, 0x6E, 0x06): (0x37A, 0x04),
    (0x01, 0x32, 0x64, 0x40, 0x6F, 0x06): (0x37A, 0x01),
    (0x08, 0x34, 0x64, 0x40, 0x7C, 0x06): (0x37A, 0x08),
}
_smz3_belon_cache = {}


def _smz3_sm_belon(rom):
    """{Metroid region: (SRAM offset, bit)} for the bosses giving a pendant or crystal.

        A region whose bytes match no signature is left out - an unknown reward
        must stay unknown, not be guessed at.
    """
    if not rom:
        return {}
    try:
        nyckel = (rom, os.path.getmtime(rom))
    except OSError:
        return {}
    if nyckel in _smz3_belon_cache:
        return _smz3_belon_cache[nyckel]
    ut = {}
    try:
        with open(rom, "rb") as f:
            for region, adresser in SMZ3_SM_BELONING.items():
                sig = []
                for a in adresser:
                    off = _smz3_snes(a)
                    if off is None:
                        break
                    f.seek(off)
                    b = f.read(1)
                    if not b:
                        break
                    sig.append(b[0])
                hit = SMZ3_BELONING_SIGNATUR.get(tuple(sig))
                if hit:
                    ut[region] = hit
    except OSError:
        return {}
    _smz3_belon_cache[nyckel] = ut
    return ut


def _smz3_lasta(rom):
    """The Metroid regions whose reward can be read from the save file."""
    return sorted(_smz3_sm_belon(rom))


def _smz3_klara(raw, rom=None):
    """Regions whose reward has actually been COLLECTED.

        Otherwise TotalSMZ3 only asks whether the dungeon CAN be cleared, which
        makes the big bomb, for one, look purchasable before the crystals have
        been taken. The boss flag is the same one the ALTTP half reads.
    """
    ut = []
    for namn in SMZ3_PRISDUNGEON:
        if chest_open(namn + " - Boss", raw):
            ut.append(namn)
    # Castle Tower gives Agahnim; the progress meter at 0x3C5 says whether he is
    # beaten. The same thresholds the ALTTP half uses.
    if len(raw) > 0x3C5 and raw[0x3C5] >= 3:
        ut.append("Castle Tower")
    # Metroid bosses: the reward's own bit. Only regions in _smz3_lasta(rom) -
    # the logic overrides exactly those, and nothing else.
    for region, (off, bit) in _smz3_sm_belon(rom).items():
        if off < len(raw) and raw[off] & bit:
            ut.append(region)
    return ut


def _smz3_chest(namn, raw):
    """chest_open, but with SMZ3's spellings translated. None = unknown."""
    for kand in (namn,
                 SMZ3_NAME_ALIAS.get(namn),
                 SMZ3_BOSS_ALIAS.get(namn),
                 namn.replace("Ganon's Tower", "Ganons Tower")):
        if not kand:
            continue
        st = chest_open(kand, raw)
        if st is not None:
            return st
    return None


def _smz3_meta(rom):
    """(prizes, medallions, known) from the seed's .txt next to the ROM.

        It is a playthrough, not a full placement - but the last block holds the
        prize distribution and the medallion requirements, and the logic cannot
        guess those. Without the file TotalSMZ3 randomises its own, and then it
        answers about a different world than the one being played.

        ⚠️ `known` is not cosmetic. If the file is missing the logic must NOT
        run - a dot with no opinion is honest, a dot built on default medallions
        is a guess that looks like an answer. Not every seed has a .txt: seeds
        fetched from somewhere other than the local generator lack it.
    """
    txt = os.path.splitext(rom)[0] + ".txt"
    try:
        st = os.path.getmtime(txt)
    except OSError:
        return {}, ["Ether", "Quake"], False
    hit = _smz3_meta_cache.get(txt)
    if hit and hit[0] == st:
        return hit[1], hit[2], True
    prizes, medals = {}, ["Ether", "Quake"]
    try:
        with open(txt) as f:
            data = json.load(f)
        for block in data:
            if not isinstance(block, dict):
                continue
            for k, v in block.items():
                if k in SMZ3_PRIZE_REGIONS:
                    prizes[SMZ3_PRIZE_REGIONS[k]] = v
                elif k == "Medallion Required - Misery Mire":
                    medals[0] = v
                elif k == "Medallion Required - Turtle Rock":
                    medals[1] = v
    except (OSError, ValueError):
        return {}, ["Ether", "Quake"], False
    # Half a file is no better than none: without the prize block we do not know
    # which dungeon gives what, and the world is then wrong.
    if len(prizes) < len(SMZ3_PRIZE_REGIONS):
        return {}, ["Ether", "Quake"], False
    # ⚠️ A medallion name we do not recognise must NOT slip through.
    # smz3_logic faller tillbaka pa Ether nar uppslaget missar, sa en
    # spelling we did not anticipate would give a confident answer about the
    # wrong medallion - exactly the mistake this file exists to avoid.
    if any(m not in SMZ3_MEDALLIONS for m in medals):
        return {}, ["Ether", "Quake"], False
    _smz3_meta_cache[txt] = (st, prizes, medals)
    return prizes, medals, True


def _smz3_items(raw, ammo):
    """What the player has, as SMZ3's ItemType names.

        The Zelda half sits at ALTTP's offsets and is read with the same table.
        The Metroid half can only be read halfway: the MAX value for each
        ammunition type reveals whether the ability is held, and max energy how
        many energy tanks have been collected.

        ⚠️ The EQUIPMENT itself (Morph, Bombs, Varia, Gravity, Hi-Jump ...)
        cannot be read yet - the field is not located. It therefore counts as
        missing, which makes the dots CAUTIOUS: a location can be shown as locked
        when it is reachable, never the other way round. As long as no equipment
        items have been picked up the answer is exact as well.
    """
    inv = {o: (raw[o] if o < len(raw) else 0)
           for o in {i[2] for i in LOGIC_ITEMS} | set(BOTTLE_SLOTS)}
    out = []
    for iid, _n, off, need in LOGIC_ITEMS:
        namn = SMZ3_ITEM_MAP.get(iid)
        if namn and inv.get(off, 0) >= need:
            out.append(namn)
    # The bottles: the same four slots as in the ALTTP half, one entry per bottle.
    while "Bottle" in out:
        out.remove("Bottle")
    out += ["Bottle"] * sum(1 for o in BOTTLE_SLOTS if inv.get(o, 0))
    # The same shared bytes as in ALTTP: the mushroom is consumed once the powder
    # exists, and the shovel lives on as a bit after the flute overwrote the slot.
    if inv.get(0x344, 0) != 1 and "Mushroom" in out:
        out.remove("Mushroom")
    if not (inv.get(0x38C, 0) & 0x04 or inv.get(0x34C, 0) == 1):
        while "Shovel" in out:
            out.remove("Shovel")
    # Progressive items: the level in SRAM says how many have been picked up.
    out += ["ProgressiveGlove"] * min(2, inv.get(0x354, 0))
    out += ["ProgressiveSword"] * min(4, inv.get(0x359, 0))

    def w(o):
        return raw[o] | (raw[o + 1] << 8) if o + 1 < len(raw) else 0

    # ⚠️ THE EQUIPMENT, found 2026-08-11. Sits 0x20 and 0x1C respectively
    # BEFORE the ammo base, so it travels with any save slot.
    # Verified against a real seed: the player said "I have Speed Booster", and
    # faltet stod pa 0x2004 = Speed Booster + Morphing Ball. Dagen innan,
    # without equipment, it read 0x0000.
    for bit, typ in SM_FOREMAL:
        if w(ammo - 0x20) & bit:
            out.append(typ)
    for bit, typ in SM_STRALAR:
        if w(ammo - 0x1C) & bit:
            out.append(typ)
    if w(ammo + 6):
        out.append("Missile")
    if w(ammo + 10):
        out.append("Super")
    if w(ammo + 14):
        out.append("PowerBomb")
    # Max energy is 99 plus 100 per energy tank.
    out += ["ETank"] * max(0, (w(ammo + 2) - 99) // 100)
    # Big keys: the same 16-bit field the ALTTP half reads. They are never
    # consumed, so the field is the truth. Hand them out instead and a Big Chest
    # looks openable without its key.
    if len(raw) > 0x367:
        bk = raw[0x366] | (raw[0x367] << 8)
        for bit, typ in SMZ3_BIGKEY:
            if bk & bit:
                out.append(typ)
    return out


def smz3_reach(items, prizes, medals, klara=None, lasta=None):
    """(reachable, known) from reachd, or (None, None) if it does not answer.

        Both sets are needed: a location the logic does not know at all should
        end up WITHOUT AN OPINION, not red. The dungeon markers on the Zelda map
        are exactly that - they are our own markers, not locations in SMZ3.
    """
    key = (tuple(sorted(items)), tuple(sorted(prizes.items())),
           tuple(medals), None if klara is None else tuple(sorted(klara)),
           tuple(sorted(lasta or ())))
    if key in _smz3_cache:
        return _smz3_cache[key]
    if time.time() < _smz3_down_until[0]:
        return None, None
    try:
        body = json.dumps({"items": items, "rewards": prizes,
                           "medals": list(medals),
                           "klara": klara,
                           "sm_lasta": lasta or []}).encode()
        req = urllib.request.Request(
            SMZ3_REACH_URL, data=body,
            headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read().decode())
        ok = set(data.get("reachable") or [])
        kanda = ok | set(data.get("locked") or [])
    except Exception:                                          # noqa: BLE001
        _smz3_down_until[0] = time.time() + 20
        return None, None
    if len(_smz3_cache) < 200:
        _smz3_cache[key] = (ok, kanda)
    return ok, kanda


def _smz3_reach_of(namn, ok, kanda):
    """True/False/None for a location. None = the logic does not know it."""
    if kanda is None:
        return None
    namn = SMZ3_LOC_ALIAS.get(namn, namn)
    if namn not in kanda:
        return None
    return namn in ok


def _smz3_zpunkter(raw, ok, kanda):
    """The Zelda half's dots. The same markers the ALTTP map uses - the
        positions are seed-independent and shared between the games.

        The grouping is ALTTP's own: `_group` merges locations that share a base
        name ("Kakariko Well - Top/Left/...") and `_merge_close` those that ended
        up on top of each other on the map. Copying the code would have meant two
        places to fix the same bug - it is seed-independent and depends only on
        the markers, which both games share.
    """
    flat = []
    for key, pos in _load_anno().items():
        region, _, namn = key.partition("|")
        if region == DUNGEON_REGION or not isinstance(pos, dict):
            continue
        if pos.get("world") not in ("lw", "dw"):
            continue
        try:
            x, y = float(pos["x"]), float(pos["y"])
        except (KeyError, TypeError, ValueError):
            continue
        st = _smz3_chest(namn, raw)
        flat.append({"name": namn, "region": region, "world": pos["world"],
                     "x": round(x, 5), "y": round(y, 5),
                     "open": bool(st), "exact": st is not None,
                     "reach": _smz3_reach_of(namn, ok, kanda)})
    return _group(flat, raw)


def _smz3_dungeons(raw, ok, kanda, prizes=None):
    """Dungeon markers for SMZ3's Zelda maps.

        The ALTTP half builds them from the seed's spoiler in order to know which
        chests exist. That is not needed here: the logic knows every interior
        location by name and also says which ones are reachable, and the chest
        flags are read per location from the same SRAM. No spoiler is touched.

        ⚠️ `found` becomes None when no member can be read exactly. All of Ganons
        Tower is missing from the chest table, as are all but ten of the thirteen
        boss rooms - "?" is then more honest than a zero that looks like a
        measurement.
    """
    if kanda is None:
        return []
    anno = _load_anno()
    ut = []
    for namn, prefix in SMZ3_DUNGEON_PREFIX.items():
        pos = anno.get("%s|%s" % (DUNGEON_REGION, namn))
        if not isinstance(pos, dict) or pos.get("world") not in ("lw", "dw"):
            continue
        platser = sorted(n for n in kanda
                         if any(n.startswith(p) for p in prefix))
        if not platser:
            continue
        med = []
        for n in platser:
            st = _smz3_chest(n, raw)
            med.append({"name": n, "open": bool(st), "exact": st is not None,
                        "reach": n in ok})
        lasbara = [m for m in med if m["exact"]]
        kvar = [m for m in med if not m["open"]]
        rest = [m["reach"] for m in kvar]
        # The reward is visible on the map in the game before you go in, so it is
        # not a spoiler - the same reasoning the ALTTP half follows.
        region = prefix[0].rstrip(" -")
        ut.append({"name": namn, "pos": pos,
                   "reward": (prizes or {}).get(region),
                   "chests": len(med),
                   "found": (sum(1 for m in med if m["open"])
                             if lasbara else None),
                   "exact": len(lasbara) == len(med),
                   "state": ("done" if not kvar else
                             "can" if all(rest) else
                             "part" if any(rest) else "no"),
                   "members": med})
    return ut


# --- skins -----------------------------------------------------------------
# Every generated seed gets a random look for Link. It changes nothing in the
# game but makes the seed easier to remember than a hash - you recognise the
# squirrel, not "mykamxJmMQ". Name and preview image are written next to the
# ROM by the generator; seeds made before this existed use the default look.
SKIN_DEFAULT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                            "skin-default")


def _skin_for(rom_rel):
    """{"name", "author", "default"} for seedens ROM, aldrig None."""
    fall = {"name": "Link", "author": "Nintendo", "samus": "",
            "samus_author": "", "samus_index": None, "default": True}
    # SMZ3 has two looks, so even the default state should show both.
    # Cell 0 in the strip is Samus's ordinary suit.
    if rom_rel and rom_rel.startswith("SMZ3" + os.sep):
        fall = dict(fall, samus="Samus", samus_author="Nintendo",
                    samus_index=0)
    if not rom_rel:
        return fall
    bas = os.path.join(GAMES, "SNES", rom_rel)
    # Does the seed have a cropped Samus image of its own? Then the card should
    # show THAT and not count cells in the shared strip. One stat, once per card.
    egen = os.path.exists(os.path.splitext(bas)[0] + ".samus.png")
    fall = dict(fall, samus_file=egen)
    try:
        with open(os.path.splitext(bas)[0] + ".skin.json") as f:
            d = json.load(f)
        if d.get("name") or d.get("samus"):
            return {"name": d.get("name") or "Link",
                    "author": d.get("author") or "",
                    "samus": d.get("samus") or fall.get("samus", ""),
                    "samus_author": (d.get("samus_author")
                                     or fall.get("samus_author", "")),
                    "samus_index": (d.get("samus_index")
                                    if d.get("samus") else
                                    fall.get("samus_index")),
                    "samus_file": egen,
                    "default": not d.get("name")}
    except (OSError, ValueError):
        pass
    return fall


def skin_png(seed):
    """The preview image for a seed as bytes, otherwise the default image.

        Looks up by file name rather than going through the tracker - the image
        is fetched once per card and should not cost a tracker build.
    """
    if seed:
        for grund in ("ALTTPR", "SMZ3", "Alltp Randomizer"):
            try:
                for dp, _dn, fns in os.walk(os.path.join(GAMES, "SNES", grund)):
                    for fn in fns:
                        if fn.endswith(".skin.png") and seed in fn:
                            with open(os.path.join(dp, fn), "rb") as f:
                                return f.read()
            except OSError:
                continue
    try:
        with open(SKIN_DEFAULT + ".png", "rb") as f:
            return f.read()
    except OSError:
        return None


def samus_png(seed):
    """The seed's OWN Samus image as bytes, otherwise None.

        ⚠️ The difference from samus_index: the index points into the SHARED
        strip sprites-sm.png. If the strip is replaced at samus.link, every old
        seed's index points at the wrong cell, silently. This file is cropped at
        generation time and cannot drift. If it is missing the card falls back on
        the strip as before.
    """
    if not seed:
        return None
    try:
        for dp, _dn, fns in os.walk(os.path.join(GAMES, "SNES", "SMZ3")):
            for fn in fns:
                if fn.endswith(".samus.png") and _hor_till_seed(fn, seed):
                    with open(os.path.join(dp, fn), "rb") as f:
                        return f.read()
    except OSError:
        pass
    return None


# SMZ3:s logik svarar med randomizerns egna namn. ALTTP-halvan av
# interface has long used its own vocabulary, so the same item was named
# differently in the two games. Here the ZELDA half is translated to exactly
# the same names AP_TO_DISPLAY uses.
#
# ⚠️ The Metroid items are deliberately left in English - that is what
# randomizer players call them ("Space Jump", "Varia suit", "Morph ball
# bombs"), and they are proper names in the game. Translating them would
# make the answer harder to recognise, not easier.
SMZ3_DISPLAY = {
    "Blue Boomerang": "Boomerang", "Red Boomerang": "Red Boomerang",
    "Bottle": "Bottle", "Bow": "Bow", "Bug Catching Net": "Bug Net",
    "Fire Rod": "Fire Rod", "Ice Rod": "Ice Rod", "Flute": "Flute",
    "Half Magic": "Half Magic", "Hammer": "Hammer", "Lamp": "Lamp",
    "Heart Container": "Heart Container", "Heart Piece": "Heart Piece",
    "Magic Cape": "Cape", "Magic Mirror": "Magic Mirror",
    "Magic Powder": "Magic Powder", "Mushroom": "Mushroom",
    "Shovel": "Shovel", "Silver Arrows": "Silver Arrows",
    "Zora's Flippers": "Flippers",
    "Progressive Glove": "Glove", "Progressive Mail": "Mail",
    "Progressive Shield": "Shield", "Progressive Sword": "Sword",
}


# ALTTP's spoiler file writes item names with no spaces at all -
# "PieceOfHeart", "ThreeBombs", "TwentyRupees". SMZ3's side reads its names out
# of the ROM and already has them spaced, so only the Zelda half needs this.
_VERSALER = re.compile(r"(?<=[a-z0-9])(?=[A-Z])")
# Joining words are lower case in a real name: "Piece of Heart", not "Of".
_SMAORD = {"Of": "of", "The": "the", "And": "and", "A": "a"}


def _mellanslag(namn):
    """"PieceOfHeart" -> "Piece of Heart". A name that already has a space is
        left exactly as it is, so this can sit in the common path.

        ⚠️ Splits only on a capital that FOLLOWS a lower-case letter. "ETank"
        and "XRay" therefore come through untouched, which is what we want -
        they have their own names in _smz3_visning and must not be pulled apart.
    """
    if not namn or " " in namn:
        return namn
    delar = _VERSALER.split(namn)
    return " ".join([delar[0]] + [_SMAORD.get(d, d) for d in delar[1:]])


def _display(label):
    """Translates an item name but keeps a trailing "×2"."""
    bas, sep, antal = label.partition(" ×")
    bas = _mellanslag(bas)
    return language.word(SMZ3_DISPLAY.get(bas, bas)) + sep + antal


def smz3_missing(seed, name, medlemmar=None):
    """What is missing to reach an SMZ3 location?

        Like its ALTTP counterpart, we never send the location's CONTENTS -
        only what it takes to get there. The requirement is a property of the
        world, not of the seed.
    """
    rom = sav = None
    root = os.path.join(GAMES, "SNES", "SMZ3")
    try:
        for dp, _dn, fns in os.walk(root):
            for f in fns:
                if f.lower().endswith(".sfc") and f.rsplit("-", 1)[-1] \
                        .rsplit(".", 1)[0] == seed:
                    rom = os.path.join(dp, f)
                    sav = os.path.join(SAVES, "SNES",
                                       os.path.splitext(f)[0] + ".sav")
    except OSError:
        pass
    if not rom:
        return {"name": name, "fel": language.word("unknown seed")}
    # ⚠️ Live memory first, exactly as smz3_tracker does. The save file is only
    # written when the OSD opens, so a location emptied minutes ago still reads
    # as untouched here - and "what was in it" then stayed silent on a location
    # the map had already greyed out. The requirements themselves were equally
    # stale, just less visibly so.
    raw = []
    tagg = live_rom_tag()
    if tagg and rom_tag(rom) == tagg:
        raw = live_smz3_raw() or []
    if not raw:
        try:
            with open(sav, "rb") as f:
                raw = list(f.read())
        except OSError:
            raw = []
    slot = sm_slot(raw) if raw else None
    items = _smz3_items(raw, slot[0]) if slot else []
    prizes, medals, kand = _smz3_meta(rom)
    if not kand:
        return {"name": name,
                # One line on purpose: lang_check.py greps the source for
                # every key, and a string split across two lines cannot be
                # found even though Python joins it at runtime.
                "fel": language.word(
                    "the seed's .txt is missing - without it we know neither prizes nor medallions")}
    # Nara grupper slas ihop till "King Zora / Zora's Ledge". Logiken kanner
    # only the individual names, so try the parts separately.
    kandidater = [name] + [d.strip() for d in name.split(" / ")]
    d = {"okand": True}
    try:
        for kand in kandidater:
            body = json.dumps({
                "location": SMZ3_LOC_ALIAS.get(kand, kand), "items": items,
                "rewards": prizes, "medals": medals,
                "klara": _smz3_klara(raw, rom),
                "sm_lasta": _smz3_lasta(rom)}).encode()
            req = urllib.request.Request(
                SMZ3_REACH_URL.replace("/smz3reach", "/smz3missing"),
                data=body, headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=30) as r:
                d = json.loads(r.read().decode())
            if not d.get("okand"):
                break
    except Exception as e:                                     # noqa: BLE001
        return {"name": name, "fel": language.word("the logic service is not answering (%s)") % e}

    # ⚠️ A location locked by a reward must NOT be reported as reachable. The
    # test that decides the reward is what stands in the way is run with the
    # rewards counted as collectable, so it answers "reachable" - but only in that world.
    out = {"name": name,
           "nabar": bool(d.get("nabar")) and not d.get("belong")}

    def _tagen(n):
        """True/False/None - is this SMZ3 location emptied? None = cannot tell.

            Two exact readings, both per location: Metroid's item bitfield and
            Zelda's chest table. Anything else answers None.
        """
        lid = (SMLOCS.get(n) or (None, None))[0]
        if lid is not None:
            slot = sm_slot(raw)
            if not slot:
                return None
            off = slot[1] + (lid >> 3)
            return bool(off < len(raw) and raw[off] & (1 << (lid & 7)))
        return _smz3_chest(n, raw)

    hamtat = hamtat_lista(seed, medlemmar or [name], _tagen)
    if hamtat:
        out["hamtat"] = hamtat
    visad = spoiler_visad(seed, name)
    if visad:
        out["spoiler"] = _display(visad["item"])
        out["spoiler_plats"] = visad["plats"]
    if d.get("okand"):
        out["fel"] = language.word("this location is not in the logic")
    elif d.get("omojlig"):
        out["omojlig"] = True
    elif d.get("belong"):
        # Locked behind a reward that has not been collected yet - no items in the
        # world open it, you have to clear the dungeon that gives the crystal.
        out["belong"] = True
        if d.get("single"):
            out["nagot_av"] = d["single"]
        elif d.get("combo"):
            out["behover"] = d["combo"]
    elif d.get("single"):
        out["nagot_av"] = d["single"]
    elif d.get("combo"):
        out["behover"] = d["combo"]
    # {"Space Jump": ["Hi-Jump Boots", "Morph Ball Bombs"]} - what could have
    # stood in each slot of the combination. The minimisation gives ONE valid
    # set, and without this you can end up hunting for the wrong item.
    if d.get("alternativ") and out.get("behover"):
        out["alternativ"] = d["alternativ"]
    # Entirely different routes to the same location - found by asking the logic
    # "does it work without X?" for every item in the answer.
    if d.get("vagar") and out.get("behover"):
        out["vagar"] = d["vagar"]
    # Last of all: translate everything the player actually reads. The
    # alternatives are keyed on the same labels as "behover", so both sides must be included.
    if out.get("nagot_av"):
        out["nagot_av"] = [_display(x) for x in out["nagot_av"]]
    if out.get("behover"):
        out["behover"] = [_display(x) for x in out["behover"]]
    if out.get("alternativ"):
        out["alternativ"] = {_display(k): [_display(v) for v in vs]
                             for k, vs in out["alternativ"].items()}
    if out.get("vagar"):
        out["vagar"] = [[_display(x) for x in v] for v in out["vagar"]]
    return out


def smz3_tracker():
    """One entry per SMZ3 seed, the same shape as the ALTTPR tracker."""
    out = []
    root = os.path.join(GAMES, "SNES", "SMZ3")
    try:
        roms = [os.path.join(dp, f)
                for dp, _dn, fn in os.walk(root) for f in fn
                if f.lower().endswith(".sfc")]
    except OSError:
        roms = []
    for rom in sorted(roms):
        bas = os.path.splitext(os.path.basename(rom))[0]
        seed = bas.rsplit("-", 1)[-1]
        sav = os.path.join(SAVES, "SNES", bas + ".sav")
        raw, synced, live = [], 0, False
        # If THIS seed is running right now, live memory wins: the save file is
        # only written when the OSD is opened and is therefore nearly always older.
        tagg = live_rom_tag()
        if tagg and rom_tag(rom) == tagg:
            lev = live_smz3_raw()
            if lev:
                raw, synced, live = lev, time.time(), True
        if not raw:
            try:
                with open(sav, "rb") as f:
                    raw = list(f.read())
                synced = os.path.getmtime(sav)
            except OSError:
                pass
        out.append({"seed": seed, "name": bas, "live": live,
                    # ⚠️ Relative to the CORE's folder, not games/. launch()
                    # looks the SMZ3 group up -> the SNES core and assembles
                    # GAMES/SNES/<rom>; counting from GAMES put "SNES/" in
                    # twice and the file was never found. The same convention
                    # the ALTTPR tracker already follows.
                    "rom": os.path.relpath(rom, os.path.join(GAMES, "SNES")),
                    "started": bool(raw), "synced": synced,
                    "skin": _skin_for(os.path.relpath(
                        rom, os.path.join(GAMES, "SNES"))),
                    "spoilers": spoil_count(seed),
                    # Requires both halves. The Metroid side is not mapped
                    # yet, so "cleared" is always False for now -
                    # better that than a false tick. "zelda_klar" shows how
                    # far the Ganon side has come.
                    "klar": smz3_klar(raw) if raw else False,
                    "zelda_klar": zelda_klar(bytes(raw)) if raw else False,
                    "metroid": smz3_state(raw, rom) if raw else None})
    out.sort(key=lambda x: (0 if x["synced"] else 1, -x["synced"]))
    return out


def tracker():
    sig = _trk_sig()
    if _trk_cache[0] == sig and _trk_cache[1] is not None:
        return _trk_cache[1]
    out = _tracker_build()
    _trk_cache[0], _trk_cache[1] = sig, out
    return out


def _tracker_build():
    """One entry per ALTTPR SEED, not per save file.

        Seeds not started yet get an empty map - the positions are shared
        between all seeds, so the dots are drawn anyway, just none ticked off.
    """
    saves = {}
    try:
        for fn in os.listdir(os.path.join(SAVES, "SNES")):
            if fn.lower().endswith(".sav") and fn.lower().startswith("alttpr"):
                full = os.path.join(SAVES, "SNES", fn)
                d = read_save(full)
                if d and d.get("seed"):
                    saves[d["seed"]] = (d, fn)
    except OSError:
        pass

    with _lock:
        roms = list(_index.get("ALTTPR", []))
    out, seen = [], set()
    for rel in roms:
        # " (1)" is a duplicate download - the counter comes after the seed and
        # otherwise hid the whole seed from the tracker. The same artefact
        # _hor_till_seed() has to strip away when deleting.
        m = re.search(r"_([A-Za-z0-9]{6,})(?: \(\d+\))?\.sfc$", rel)
        seed = m.group(1) if m else ""
        if not seed or seed in seen:
            continue
        seen.add(seed)
        hit = saves.pop(seed, None)
        if hit:
            d, fn = hit
            d["name"] = os.path.splitext(fn)[0]
        else:
            # Ostartad: tom karta, men kistantalen kommer ur seedens spoiler
            d = {"seed": seed, "intact": True, "screens": 0, "rooms": 0,
                 "hearts": 0, "rupees": 0, "synced": 0, "started": False,
                 "ow_raw": [], "raw": [], "inv": {}, "visited": [],
                 "name": os.path.basename(rel)}
        d.setdefault("started", True)
        d["rom"] = rel
        d["skin"] = _skin_for(rel)
        # Logic for every STARTED seed - see the note at points(). A run you have
        # set aside must not lose its colours.
        d["fresh"] = bool(d.get("synced"))
        d["dungeons"] = dungeons(d["seed"], d.pop("visited", []),
                                 d.get("raw"), d.get("inv"), d["fresh"])
        d["points"] = points(d.pop("ow_raw", []), d["seed"],
                             d.pop("inv", {}), d.pop("raw", []), d["fresh"])
        d["spoilers"] = spoil_count(d["seed"])
        # Only the Light/Dark World doors - an ALTTPR seed has no Zebes.
        d["portals"] = _portaler(ZELDA_PORTALER)
        out.append(d)
    # started first, newest sync at the top; unstarted last
    out.sort(key=lambda x: (0 if x["synced"] else 1, -x["synced"]))
    return out


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        # The page can be served from HA (/local/mister.html) and then calls this
        # API from a different origin.
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj), "application/json; charset=utf-8")

    def do_GET(self):
        p = urllib.parse.urlparse(self.path)
        route = posixpath.normpath(p.path)
        if route in ("/", "/index.html"):
            return self._send(200, language.page("page", PAGE),
                              "text/html; charset=utf-8")
        if route in ("/seeds", "/seeds.html"):
            return self._send(200, language.page("seedpage", SEEDPAGE),
                              "text/html; charset=utf-8")
        if route == "/api/cores":
            with _lock:
                data = [{"id": k, "name": language.word(NAMES.get(k, k)), "count": len(v),
                         "icon": ICONS.get(k, "🎮"), "prefixes": [],
                         "small": len(v) < SMALL_CORE_MAX}
                        for k, v in _index.items() if v and k not in GROUPS]
            data.sort(key=lambda c: (CORE_ORDER.index(c["id"])
                                     if c["id"] in CORE_ORDER else 99,
                                     c["id"].lower()))
            return self._json(data)
        if route == "/api/games":
            q = urllib.parse.parse_qs(p.query)
            core = (q.get("core") or [""])[0]
            with _lock:
                return self._json(_index.get(core, []))
        if route == "/api/seedgroups":
            with _lock:
                snapshot = {g: list(_index.get(g, [])) for g in GROUPS}
            data = []
            for g, paths in snapshot.items():
                parent = GROUPS[g][0]
                seeds = []
                for rel in paths:
                    full = os.path.join(GAMES, parent, rel)
                    try:
                        mtime = os.path.getmtime(full)
                    except OSError:
                        mtime = 0
                    # The date is taken from the folder name where there is one, otherwise
                    # from the file's timestamp - so old seeds get a date too.
                    date = ""
                    for part in rel.replace(os.sep, "/").split("/"):
                        if len(part) == 10 and part[4] == "-" and part[7] == "-":
                            date = part
                            break
                    if not date:
                        date = time.strftime("%Y-%m-%d", time.localtime(mtime))
                    seeds.append({"path": rel, "date": date, "mtime": mtime})
                # Nyast overst, alltid.
                seeds.sort(key=lambda x: x["mtime"], reverse=True)
                data.append({"id": g, "name": language.word(NAMES.get(g, g)),
                             "icon": ICONS.get(g, "🎲"),
                             "gen": GROUP_GEN.get(g, ""),
                             "count": len(seeds), "games": seeds})
            return self._json(data)
        if route in ("/annotate", "/annotate.html"):
            return self._send(200, language.page("annotatepage", ANNOTATE),
                              "text/html; charset=utf-8")
        if route == "/api/smz3":
            return self._json(smz3_tracker())
        if route == "/api/tracker":
            return self._json(tracker())
        if route == "/api/locations":
            return self._json(locations())
        if route == "/api/dungeon":
            q = urllib.parse.parse_qs(p.query)
            sd = (q.get("seed") or [""])[0]
            return self._json(dungeon_chests(
                sd, (q.get("name") or [""])[0], None,
                _inv_for_seed(sd), _prizes_for_seed(sd)))
        if route == "/api/missing":
            q = urllib.parse.parse_qs(p.query)
            # "members" lists the locations under one map dot, so a group that
            # is fully emptied can show all of them and not just the first.
            med = [x for x in ((q.get("members") or [""])[0]).split("|") if x]
            return self._json(missing_for((q.get("seed") or [""])[0],
                                          (q.get("name") or [""])[0], med))
        if route == "/api/spritesheet":
            # samus.links egen remsa, 16x24 per ruta. Sparad lokalt av
            # the generator, so the card works without internet access.
            try:
                with open(os.path.join(os.path.dirname(
                        os.path.abspath(__file__)), "sprites-sm.png"), "rb") as f:
                    png = f.read()
            except OSError:
                return self._json({"error": "ingen sheet"}, 404)
            self.send_response(200)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Length", str(len(png)))
            self.send_header("Cache-Control", "max-age=86400")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(png)
            return
        if route == "/api/skin":
            q = urllib.parse.parse_qs(p.query)
            sd = (q.get("seed") or [""])[0]
            # which=samus -> seedens egen utklippta Samus-bild. Ingen
            # default image to fall back on: if the file is missing the card should
            # use the strip, and skin.samus_file is what decides that.
            if (q.get("which") or [""])[0] == "samus":
                png = samus_png(sd)
            else:
                png = skin_png(sd)
            if not png:
                return self._json({"error": "ingen bild"}, 404)
            self.send_response(200)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Length", str(len(png)))
            self.send_header("Cache-Control", "max-age=86400")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(png)
            return
        if route == "/api/smz3missing":
            q = urllib.parse.parse_qs(p.query)
            med = [x for x in ((q.get("members") or [""])[0]).split("|") if x]
            return self._json(smz3_missing((q.get("seed") or [""])[0],
                                           (q.get("name") or [""])[0], med))
        if route == "/api/seedfiles":
            sd = (urllib.parse.parse_qs(p.query).get("seed") or [""])[0]
            return self._json({"files": [os.path.basename(f)
                                         for f in seed_files(sd)]})
        if route == "/api/spoilernames":
            # Step 1: names ONLY, never the answer. You should be able to search
            # without spoiling yourself - the reveal happens in step 2, with a
            # confirmation, and only then is it recorded.
            q = urllib.parse.parse_qs(p.query)
            seed = (q.get("seed") or [""])[0]
            mode = (q.get("mode") or ["item"])[0]
            term = (q.get("q") or [""])[0].strip()
            if mode not in ("item", "plats"):
                return self._json({"namn": [], "message": "okant lage"}, 400)
            if len(term.replace("*", "").strip()) < 3:
                return self._json({"namn": [], "total": 0,
                                   "count": spoil_count(seed),
                                   "message": "minst 3 tecken"})
            return self._json(spoiler_namn(seed, mode, term))
        if route == "/api/spoilerlog":
            seed = (urllib.parse.parse_qs(p.query).get("seed") or [""])[0]
            return self._json(spoiler_logg(seed))
        if route == "/api/spoilercount":
            seed = (urllib.parse.parse_qs(p.query).get("seed") or [""])[0]
            return self._json({"count": spoil_count(seed)})
        if route == "/api/regions":
            return self._json({"regions": region_names(),
                               "reqs": _load_regions(),
                               "items": [{"id": i[0], "name": i[1]}
                                         for i in LOGIC_ITEMS]})
        if route == "/api/rewards":
            return self._json(REWARDS)
        if route == "/api/status":
            def read(path):
                try:
                    with open(path) as f:
                        return f.read().strip()
                except OSError:
                    return ""
            core = read("/tmp/CORENAME") or "MENU"
            return self._json({"core": core, "name": language.word(NAMES.get(core, core))})
        if route == "/api/genstatus":
            with _lock:
                return self._json(dict(_gen, last=dict(_gen_last)))
        if route == "/api/rescan":
            n = scan()
            return self._json({"ok": True, "message": "%d spel indexerade" % n})
        self._json({"ok": False, "message": "not found"}, 404)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Length", "0")
        self.end_headers()

    def do_POST(self):
        route = posixpath.normpath(urllib.parse.urlparse(self.path).path)
        if route == "/api/annotate":
            try:
                n = int(self.headers.get("Content-Length", 0))
                req = json.loads(self.rfile.read(n) or b"{}")
            except (ValueError, TypeError):
                return self._json({"ok": False, "message": language.word("malformed request")}, 400)
            region, name = req.get("region", ""), req.get("name", "")
            if not region or not name:
                return self._json({"ok": False, "message": "saknar plats"}, 400)
            pos = req.get("pos")
            if pos is not None:
                try:
                    pos = {"world": str(pos["world"])[:2],
                           "x": round(float(pos["x"]), 5),
                           "y": round(float(pos["y"]), 5)}
                except (KeyError, TypeError, ValueError):
                    return self._json({"ok": False, "message": "trasig position"}, 400)
                if not (0 <= pos["x"] <= 1 and 0 <= pos["y"] <= 1):
                    return self._json({"ok": False, "message": "utanfor kartan"}, 400)
            return self._json({"ok": True, "count": annotate(region, name, pos)})
        if route == "/api/delete_seed":
            try:
                n = int(self.headers.get("Content-Length", 0))
                sd = json.loads(self.rfile.read(n) or b"{}").get("seed", "")
            except (ValueError, TypeError):
                return self._json({"ok": False, "message": language.word("malformed request")}, 400)
            if not sd:
                return self._json({"ok": False, "message": "saknar seed"}, 400)
            gone = delete_seed(sd)
            scan()
            return self._json({"ok": True, "deleted": gone,
                               "message": "%d filer borttagna" % len(gone)})
        if route == "/api/spoilerreveal":
            # Step 2: the player has confirmed. Now - and only now - the answer leaves
            # the server, and the lookup is recorded.
            try:
                n = int(self.headers.get("Content-Length", 0))
                req = json.loads(self.rfile.read(n) or b"{}")
            except (ValueError, TypeError):
                return self._json({"ok": False, "message": language.word("malformed request")}, 400)
            seed = req.get("seed", "")
            mode = req.get("mode", "")
            namn = req.get("namn", "")
            if not seed or mode not in ("item", "plats") or not namn:
                return self._json({"ok": False, "message": "ofullstandigt val"}, 400)
            return self._json(spoiler_avsloja(seed, mode, namn))
        if route == "/api/medallion":
            try:
                n = int(self.headers.get("Content-Length", 0))
                req = json.loads(self.rfile.read(n) or b"{}")
            except (ValueError, TypeError):
                return self._json({"ok": False, "message": language.word("malformed request")}, 400)
            seed = req.get("seed", "")
            dung = req.get("dungeon", "")
            val = req.get("value", "") or ""
            if not seed or dung not in ("tr", "mm"):
                return self._json({"ok": False, "message": "okand dungeon"}, 400)
            if val and val not in MEDALS:
                return self._json({"ok": False, "message": "okand medaljong"}, 400)
            n = set_medallion(seed, dung, val)
            return self._json({"ok": True, "count": n})
        if route == "/api/region":
            try:
                n = int(self.headers.get("Content-Length", 0))
                req = json.loads(self.rfile.read(n) or b"{}")
            except (ValueError, TypeError):
                return self._json({"ok": False, "message": language.word("malformed request")}, 400)
            name = req.get("name", "")
            if not name:
                return self._json({"ok": False, "message": "saknar region"}, 400)
            bad = [i for i in (req.get("all") or []) + (req.get("any") or [])
                   if i not in LOGIC_BY_ID]
            if bad:
                return self._json({"ok": False,
                                   "message": "okant foremal: %s" % bad[0]}, 400)
            n = set_region(name, req.get("all") or [], req.get("any") or [])
            return self._json({"ok": True, "count": n})
        if route == "/api/logic":
            try:
                n = int(self.headers.get("Content-Length", 0))
                req = json.loads(self.rfile.read(n) or b"{}")
            except (ValueError, TypeError):
                return self._json({"ok": False, "message": language.word("malformed request")}, 400)
            region, name = req.get("region", ""), req.get("name", "")
            if not region or not name:
                return self._json({"ok": False, "message": "saknar plats"}, 400)
            bad = [i for i in (req.get("all") or []) + (req.get("any") or [])
                   if i not in LOGIC_BY_ID]
            if bad:
                return self._json({"ok": False,
                                   "message": "okant foremal: %s" % bad[0]}, 400)
            n = set_logic(region, name, req.get("all") or [],
                          req.get("any") or [])
            return self._json({"ok": True, "count": n})
        if route == "/api/check":
            try:
                n = int(self.headers.get("Content-Length", 0))
                req = json.loads(self.rfile.read(n) or b"{}")
            except (ValueError, TypeError):
                return self._json({"ok": False, "message": language.word("malformed request")}, 400)
            seed = req.get("seed", "")
            region, name = req.get("region", ""), req.get("name", "")
            if not seed or not region or not name:
                return self._json({"ok": False, "message": "saknar plats"}, 400)
            n = set_check(seed, region, name, bool(req.get("open")))
            return self._json({"ok": True, "count": n})
        if route == "/api/progress":
            try:
                n = int(self.headers.get("Content-Length", 0))
                req = json.loads(self.rfile.read(n) or b"{}")
            except (ValueError, TypeError):
                return self._json({"ok": False, "message": language.word("malformed request")}, 400)
            seed, dung = req.get("seed", ""), req.get("dungeon", "")
            if not seed or dung not in DUNGEONS:
                return self._json({"ok": False, "message": "okand dungeon"}, 400)
            reward = req.get("reward", "") or ""
            if reward and reward not in REWARDS:
                return self._json({"ok": False, "message": "okand beloning"}, 400)
            f = req.get("found")
            n = set_progress(seed, dung, req.get("boss"), reward,
                             None if f is None else max(0, int(f)))
            return self._json({"ok": True, "count": n})
        if route == "/api/generate":
            try:
                n = int(self.headers.get("Content-Length", 0))
                kind = json.loads(self.rfile.read(n) or b"{}").get("kind", "")
            except (ValueError, TypeError):
                return self._json({"ok": False, "message": language.word("malformed request")}, 400)
            if kind not in GENERATORS:
                return self._json({"ok": False, "message": language.word("unknown generator")}, 400)
            ok, msg = run_generator(kind)
            return self._json({"ok": ok, "message": msg}, 200 if ok else 409)
        if route == "/api/menu":
            ok, msg = to_menu()
            return self._json({"ok": ok, "message": msg}, 200 if ok else 400)
        if route != "/api/launch":
            return self._json({"ok": False, "message": "not found"}, 404)
        try:
            n = int(self.headers.get("Content-Length", 0))
            req = json.loads(self.rfile.read(n) or b"{}")
        except (ValueError, TypeError):
            return self._json({"ok": False, "message": language.word("malformed request")}, 400)
        core = req.get("core", "")
        path = req.get("path", "")
        # Stop anyone escaping out of the games folder.
        if not path or path.startswith("/") or ".." in path.split("/"):
            return self._json({"ok": False, "message": language.word("invalid path")}, 400)
        ok, msg = launch(core, path)
        self._json({"ok": ok, "message": msg}, 200 if ok else 400)


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


def rescan_loop(minutes=15):
    """Re-indexes at regular intervals. The NAS share with disc images is
        filled by an ongoing download, and the index used to be built only once
        at start - new games then never appeared without a restart.
    """
    while True:
        time.sleep(minutes * 60)
        try:
            scan()
        except OSError as e:
            print("omindexering misslyckades: %s" % e, flush=True)


if __name__ == "__main__":
    total = scan()
    print("MiSTer-spelserver: %d spel i %d cores, lyssnar pa port %d"
          % (total, len(_index), PORT), flush=True)
    threading.Thread(target=rescan_loop, daemon=True).start()
    Server(("0.0.0.0", PORT), Handler).serve_forever()
