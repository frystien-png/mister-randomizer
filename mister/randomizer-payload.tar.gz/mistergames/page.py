"""HTML/CSS/JS for the game browser.

The page is served both by the MiSTer itself (relative API calls) and by
Home Assistant from /config/www/ (absolute API URL via window.MISTER_API).
In the second case the page survives the MiSTer being switched off, and can
then show a sensible offline state instead of the browser's connection
error.
"""

PAGE = r"""<!doctype html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>MiSTer</title>
<style>
:root{--bg:#12141a;--card:#1c2029;--card2:#232833;--fg:#e8eaf0;--dim:#8b93a7;
--accent:#5b9dff;--ok:#3ddc84;--line:#2c313d}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;background:var(--bg);color:var(--fg);
font:16px/1.4 system-ui,-apple-system,"Segoe UI",sans-serif;overscroll-behavior:none}
header{position:sticky;top:0;z-index:5;background:rgba(18,20,26,.96);
backdrop-filter:blur(8px);border-bottom:1px solid var(--line);
padding:env(safe-area-inset-top) 0 0}
.bar{display:flex;align-items:center;gap:10px;padding:12px 14px}
.back{background:var(--card2);border:0;color:var(--fg);font-size:20px;
width:44px;height:44px;border-radius:12px;flex:0 0 auto;display:none}
h1{font-size:18px;margin:0;font-weight:600;flex:1;
overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.count{color:var(--dim);font-size:13px;flex:0 0 auto}
.now{display:none;align-items:center;gap:7px;background:var(--card);
border:1px solid var(--line);border-radius:99px;padding:5px 12px 5px 9px;
font-size:12.5px;color:var(--dim);flex:0 0 auto;max-width:44vw}
.now.show{display:inline-flex}
.now b{color:var(--fg);font-weight:600;overflow:hidden;
text-overflow:ellipsis;white-space:nowrap}
.now i{width:7px;height:7px;border-radius:50%;background:var(--ok);
flex:0 0 auto;animation:pulse 2.2s ease-in-out infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
li .tag{color:#5d6478}
input{width:100%;padding:13px 14px;font-size:16px;border-radius:12px;
border:1px solid var(--line);background:var(--card);color:var(--fg)}
.search{padding:0 14px 12px;display:none}
main{padding:12px 14px calc(28px + env(safe-area-inset-bottom))}
.cores{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px}
.core{background:var(--card);border:1px solid var(--line);border-radius:16px;
padding:20px 16px;text-align:center;cursor:pointer}
.core:active{background:var(--card2)}
.core .ic{font-size:34px;line-height:1}
.core .nm{margin-top:8px;font-weight:600;font-size:14.5px;line-height:1.25;
hyphens:auto}
.core .ct{color:var(--dim);font-size:13px;margin-top:2px}
ul{list-style:none;margin:0;padding:0}
li{background:var(--card);border:1px solid var(--line);border-radius:12px;
padding:15px 14px;margin-bottom:8px;cursor:pointer;
overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
li:active{background:var(--card2);border-color:var(--accent)}
li .sub{display:block;color:var(--dim);font-size:12px;margin-top:3px}
.toast{position:fixed;left:50%;bottom:calc(24px + env(safe-area-inset-bottom));
transform:translateX(-50%) translateY(80px);background:var(--ok);color:#06240f;
padding:13px 22px;border-radius:99px;font-weight:600;opacity:0;
transition:.25s;pointer-events:none;max-width:90vw;z-index:20}
.toast.show{transform:translateX(-50%);opacity:1}
.toast.err{background:#ff6b6b;color:#2a0000}
.empty{color:var(--dim);text-align:center;padding:40px 0}
.gen{margin-top:22px;border-top:1px solid var(--line);padding-top:18px}
.gen h2{font-size:13px;color:var(--dim);margin:0 0 10px;font-weight:600;
letter-spacing:.06em;text-transform:uppercase}
.genrow{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.gb{background:var(--card);border:1px solid var(--accent);color:var(--accent);
border-radius:14px;padding:16px 12px;font:600 15px system-ui;cursor:pointer}
.gb:active{background:var(--card2)}
.gb:disabled{opacity:.45;border-color:var(--line);color:var(--dim);cursor:default}

/* --- offline state --- */
.off{position:fixed;inset:0;background:var(--bg);display:none;
flex-direction:column;align-items:center;justify-content:center;
text-align:center;padding:32px;z-index:50}
.off.show{display:flex}
.off h2{font-size:22px;margin:26px 0 10px;font-weight:600}
.off p{color:var(--dim);margin:0 0 26px;max-width:32ch;line-height:1.55}
.off button{background:var(--accent);border:0;color:#04122b;
font:600 16px system-ui;padding:14px 28px;border-radius:99px;cursor:pointer}
.off .hint{font-size:13px;color:#5d6478;margin-top:18px}
@keyframes blink{0%,45%{opacity:1}55%,100%{opacity:.15}}
@keyframes float{0%{transform:translateY(0) scale(.8);opacity:0}
25%{opacity:.9}100%{transform:translateY(-26px) scale(1.15);opacity:0}}
@keyframes sway{0%,100%{transform:rotate(-2deg)}50%{transform:rotate(2deg)}}
#led{animation:blink 1.6s ease-in-out infinite}
#box{animation:sway 4.5s ease-in-out infinite;transform-origin:50% 90%}
.z1{animation:float 2.8s ease-out infinite}
.z2{animation:float 2.8s ease-out .9s infinite}
.z3{animation:float 2.8s ease-out 1.8s infinite}

/* --- direct mode: skips the save warning. Only shown while a game runs. --- */
.tgl{display:none;align-items:center;gap:7px;background:var(--card);
border:1px solid var(--line);border-radius:99px;padding:5px 11px 5px 9px;
font-size:12.5px;color:var(--dim);flex:0 0 auto;cursor:pointer;
user-select:none;-webkit-user-select:none}
.tgl.show{display:inline-flex}
.tgl i{width:26px;height:15px;border-radius:99px;background:var(--card2);
border:1px solid var(--line);position:relative;flex:0 0 auto;
transition:background .15s,border-color .15s}
.tgl i::after{content:"";position:absolute;top:1px;left:1px;
width:11px;height:11px;border-radius:50%;background:var(--dim);
transition:transform .15s,background .15s}
.tgl.on{color:var(--accent);border-color:var(--accent)}
.tgl.on i{background:rgba(91,157,255,.25);border-color:var(--accent)}
.tgl.on i::after{transform:translateX(11px);background:var(--accent)}

/* --- back to the MiSTer menu. Same pill shape as the toggle next to it,
   and shown under the same condition: only while a core is loaded, because
   there is nothing to unload otherwise. --- */
.menu{display:none;align-items:center;gap:5px;background:var(--card);
border:1px solid var(--line);border-radius:99px;padding:6px 12px;
font:600 12.5px system-ui;color:var(--dim);flex:0 0 auto;cursor:pointer;
white-space:nowrap}
.menu.show{display:inline-flex}
.menu:active{background:var(--card2);color:var(--fg)}

/* --- save warning before switching core --- */
.ask{position:fixed;inset:0;background:rgba(10,11,15,.72);display:none;
align-items:center;justify-content:center;padding:24px;z-index:60}
.ask.show{display:flex}
.ask .box{background:var(--card);border:1px solid var(--line);
border-radius:18px;padding:22px;width:100%;max-width:36ch}
.ask h2{margin:0 0 10px;font-size:17px;font-weight:600}
.ask p{margin:0 0 20px;color:var(--dim);font-size:14px;line-height:1.55}
.ask .row{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.ask button{border:0;border-radius:12px;padding:13px 10px;
font:600 15px system-ui;cursor:pointer}
.ask .no{background:var(--card2);color:var(--fg)}
.ask .yes{background:var(--accent);color:#04122b}
</style>
<header>
  <div class="bar">
    <button class="back" id="back">&lsaquo;</button>
    <h1 id="title">MiSTer</h1>
    <span class="now" id="now"><i></i><b></b></span>
    <span class="tgl" id="tgl" title="Switch games without a save warning"><i></i>Direct</span>
    <button class="menu" id="menu" title="Unload the game and return to the MiSTer menu">⏏ Menu</button>
    <span class="count" id="count"></span>
  </div>
  <div class="search" id="searchwrap">
    <input id="q" placeholder="Search games…" autocomplete="off"
           autocorrect="off" autocapitalize="off" spellcheck="false">
  </div>
</header>
<main id="main"></main>
<div class="toast" id="toast"></div>

<div class="ask" id="ask">
  <div class="box">
    <h2>Save in the game first</h2>
    <p>The MiSTer keeps your progress in memory and only writes it to the card when you open the OSD menu. Save where you are, open and close the OSD, then come back — otherwise everything since your last save is gone.</p>
    <div class="row">
      <button class="no" id="askno">Cancel</button>
      <button class="yes" id="askyes">Continue anyway</button>
    </div>
  </div>
</div>

<div class="off" id="off">
  <svg width="190" height="150" viewBox="0 0 190 150" aria-hidden="true">
    <g class="z1"><text x="132" y="52" fill="#5b9dff" font-size="17"
       font-family="system-ui" font-weight="700">z</text></g>
    <g class="z2"><text x="146" y="42" fill="#5b9dff" font-size="21"
       font-family="system-ui" font-weight="700">z</text></g>
    <g class="z3"><text x="160" y="32" fill="#5b9dff" font-size="26"
       font-family="system-ui" font-weight="700">z</text></g>
    <g id="box">
      <rect x="26" y="62" width="118" height="62" rx="9"
            fill="#1c2029" stroke="#2c313d" stroke-width="2.5"/>
      <rect x="38" y="76" width="58" height="34" rx="5" fill="#12141a"/>
      <rect x="45" y="83" width="30" height="3.5" rx="1.75" fill="#2c313d"/>
      <rect x="45" y="92" width="44" height="3.5" rx="1.75" fill="#2c313d"/>
      <rect x="45" y="101" width="22" height="3.5" rx="1.75" fill="#2c313d"/>
      <circle id="led" cx="122" cy="93" r="7" fill="#ff6b6b"/>
      <rect x="52" y="124" width="66" height="7" rx="3.5" fill="#232833"/>
    </g>
  </svg>
  <h2>No contact with the MiSTer</h2>
  <p>Make sure the MiSTer FPGA is powered on and connected to the network.</p>
  <button id="retry">Try again</button>
  <div class="hint" id="hint">Retrying automatically every five seconds…</div>
</div>

<script>
const API=window.MISTER_API||'';
const M=document.getElementById('main'),T=document.getElementById('title'),
C=document.getElementById('count'),B=document.getElementById('back'),
S=document.getElementById('searchwrap'),Q=document.getElementById('q'),
TO=document.getElementById('toast'),OFF=document.getElementById('off');
let cores=[],cur=null,curPrefixes=[],games=[],offline=false,
retryTimer=null,poll=null,nowTimer=null;

function toast(msg,err){TO.textContent=msg;TO.className='toast show'+(err?' err':'');
  clearTimeout(TO._t);TO._t=setTimeout(()=>TO.className='toast',2600);}

/* Every API call goes through this one - if we lose contact the offline
   screen is shown instead of the page simply going dead. */
async function api(path,opts){
  try{
    const r=await fetch(API+path,Object.assign({cache:'no-store'},opts||{}));
    if(!r.ok&&r.status>=500)throw new Error('HTTP '+r.status);
    goneOnline();
    return r;
  }catch(e){goneOffline();throw e;}
}
function goneOffline(){
  if(offline)return;offline=true;OFF.classList.add('show');
  clearInterval(retryTimer);retryTimer=setInterval(ping,5000);
}
function goneOnline(){
  if(!offline)return;offline=false;OFF.classList.remove('show');
  clearInterval(retryTimer);retryTimer=null;
}
async function ping(){
  try{
    const r=await fetch(API+'api/cores',{cache:'no-store'});
    if(r.ok){goneOnline();showCores();}
  }catch(e){}
}
document.getElementById('retry').onclick=()=>{
  document.getElementById('hint').textContent='Trying…';ping();
  setTimeout(()=>document.getElementById('hint').textContent=
    'Retrying automatically every five seconds…',1500);
};

function tile(icon,name,sub,id){
  return `<div class="core" data-c="${id}"><div class="ic">${icon}</div>
     <div class="nm">${esc(name)}</div>
     <div class="ct">${sub}</div></div>`;
}
function bindTiles(fn){
  M.querySelectorAll('.core').forEach(e=>e.onclick=()=>fn(e.dataset.c));
}
const isSmall=c=>c.small;

/* The systems with only a handful of games - the home computers and the
   half-empty cores - would otherwise fill half the start page with ones
   and twos. They are collected behind the "Other" tile. The threshold is
   SMALL_CORE_MAX in server.py. */
async function showCores(){
  cur=null;B.style.display='none';S.style.display='none';T.textContent='MiSTer';
  let r;try{r=await api('api/cores')}catch(e){return}
  cores=await r.json();
  C.textContent=cores.reduce((a,c)=>a+c.count,0)+' games';
  const small=cores.filter(isSmall);
  let h=cores.filter(c=>!isSmall(c)).map(c=>tile(c.icon,c.name||c.id,c.count+' games',c.id)).join('');
  if(small.length)h+=tile('🧰','Other',small.length+' systems','__misc');
  M.innerHTML='<div class="cores">'+h+'</div>';
  bindTiles(id=>id==='__misc'?showSmall(true):showGames(id));
  history.replaceState({v:'cores'},'');
}

function showSmall(push){
  cur=null;B.style.display='block';S.style.display='none';T.textContent='Other';
  const small=cores.filter(isSmall);
  C.textContent=small.reduce((a,c)=>a+c.count,0)+' games';
  M.innerHTML='<div class="cores">'+
    small.map(c=>tile(c.icon,c.name||c.id,c.count+' games',c.id)).join('')+'</div>';
  bindTiles(showGames);
  if(push){history.pushState({v:'small'},'');window.scrollTo(0,0);}
}

async function showGames(id,push){
  const meta=cores.find(c=>c.id===id)||{};
  cur=id;curPrefixes=meta.prefixes||[];B.style.display='block';S.style.display='block';
  T.textContent=meta.name||id;
  M.innerHTML='<div class="empty">Loading…</div>';
  let r;try{r=await api('api/games?core='+encodeURIComponent(id))}catch(e){return}
  games=await r.json();Q.value='';render('');
  if(push!==false){history.pushState({v:'games',id},'');window.scrollTo(0,0);}
}

/* "Super Mario World (U) [!]" -> name emphasised, tags dimmed. */
function pretty(name){
  return esc(name).replace(/(\s*[\(\[][^\)\]]*[\)\]])+\s*$/,
    m=>'<span class="tag">'+m+'</span>');
}
/* The subfolder is shown without the group's own prefix -
   "ALTTPR/2026-08-06" becomes just "2026-08-06". */
function shortDir(dir){
  for(const p of (curPrefixes||[])){
    const t=p.replace(/\/$/,'');
    if(dir===t)return '';
    if(dir.startsWith(t+'/'))return dir.slice(t.length+1);
  }
  return dir;
}

function render(f){
  const n=f.toLowerCase().split(/\s+/).filter(Boolean);
  const list=games.filter(g=>{const l=g.toLowerCase();return n.every(t=>l.includes(t))});
  C.textContent=list.length+' games';
  if(!list.length){M.innerHTML='<div class="empty">No matches</div>';return;}
  M.innerHTML='<ul>'+list.slice(0,900).map(g=>{
    const i=g.lastIndexOf('/');
    const nm=(i<0?g:g.slice(i+1)).replace(/\.[^.]+$/,'');
    const dir=i<0?'':g.slice(0,i);
    const sd=shortDir(dir);
    return `<li data-p="${encodeURIComponent(g)}">${pretty(nm)}`+
           (sd?`<span class="sub">${esc(sd)}</span>`:'')+`</li>`;}).join('')+'</ul>'+
    (list.length>900?'<div class="empty">Showing 900 of '+list.length+' – search to narrow it down</div>':'');
  M.querySelectorAll('li').forEach(e=>e.onclick=()=>go(decodeURIComponent(e.dataset.p)));
}
function esc(s){return String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}

/* Save memory stays inside the FPGA until the OSD is opened - switching
   core mid-game therefore throws away everything unsaved. So we ask first.
   The "Direct" toggle skips the question and resets on every reload. */
const TGL=document.getElementById('tgl'),ASK=document.getElementById('ask'),
      MENUBTN=document.getElementById('menu');
/* pending ar en FUNKTION, inte en sokvag: samma varningsruta grindar bade
   "starta spel" och "tillbaka till menyn", och da racker inte en strang. */
let skipWarn=false,liveCore=null,pending=null;
TGL.onclick=()=>{skipWarn=!skipWarn;TGL.classList.toggle('on',skipWarn);
  toast(skipWarn?'Direct mode: switches without warning':'Warns before switching games')};
document.getElementById('askno').onclick=()=>{
  ASK.classList.remove('show');pending=null};
document.getElementById('askyes').onclick=()=>{
  ASK.classList.remove('show');const p=pending;pending=null;if(p)p()};

/* Samma grind for allt som slanger den korande coren. */
const JA=document.getElementById('askyes');
function bekrafta(gor,jaText){
  if(liveCore&&!skipWarn){
    pending=gor;JA.textContent=jaText;ASK.classList.add('show');return}
  gor();
}
async function go(path){bekrafta(()=>launch(path),'Switch game anyway')}
MENUBTN.onclick=()=>bekrafta(toMenu,'Go to the menu anyway');

async function toMenu(){
  toast('Returning to the menu…');
  try{
    const r=await api('api/menu',{method:'POST'});
    const d=await r.json();toast(d.message,!d.ok);
    if(d.ok)updateNow();          /* pillret och knappen ska forsvinna direkt */
  }catch(e){}
}
async function launch(path){
  toast('Starting…');
  try{
    const r=await api('api/launch',{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({core:cur,path:path})});
    const d=await r.json();toast(d.message,!d.ok);
  }catch(e){}
}

function setBusy(b){document.querySelectorAll('.gb').forEach(e=>e.disabled=b)}
async function generate(kind){
  setBusy(true);
  toast(kind==='smz3'?'Generating SMZ3, this takes a while…':'Generating ALTTPR…');
  try{
    const r=await api('api/generate',{method:'POST',
      headers:{'Content-Type':'application/json'},body:JSON.stringify({kind})});
    const d=await r.json();
    if(!d.ok){setBusy(false);return toast(d.message,true)}
    clearInterval(poll);poll=setInterval(checkGen,2500);
  }catch(e){setBusy(false)}
}
async function checkGen(){
  let d;try{d=await(await api('api/genstatus')).json()}catch(e){return}
  if(d.running){setBusy(true);return}
  setBusy(false);
  if(poll){clearInterval(poll);poll=null;
    if(d.done)toast(d.message,!d.ok);
    if(d.ok&&!cur)showCores();}
}

/* Shows which core the MiSTer is running, so you can see a tap landed. */
const NOW=document.getElementById('now');
async function updateNow(){
  try{
    const d=await(await fetch(API+'api/status',{cache:'no-store'})).json();
    if(d.core&&d.core!=='MENU'){NOW.querySelector('b').textContent=d.name||d.core;
      NOW.classList.add('show');liveCore=d.core;TGL.classList.add('show');
      MENUBTN.classList.add('show');}
    else{NOW.classList.remove('show');liveCore=null;TGL.classList.remove('show');
      MENUBTN.classList.remove('show');}
  }catch(e){NOW.classList.remove('show');liveCore=null;
    TGL.classList.remove('show');MENUBTN.classList.remove('show');}
}
updateNow();nowTimer=setInterval(updateNow,6000);

Q.addEventListener('input',()=>render(Q.value));
B.onclick=()=>history.back();
window.onpopstate=e=>{const s=e.state;
  if(!s||s.v==='cores')showCores();
  else if(s.v==='small')showSmall(false);
  else showGames(s.id,false)};
showCores();
</script>
"""

# >>> distributed with mister-randomizer >>>
# The stamp is added by build_payload.sh. The installer only overwrites a
# page.py that carries this line; a file without it is your own and is left
# untouched. Remove the line and your changes stop being overwritten.
