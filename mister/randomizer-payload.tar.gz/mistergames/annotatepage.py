# A one-off tool: you mark where on the map each location in the spoiler
# log sits, so the tracker can show real dots instead of an abstract 8x8
# grid. It NEVER shows what is at a location - only the name.
#
# Served from the MiSTer (port 8182) rather than through HA, so we avoid
# HA's 31-day cache while iterating.

ANNOTATE = r"""<!doctype html>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Mark locations</title>
<style>
:root{--bg:#12141a;--card:#1c2029;--card2:#232833;--fg:#e8eaf0;--dim:#8b93a7;
--accent:#5b9dff;--ok:#3ddc84;--line:#2c313d}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;background:var(--bg);color:var(--fg);
font:16px/1.4 system-ui,-apple-system,"Segoe UI",sans-serif;
overscroll-behavior:none;padding-bottom:env(safe-area-inset-bottom)}
header{position:sticky;top:0;z-index:5;background:rgba(18,20,26,.97);
backdrop-filter:blur(8px);border-bottom:1px solid var(--line);
padding:env(safe-area-inset-top) 14px 12px}
.prog{font-size:12px;color:var(--dim);padding-top:12px}
.bar{height:4px;background:var(--card2);border-radius:99px;margin:7px 0 12px}
.bar i{display:block;height:100%;background:var(--accent);border-radius:99px;
transition:width .2s}
h1{font-size:19px;margin:0;font-weight:600;line-height:1.25}
.reg{font-size:12px;color:var(--accent);font-weight:600;
letter-spacing:.05em;text-transform:uppercase;margin-bottom:3px}
main{padding:14px}
.worlds{display:flex;gap:8px;margin-bottom:12px;align-items:center}
/* Metroid locations carry their map in the data - the name is then shown
   instead of buttons, since there is no choice to make. */
.kartnamn{flex:1;text-align:center;font:600 13px system-ui;
color:var(--accent);padding:9px}
.worlds button{flex:1;background:var(--card);border:1px solid var(--line);
color:var(--dim);border-radius:99px;padding:9px;font:600 13px system-ui}
.worlds button.on{border-color:var(--accent);color:var(--accent);
background:rgba(91,157,255,.1)}
.wrap{position:relative;border-radius:12px;overflow:hidden;
border:1px solid var(--line);touch-action:manipulation}
.wrap img{display:block;width:100%;height:auto}
.dot{position:absolute;width:14px;height:14px;margin:-7px 0 0 -7px;
border-radius:50%;background:var(--accent);border:2px solid #fff;
box-shadow:0 0 0 2px rgba(0,0,0,.5);pointer-events:none}
.dot.old{width:8px;height:8px;margin:-4px 0 0 -4px;background:var(--ok);
border-width:1px;opacity:.75}
.hint{color:var(--dim);font-size:13px;margin:12px 0;line-height:1.5;
text-align:center}
.row{display:grid;grid-template-columns:1fr 1fr 1fr;gap:9px;margin-top:12px}
.row button{border:0;border-radius:12px;padding:14px 8px;
font:600 14px system-ui;background:var(--card2);color:var(--fg)}
.row .skip{color:var(--dim)}
.row .save{background:var(--accent);color:#04122b}
.row button:disabled{opacity:.4}
.done{text-align:center;padding:50px 20px;color:var(--dim);line-height:1.6}
.done b{display:block;color:var(--fg);font-size:20px;margin-bottom:10px}
.toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%) translateY(20px);
background:var(--card2);color:var(--fg);padding:11px 18px;border-radius:99px;
font-size:14px;opacity:0;transition:.2s;pointer-events:none;z-index:9}
.toast.show{transform:translateX(-50%);opacity:1}

/* Requirements: which items are needed to reach the location. Seed-independent. */
.req{margin-top:18px;border-top:1px solid var(--line);padding-top:16px}
.req h3{margin:0 0 3px;font-size:12px;font-weight:600;color:var(--dim);
letter-spacing:.05em;text-transform:uppercase}
.req .ex{color:#5d6478;font-size:11.5px;margin-bottom:9px;line-height:1.4}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px}
.chips button{background:var(--card);border:1px solid var(--line);
color:var(--dim);border-radius:99px;padding:8px 12px;font:600 12px system-ui;
cursor:pointer}
.chips button.on{border-color:var(--accent);color:var(--accent);
background:rgba(91,157,255,.12)}
#regsel{width:100%;padding:11px 12px;font-size:15px;border-radius:11px;
border:1px solid var(--line);background:var(--card);color:var(--fg);
margin-bottom:10px}
.chips.any button.on{border-color:#ffb454;color:#ffb454;
background:rgba(255,180,84,.12)}

/* List of every location - for going back and redoing a misplaced marker */
.list{margin-top:26px;border-top:1px solid var(--line);padding-top:18px}
.list h2{font-size:12px;color:var(--dim);margin:0 0 10px;font-weight:600;
letter-spacing:.06em;text-transform:uppercase}
#filter{width:100%;padding:12px 14px;font-size:16px;border-radius:12px;
border:1px solid var(--line);background:var(--card);color:var(--fg);
margin-bottom:10px}
#rows{max-height:52vh;overflow-y:auto;-webkit-overflow-scrolling:touch}
#rows div{display:flex;align-items:center;gap:10px;padding:11px 12px;
border-radius:10px;background:var(--card);margin-bottom:6px;cursor:pointer}
#rows div.cur{border:1px solid var(--accent)}
#rows i{width:9px;height:9px;border-radius:50%;background:var(--card2);
flex:0 0 auto}
#rows div.set i{background:var(--ok)}
#rows b{font-weight:500;font-size:14px;flex:1;overflow:hidden;
text-overflow:ellipsis;white-space:nowrap}
#rows s{font-size:11px;color:var(--dim);text-decoration:none;flex:0 0 auto}
</style>
<header>
  <div class="prog" id="prog"></div>
  <div class="bar"><i id="fill"></i></div>
  <div class="reg" id="reg"></div>
  <h1 id="name">Loading…</h1>
</header>
<main id="main">
  <div class="worlds">
    <button id="blw" class="on">Light World</button>
    <button id="bdw">Dark World</button>
    <span id="kartnamn" class="kartnamn"></span>
  </div>
  <div class="worlds">
    <button id="sp_alla" class="on">All</button>
    <button id="sp_zelda">Zelda</button>
    <button id="sp_metroid">Metroid</button>
  </div>
  <div class="wrap" id="wrap">
    <img id="map" alt="">
    <div id="dots"></div>
  </div>
  <div class="hint">Tap the map where the location sits. If it is inside a dungeon, press <b>Skip</b>.</div>
  <div class="row">
    <button class="skip" id="skip">Skip</button>
    <button id="undo">Undo</button>
    <button class="save" id="next" disabled>Next</button>
  </div>
  <div class="req">
    <h3>Region requirements</h3>
    <div class="ex">Applies to EVERY location in the area, so it does not have to be entered once per location. Added on top of the location's own requirements.</div>
    <select id="regsel"></select>
    <div class="chips" id="rgall"></div>
    <div class="chips any" id="rgany"></div>
  </div>
  <div class="req">
    <h3>Requires all of</h3>
    <div class="ex">All of them are needed for the location to be reachable.</div>
    <div class="chips" id="reqall"></div>
    <h3>Requires any of</h3>
    <div class="ex">Any one of them is enough. Leave empty if there is no alternative.</div>
    <div class="chips any" id="reqany"></div>
  </div>
  <div class="list">
    <h2 id="lh">All locations</h2>
    <input id="filter" placeholder="Search locations…" autocomplete="off"
           autocorrect="off" autocapitalize="off" spellcheck="false">
    <div id="rows"></div>
  </div>
</main>
<div class="toast" id="toast"></div>
<script>
const API=window.MISTER_API||'';
/* The map images sit NEXT TO the page, exactly as the seed page does it.
   An absolute address to one particular Home Assistant used to stand here;
   it worked in a single home and shipped out with the package on top of
   that. Relative works in both modes: served from HA's /local/ it finds
   /local/alttp-lw.png, served from the MiSTer it is fetched from there. */
const MAPS={lw:'alttp-lw.png', dw:'alttp-dw.png',
  metroid:'sm-world.webp'};
const KARTNAMN={lw:'Light World',dw:'Dark World',metroid:'Zebes'};
const $=i=>document.getElementById(i);
let allaLocs=[],locs=[],i=0,world='lw',pending=null,done={},items=[],logic={};
// Zelda and Metroid are two separate sessions of work - 243 and 100
// locations. Without a filter you have to scroll through all of Zelda to
// reach Metroid.
let spel='alla';
function setSpel(v){
  spel=v;
  ['alla','zelda','metroid'].forEach(k=>{
    const b=document.getElementById('sp_'+k);
    if(b)b.className=(k===v?'on':'');
  });
  locs=allaLocs.filter(l=>v==='alla' ? true
      : v==='metroid' ? l.region==='Metroid' : l.region!=='Metroid');
  i=0;
  while(i<locs.length&&done[key(locs[i])])i++;
  if(i>=locs.length)i=0;
  buildRows();show();
}

/* Region requirements: the same chip UI, but for a whole area. The rules
   are written by hand - guessing at ALTTP logic would lock the wrong
   locations. */
let regs=[],regReqs={};
async function loadRegions(){
  let d;try{d=await(await fetch(API+'api/regions')).json()}catch(e){return}
  regs=d.regions||[];regReqs=d.reqs||{};
  if(!items.length)items=d.items||[];
  const sel=$('regsel');
  const keep=sel.value;
  sel.innerHTML=regs.map(r=>'<option>'+r+'</option>').join('');
  if(keep&&regs.indexOf(keep)>=0)sel.value=keep;
  sel.onchange=drawReg;
  drawReg();
}
function drawReg(){
  const name=$('regsel').value;
  const cur=regReqs[name]||{all:[],any:[]};
  ['all','any'].forEach(kind=>{
    const sel=cur[kind]||[];
    $('rg'+kind).innerHTML=items.map(it=>
      '<button data-i="'+it.id+'" class="'+(sel.indexOf(it.id)>=0?'on':'')+'">'+
      it.name+'</button>').join('');
    $('rg'+kind).querySelectorAll('button').forEach(b=>b.onclick=async()=>{
      const c=regReqs[name]||{all:[],any:[]};
      c[kind]=c[kind]||[];
      const at=c[kind].indexOf(b.dataset.i);
      if(at>=0)c[kind].splice(at,1); else c[kind].push(b.dataset.i);
      regReqs[name]=c;b.classList.toggle('on',at<0);
      try{await fetch(API+'api/region',{method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({name:name,all:c.all||[],any:c.any||[]})});
        toast(name+' updated')}
      catch(e){toast('Could not save')}
    });
  });
}

/* Requirements for the location you are standing on. Saved on every tap -
   no "save" button to forget. Seed-independent, like the positions. */
function reqKey(l){return l.region+'|'+l.name}
function drawReq(){
  const l=locs[i];
  if(!l){$('reqall').innerHTML=$('reqany').innerHTML='';return}
  const cur=logic[reqKey(l)]||{all:[],any:[]};
  ['all','any'].forEach(kind=>{
    const sel=cur[kind]||[];
    $('req'+kind).innerHTML=items.map(it=>
      '<button data-i="'+it.id+'" class="'+(sel.indexOf(it.id)>=0?'on':'')+'">'+
      it.name+'</button>').join('');
    $('req'+kind).querySelectorAll('button').forEach(b=>b.onclick=()=>{
      const id=b.dataset.i;
      const c=logic[reqKey(l)]||{all:[],any:[]};
      c[kind]=c[kind]||[];
      const at=c[kind].indexOf(id);
      if(at>=0)c[kind].splice(at,1); else c[kind].push(id);
      logic[reqKey(l)]=c;
      b.classList.toggle('on',at<0);
      saveReq(l,c);
    });
  });
}
async function saveReq(l,c){
  try{
    await fetch(API+'api/logic',{method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({region:l.region,name:l.name,
                           all:c.all||[],any:c.any||[]})});
  }catch(e){toast('Could not save the requirement')}
}

function toast(m){const t=$('toast');t.textContent=m;t.className='toast show';
  clearTimeout(t._t);t._t=setTimeout(()=>t.className='toast',1400)}

function setWorld(w){
  if(!MAPS[w])w='lw';
  world=w;
  const blw=$('blw'), bdw=$('bdw');
  // The Zelda buttons only mean anything on the Zelda maps.
  const zelda=(w==='lw'||w==='dw');
  if(blw){blw.style.display=zelda?'':'none';blw.className=w==='lw'?'on':''}
  if(bdw){bdw.style.display=zelda?'':'none';bdw.className=w==='dw'?'on':''}
  const et=$('kartnamn');
  if(et){et.textContent=KARTNAMN[w]||w;et.style.display=zelda?'none':''}
  $('map').src=MAPS[w];
  draw();
}

function key(l){return l.region+'|'+l.name}

function draw(){
  const d=$('dots');d.innerHTML='';
  const cur=i<locs.length?key(locs[i]):null;
  Object.keys(done).forEach(k=>{
    if(k===cur)return;                       // the current one is drawn as pending
    const p=done[k];if(p.world!==world)return;
    const e=document.createElement('div');e.className='dot old';
    e.style.left=(p.x*100)+'%';e.style.top=(p.y*100)+'%';d.appendChild(e)});
  if(pending&&pending.world===world){
    const e=document.createElement('div');e.className='dot';
    e.style.left=(pending.x*100)+'%';e.style.top=(pending.y*100)+'%';
    d.appendChild(e)}
}

function show(){
  if(i>=locs.length){
    $('main').innerHTML='<div class="done"><b>Done!</b>'+
      Object.keys(done).length+' locations marked.<br>'+
      'Everything is stored on the MiSTer.</div>';
    $('name').textContent='Finished';$('reg').textContent='';
    $('prog').textContent=locs.length+' of '+locs.length;
    $('fill').style.width='100%';return;
  }
  const l=locs[i];
  $('reg').textContent=l.region;
  $('name').textContent=l.name;
  $('prog').textContent=(i+1)+' of '+locs.length+
    '  ·  '+Object.keys(done).length+' marked';
  $('fill').style.width=((i/locs.length)*100)+'%';
  // If the location is already marked, show where it sits now so you can
  // see what you are correcting. Tapping the map overwrites, Next keeps.
  const old=done[key(l)];
  pending=old?{world:old.world,x:old.x,y:old.y}:null;
  $('next').disabled=!pending;
  // Metroid locations carry their map in the data (l.world). For Zelda it
  // is guessed from the region name, as before.
  const w=pending?pending.world : (l.world ||
    (/dark|thieves|misery|swamp|skull|ice palace|turtle|ganon/i.test(l.region)
      ?'dw':'lw'));
  if(w!==world)setWorld(w); else draw();
  markRows();drawReq();
}

/* The list makes it possible to go back to a mismarked location. */
function buildRows(){
  const q=$('filter').value.toLowerCase();
  const r=$('rows');r.innerHTML='';
  locs.forEach((l,idx)=>{
    if(q&&(l.name+' '+l.region).toLowerCase().indexOf(q)<0)return;
    const d=document.createElement('div');
    d.dataset.i=idx;
    d.className=(done[key(l)]?'set ':'')+(idx===i?'cur':'');
    d.innerHTML='<i></i><b></b><s></s>';
    d.querySelector('b').textContent=l.name;
    d.querySelector('s').textContent=l.region;
    d.onclick=()=>{i=idx;show();window.scrollTo({top:0,behavior:'smooth'})};
    r.appendChild(d);
  });
  $('lh').textContent='All locations — '+Object.keys(done).length+
    ' of '+locs.length+' marked';
}
function markRows(){
  document.querySelectorAll('#rows div').forEach(d=>{
    const l=locs[d.dataset.i];
    d.className=(done[key(l)]?'set ':'')+(+d.dataset.i===i?'cur':'');
  });
}

$('wrap').onclick=e=>{
  const r=$('wrap').getBoundingClientRect();
  pending={world:world,x:(e.clientX-r.left)/r.width,y:(e.clientY-r.top)/r.height};
  $('next').disabled=false;draw();
};
['alla','zelda','metroid'].forEach(k=>{
  const b=document.getElementById('sp_'+k);
  if(b)b.onclick=()=>setSpel(k);
});
$('blw').onclick=()=>setWorld('lw');
$('bdw').onclick=()=>setWorld('dw');
$('skip').onclick=()=>{i++;show()};
$('filter').oninput=buildRows;
$('undo').onclick=()=>{
  // Clears the marker for the location you are on - locally and on the server.
  const l=locs[i];if(!l)return;
  if(!done[key(l)]&&!pending){toast('Nothing to undo');return}
  delete done[key(l)];pending=null;
  save(l,null);show();buildRows();toast('Marker removed');
};
$('next').onclick=()=>{
  if(!pending)return;
  const l=locs[i];done[key(l)]=pending;
  save(l,pending);i++;show();buildRows();
};

async function save(l,pos){
  try{await fetch(API+'api/annotate',{method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({region:l.region,name:l.name,pos:pos})})}
  catch(e){toast('Could not save')}
}

(async function(){
  try{
    const r=await fetch(API+'api/locations');
    const d=await r.json();
    allaLocs=d.locations||[];locs=allaLocs;
    items=d.items||[];logic=d.logic||{};
    (d.saved||[]).forEach(s=>{if(s.pos)done[s.region+'|'+s.name]=s.pos});
    // skip ahead to the first unmarked one
    while(i<locs.length&&done[key(locs[i])])i++;
    buildRows();setWorld('lw');show();loadRegions();
  }catch(e){$('name').textContent='Could not load locations'}
})();
</script>
"""
