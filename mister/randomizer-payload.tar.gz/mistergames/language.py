"""Language support for the pages and the API replies.

The source language in the code is ENGLISH. A language file is a flat
dictionary from the English string to the same string in another language:

    { "Close": "Stang", "New seed": "Ny seed" }

The files live in .mistergames/lang/<code>.json. Which one is used is
decided by the MISTER_LANG environment variable, which the installer
writes into randomizer.conf. English is the default.

⚠️ The variable is MISTER_LANG and not LANG on purpose. LANG is the POSIX
locale variable and is often already set to something like sv_SE.UTF-8;
we would then look for a file named sv_SE.UTF-8.json and quietly fall
back to English on every machine that has a locale configured.

## How the substitution works

A page is one big string of HTML, CSS and JS mixed together. Replacing
text inside it requires knowing where the text ENDS - otherwise "Show"
also matches inside "Showing 900 of". Only segments that sit between
delimiters are replaced: a tag or a quote on both sides.

    >Close<        HTML text
    'Close'        JS string
    "Close"        JS string or HTML attribute

That is the same condition lang_extract.py pulls keys out with, so a key
from the template can always match.

⚠️ The longest key is replaced first. Otherwise "Cleared" would eat half
of "Cleared of 5" before the longer key got its chance.

## Inheritance

A language file can inherit from another one with "__inherit". Anything
missing is taken from there. Since English is the source, a language file
normally needs no inheritance at all: an untranslated string is simply
left as it is, which is English already.

That also means a half-finished translation never breaks a page. It just
leaves part of it in English.
"""
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
LANG_DIR = os.path.join(HERE, "lang")

# A segment between delimiters. Used both when keys are extracted and when
# they are replaced - kept in ONE place so the two cannot drift apart.
DELIMITED = re.compile(r"(?<=[>'\"])(?P<text>[^<>'\"]{2,80})(?=[<'\"])")

DEFAULT = "en"

# Loaded dictionaries and finished pages, so that each page is translated
# once per language instead of once per visit. The pages are 16-64 K and
# the dictionaries a few hundred entries; without the cache every page load
# would cost a few hundred needless regex passes.
_dicts = {}
_ordered = {}
_page_cache = {}


def _code(code=None):
    return (code or os.environ.get("MISTER_LANG") or DEFAULT).strip().lower()


def _read_file(code):
    path = os.path.join(LANG_DIR, "%s.json" % code)
    if not os.path.isfile(path):
        return None
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (ValueError, OSError) as e:
        # A broken language file must never take the server down - that
        # would make a misspelled translation as bad as a page being gone.
        print("lang: cannot read %s: %s" % (path, e))
        return None


def dictionary(code=None):
    """The dictionary for a language, with inheritance folded in."""
    code = _code(code)
    if code in _dicts:
        return _dicts[code]

    merged = {}
    seen = []
    nxt = code
    while nxt and nxt not in seen:        # ⚠️ inheritance must not loop
        seen.append(nxt)
        data = _read_file(nxt)
        if data is None:
            break
        inherit = data.get("__inherit")
        for k, v in data.items():
            if k.startswith("__") or not isinstance(v, str):
                continue
            merged.setdefault(k, v)       # nearest in the chain wins
        nxt = inherit

    _dicts[code] = merged
    # Longest key first, once per language instead of once per replacement.
    _ordered[code] = sorted(merged.items(), key=lambda kv: len(kv[0]),
                            reverse=True)
    return merged


def language_name(code):
    """The language's own name, for the menu in the installer."""
    data = _read_file(code) or {}
    return data.get("__name", code)


def available():
    """Every language in lang/, as (code, own name)."""
    out = []
    if os.path.isdir(LANG_DIR):
        for fn in sorted(os.listdir(LANG_DIR)):
            if not fn.endswith(".json") or fn == "TEMPLATE.json":
                continue
            code = fn[:-5]
            out.append((code, language_name(code)))
    return out


def _safe(value, opening):
    """Make a translation harmless in the position it lands in.

    ⚠️ This is not a formality. French and Spanish are full of apostrophes
    - "l'ecran", "¿Que esta pasando?" - and an apostrophe dropped straight
    into a single-quoted JS string ends that string halfway through and
    takes the whole page down. Which character is dangerous depends on
    WHERE the text sits, so the delimiter decides:

        '...'   apostrophe and backslash need a backslash
        "..."   the same, for double quotes
        >...<   HTML text: everything dangerous becomes an entity

    ⚠️ The HTML branch has to handle the QUOTES as well, not just < and >.
    Nearly all HTML in the pages is built from inside single-quoted JS
    strings:

        h+='<div class="lbl">Also one of</div>'

    A translation then sits in HTML position but INSIDE a JS string, and an
    apostrophe ends that string halfway. Entities solve both at once:
    &#39; contains no quote character at all, and the browser shows it as
    an apostrophe.
    """
    if opening == ">":
        return (value.replace("&", "&amp;")
                     .replace("<", "&lt;").replace(">", "&gt;")
                     .replace("'", "&#39;").replace('"', "&quot;"))
    return value.replace("\\", "\\\\").replace(opening, "\\" + opening)


def translate(text, code=None):
    """Replace every known segment in a page."""
    code = _code(code)
    dictionary(code)                     # fills _ordered
    pairs = _ordered.get(code) or []
    if not pairs:
        return text
    for key, value in pairs:
        if value == key:
            continue
        # The delimiters are captured rather than just peeked at: they are
        # what each translation has to be adapted to, and they are written
        # back unchanged.
        pattern = r"([>'\"])" + re.escape(key) + r"(['\"<])"

        def swap(m, v=value):
            return m.group(1) + _safe(v, m.group(1)) + m.group(2)

        text = re.sub(pattern, swap, text)
    return text


def page(name, text, code=None):
    """Like translate(), but remembers the result per page and language."""
    code = _code(code)
    key = (name, code)
    if key not in _page_cache:
        _page_cache[key] = translate(text, code)
    return _page_cache[key]


def word(text, code=None):
    """Translate ONE string, such as an item name in an API reply.

    There are no delimiters to go by here - the string is the whole text -
    so the lookup is exact. If it is not found, the English is kept.
    """
    if not text:
        return text
    return dictionary(code).get(text, text)
