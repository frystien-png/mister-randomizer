"""Review the language files. Run it after every change in lang/.

    python3 lang_check.py            every language
    python3 lang_check.py fr         just French

Four things are checked, and the first three are the ones that actually
break something:

1. DEAD KEY. A key that occurs nowhere in the pages or in server.py can
   never match. Almost always a typo - one missing trailing space is
   enough - and without this check it only shows up as that one piece of
   text "not being translatable".

2. DANGEROUS KEY. The pages use the same kind of quotes for text as for
   CSS classes and DOM calls. Translate "toast show" and the page changes
   class instead of language and stops working. Keys that also occur as a
   class name, a selector or a file name are therefore rejected.

3. BROKEN FILE, or inheritance pointing at nothing.

4. Coverage: how much of the template the language actually translates.
   Just a number - an incomplete translation works fine, the rest simply
   stays in English, which is the source language.

Exits with 1 if any of 1-3 were found.
"""
import json
import os
import re
import sys

import language

HERE = os.path.dirname(os.path.abspath(__file__))
PAGES = ["page.py", "seedpage.py", "annotatepage.py"]
SERVER = "server.py"


def read_sources():
    text = ""
    for fn in PAGES + [SERVER]:
        path = os.path.join(HERE, fn)
        if os.path.isfile(path):
            text += open(path, encoding="utf-8").read()
    return text


def dangerous(source):
    """Strings used as a class, a selector or a file name."""
    out = set()
    for pattern in (r"class=[\"']([^\"']+)[\"']",
                    r"classList\.\w+\(([^)]*)\)",
                    r"querySelector(?:All)?\(([^)]*)\)",
                    r"getElementById\(([^)]*)\)",
                    r"className\s*=\s*([^;]+)"):
        for m in re.finditer(pattern, source):
            for bit in re.findall(r"[\"']([^\"']+)[\"']", m.group(0)):
                out.add(bit)
                # "trk show stub" is also used in parts
                for word in bit.split():
                    out.add(word)
    for m in re.finditer(r"[\"']([\w.-]+\.(?:png|webp|jpe?g|svg|json))[\"']",
                         source):
        out.add(m.group(1))
    return out


def main():
    chosen = [a.lower() for a in sys.argv[1:]]
    source = read_sources()
    risky = dangerous(source)

    template_path = os.path.join(language.LANG_DIR, "TEMPLATE.json")
    template = {}
    if os.path.isfile(template_path):
        template = json.load(open(template_path, encoding="utf-8"))
    template_size = len([k for k in template if not k.startswith("__")])

    problems = 0
    for code, name in language.available():
        if chosen and code not in chosen:
            continue
        data = language._read_file(code)
        if data is None:
            print("%s: CANNOT BE READ" % code)
            problems += 1
            continue

        keys = [k for k in data if not k.startswith("__")]
        inherit = data.get("__inherit")
        lines = []

        if inherit and not os.path.isfile(
                os.path.join(language.LANG_DIR, "%s.json" % inherit)):
            lines.append("  ⚠️  inherits from \"%s\", which does not exist"
                         % inherit)
            problems += 1

        for k in keys:
            # ⚠️ A few strings are assembled at runtime: "Crystal %d" % i
            # gives "Crystal 1" ... "Crystal 7", which therefore never
            # appear literally in the code. The trailing number is tried as
            # a format string as well.
            as_format = re.sub(r"\d+$", "%d", k)
            if k not in source and as_format not in source:
                lines.append("  ❌ DEAD KEY, not found in the pages: %r" % k)
                problems += 1
            elif k in risky:
                lines.append("  ❌ DANGEROUS KEY, also used as a class or "
                             "file name: %r" % k)
                problems += 1
            if not isinstance(data[k], str):
                lines.append("  ❌ value is not text: %r" % k)
                problems += 1

        coverage = ""
        if template_size:
            coverage = " - %d%% of the template" % (100 * len(keys) / template_size)
        inherited = (", inherits %s" % inherit) if inherit else ""
        print("%-4s %-12s %3d keys%s%s"
              % (code, name, len(keys), inherited, coverage))
        for line in lines:
            print(line)

    print()
    if problems:
        print("%d problem(s). The marked ones must be fixed - other "
              "languages are unaffected by them." % problems)
        return 1
    print("The language files look fine.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
